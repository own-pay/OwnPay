# OwnPay — Native MCP Server (Design + Implementation Guide)

> **Status:** Design / implementation plan (not yet built). This document is the complete blueprint for adding a **native, first-party MCP (Model Context Protocol) server** to OwnPay so an AI assistant can safely perform routine merchant operations.
> **Hard rule:** the MCP server can **never** move money or expose secrets. It cannot refund, initiate or verify/mark-paid a transaction, read or manage API keys, or change security/settings/users. It is **admin enable/disable-able** and **OAuth 2.1-secured**.
> All class/method/table references were verified against the live codebase (custom PHP 8.2 framework at the repo root).

---

## 1. Overview

### 1.1 What it is
A native MCP server exposed by OwnPay over **Streamable HTTP** at `POST /api/v1/mcp`. It speaks JSON-RPC 2.0 and offers a curated set of **safe tools** an AI assistant (e.g. Claude Desktop, an IDE agent, or any MCP client) can call on the merchant's behalf:

- **Billing artifacts (safe writes):** create / update / cancel **invoices** and **payment links**.
- **Customers (safe writes + reads):** add, update, get, search, list customers.
- **Money data (reads only):** search transactions, get a transaction, stats, reports, CSV export, merchant balance, and **view** (never create) refund records.

### 1.2 Goals
- Let an assistant *operate the business* (raise invoices, send a payment link, look up a customer's history) through a uniform, model-friendly tool interface.
- Be **secure by construction**: no tool that can cause financial loss exists; no path to API keys or secrets.
- Be **owner-controlled**: a global + per-brand kill switch, per-client/token revocation, full audit trail.
- Fit OwnPay's existing framework conventions (DI container, middleware groups, `Request`/`Response`, `TenantScope`).

### 1.3 Non-goals (explicitly out of scope)
- **No refunds** (`RefundService::create`).
- **No payment initiation** (`GatewayApiService::initiatePayment`).
- **No callback / verification / mark-paid** (`GatewayApiService::handleCallback`, `CheckoutController::submitVerification`).
- **No API-key access** (`ApiKeyService`, `op_api_keys`) — neither read nor create.
- **No settings / user / role / gateway-secret mutation.**
- **No cross-tenant access** (every call is bound to one `merchant_id`).

### 1.4 Who connects
The single owner connects **their own** AI assistant. Authentication is full **OAuth 2.1** (per the MCP authorization spec): the owner logs into OwnPay, consents to a scoped grant, and the client receives a short-lived access token. The token is an OAuth token — **never** a merchant API key.

---

## 2. Capability matrix (the contract)

### 2.1 ALLOWED — registered MCP tools
| Tool | Backing call (existing code) | Type |
|---|---|---|
| `invoice.create` | `InvoiceService::create(int $merchantId, array $data)` | write (no ledger) |
| `invoice.update` | `InvoiceService::update(int $merchantId, int $id, array $data)` | write |
| `invoice.cancel` | `InvoiceService::update(...)` → `status='cancelled'` | write |
| `invoice.get` / `invoice.list` | `InvoiceRepository::findScoped` / `listForMerchant` | read |
| `payment_link.create` | `PaymentLinkService::create(int $merchantId, array $data)` | write |
| `payment_link.update` | `PaymentLinkService::update(int $merchantId, int $id, array $data)` | write |
| `payment_link.deactivate` | `PaymentLinkService::update(...)` → `status='inactive'` | write |
| `payment_link.get` / `payment_link.list` | `PaymentLinkService::find` / `listForMerchant` | read |
| `customer.create` | `CustomerPiiService::create(int $merchantId, array $data)` | write (PII) |
| `customer.update` | `CustomerPiiService::update(int $merchantId, int $id, array $data)` | write (PII) |
| `customer.get` / `customer.search` / `customer.list` | `CustomerPiiService::get` / `findByContact` / `list` | read (PII) |
| `transaction.search` | `TransactionRepository::listFiltered` + `countFiltered` | read |
| `transaction.get` | `TransactionRepository::findScoped` / `findByTrxId` | read |
| `transaction.stats` | `TransactionRepository::stats` / `getTodayStats` | read |
| `transaction.report` | `TransactionRepository::getReportData` | read |
| `transaction.export` | `TransactionRepository::getExportData` | read |
| `balance.get` | Ledger read (LedgerService / `LedgerRepository` balance accessor — confirm exact method at build) | read |
| `refund.list` / `refund.get` | `RefundRepository::forTenant($mid)->paginateScoped` / `findScoped` | **read only** |

> All reads/writes go through `->forTenant($merchantId)` (the `TenantScope` trait in `src/Repository/TenantScope.php`).

### 2.2 FORBIDDEN — never registered, never reachable
| Forbidden capability | Where it lives | Why blocked |
|---|---|---|
| Create refund | `src/Service/Payment/RefundService.php::create` | Debits ledger + calls gateway refund → money out |
| Initiate payment | `src/Service/Payment/GatewayApiService.php::initiatePayment` | Creates txn + hands off to gateway |
| Handle callback / mark paid | `GatewayApiService::handleCallback` | Marks completed + posts ledger entry |
| Submit verification | `src/Controller/Checkout/CheckoutController.php::submitVerification` | Transitions txn status |
| Any API-key op | `src/Service/Customer/ApiKeyService.php`, `op_api_keys` | Would expose/forge credentials |
| Unscoped queries | `TransactionRepository::findPendingMatchGlobal`, `getGlobalBrandBreakdown` | Cross-tenant data leak |
| Settings / users / gateway secrets | `SettingsController`, user/role services | Security-sensitive mutation |

### 2.3 Three independent layers enforce 2.2
1. **Deny-by-default registry** — forbidden operations are simply *not registered as tools*; `tools/list` cannot show them and `tools/call` returns *method not found*.
2. **Hard deny-list + CI guard** — `ToolRegistry` refuses to register, and a CI test fails the build, if any tool name/handler matches `refund|initiate|callback|verify|complete|markPaid|api[_-]?key|ledger|settings|password` patterns.
3. **OAuth scopes + tenant binding** — the access token carries only safe scopes and a single `merchant_id`; every handler calls `forTenant($merchantId)`. A token for brand A can never read brand B.

---

## 3. Architecture

### 3.1 Components (new unless noted)
```
src/Mcp/
  McpServer.php            # JSON-RPC 2.0 dispatcher (initialize, tools/list, tools/call, ping)
  ToolRegistry.php         # allowlist + HARD deny-list guard; list()/call()
  Tool.php                 # interface: name(), title(), description(), inputSchema(), scope(), handle()
  McpContext.php           # carries merchantId, userId, scopes, ip, userAgent (for audit + scoping)
  Tools/
    InvoiceTools.php  PaymentLinkTools.php  CustomerTools.php
    TransactionTools.php  ReportTools.php
src/Controller/Api/
  McpController.php         # POST /api/v1/mcp  → McpServer
  OAuthController.php       # /oauth/authorize, /oauth/token, /.well-known/*, /oauth/register
src/Controller/Admin/
  McpController.php         # admin page: enable/disable, clients, tokens, tool toggles, audit
src/Middleware/
  McpResourceMiddleware.php # OAuth token validation + enabled gate + scope/audience + context inject
src/Service/OAuth/
  OAuthServer.php           # code issuance/exchange, PKCE verify, token mint/rotate/revoke
src/Repository/
  OAuthClientRepository.php  OAuthAuthCodeRepository.php  OAuthTokenRepository.php
templates/
  admin/mcp/index.twig
  oauth/consent.twig
```
**Modified:** `config/routes/api.php` (+ MCP/OAuth/well-known routes), `config/middleware.php` (+ `mcp` group), `config/services.php` (registrations), `database/schema.sql` (+ migration).

### 3.2 Request lifecycle
```mermaid
flowchart LR
  C[MCP Client] -- "Bearer access_token" --> G[global middleware\nSecurityHeaders, Maintenance, Domain]
  G --> M[mcp group\nCors, RateLimiter, McpResource, Idempotency]
  M --> Ctl[McpController@handle]
  Ctl --> S[McpServer.dispatch JSON-RPC]
  S --> R[ToolRegistry.call name,args,ctx]
  R --> T[Tool.handle]
  T --> Svc["Service forTenant(merchantId)\nInvoice/PaymentLink/Customer/Transaction"]
  Svc --> DB[(MySQL / PDO)]
  T --> A[AuditLogger.log mcp.tool.call]
```

`McpResourceMiddleware` is where auth + the kill switch live; it injects `merchant_id`, `user_id`, and granted `scopes` into request attributes (the same `getAttribute('merchant_id')` pattern used by `BearerAuthMiddleware`).

### 3.3 Why Streamable HTTP (not stdio)
OwnPay is a hosted web app, so the **remote** Streamable HTTP transport is the native fit: one HTTP endpoint, one JSON-RPC message per POST, `application/json` responses. (SSE streaming is optional and **off by default** — it is awkward under PHP-FPM and unnecessary for fast tool calls.) Desktop clients that only speak stdio connect through the documented `npx mcp-remote <url>` bridge (see §11).

---

## 4. MCP protocol surface

Transport: HTTP POST, body = a JSON-RPC 2.0 object. The server supports these methods:

| Method | Purpose | Result |
|---|---|---|
| `initialize` | Handshake; negotiate `protocolVersion`; advertise capabilities | `{ protocolVersion, capabilities:{tools:{}}, serverInfo:{name,version} }` |
| `notifications/initialized` | Client ready (notification, no response) | — |
| `tools/list` | Enumerate available tools | `{ tools:[{name,title,description,inputSchema}] }` |
| `tools/call` | Invoke a tool | `{ content:[{type:"text",text}], structuredContent?, isError? }` |
| `ping` | Liveness | `{}` |

- **Protocol version:** echo the client's requested version when supported; otherwise return the server's latest supported revision (target `2025-06-18`). Require the `MCP-Protocol-Version` header on post-initialize requests.
- **Errors:** protocol errors use JSON-RPC error objects (`-32700` parse, `-32600` invalid request, `-32601` method not found, `-32602` invalid params, `-32603` internal). **Tool** failures (validation, not-found) are returned as a normal result with `isError: true` and a text message — never a stack trace.
- **Tool definitions** advertise a JSON-Schema `inputSchema`; the server validates arguments against it before dispatch and rejects unknown fields.
- **Body cap:** reject bodies > 1 MB (mirror the webhook controller's cap). **Batch:** disabled (return invalid request) to keep the surface small.

---

## 5. OAuth 2.1 security design (MCP authorization)

OwnPay is **both** the OAuth 2.1 **Authorization Server (AS)** and the **Resource Server (RS)**. The MCP endpoint is a protected resource; the access token is minted by OwnPay's AS.

### 5.1 Endpoints
| Endpoint | Group | Purpose |
|---|---|---|
| `GET /.well-known/oauth-protected-resource` | `api-public` | RFC 9728 — advertises the AS for the MCP resource |
| `GET /.well-known/oauth-authorization-server` | `api-public` | RFC 8414 — AS metadata (authorize/token/registration URLs, PKCE methods, scopes) |
| `GET /oauth/authorize` | `web` (session + CSRF) | Authorization endpoint → login (if needed) → consent screen |
| `POST /oauth/authorize` | `web` | Consent submit → issue authorization code |
| `POST /oauth/token` | `api-public` | Code→token exchange + refresh-token grant |
| `POST /oauth/register` | `api-public` (admin-gated) | RFC 7591 dynamic client registration |
| `POST /api/v1/mcp` | `mcp` | The protected MCP resource |

### 5.2 Flow (authorization code + PKCE + resource indicator)
```mermaid
sequenceDiagram
  participant Cl as MCP Client
  participant RS as OwnPay /api/v1/mcp (RS)
  participant AS as OwnPay /oauth (AS)
  Cl->>RS: POST /api/v1/mcp (no token)
  RS-->>Cl: 401 + WWW-Authenticate: resource_metadata=".../oauth-protected-resource"
  Cl->>AS: GET /.well-known/oauth-protected-resource → AS metadata
  Cl->>AS: GET /oauth/authorize?client_id&redirect_uri&code_challenge(S256)&scope&resource&state
  AS->>AS: Authenticate owner (existing session) + show consent (scopes + "cannot refund/pay/read API keys")
  AS-->>Cl: 302 redirect_uri?code=...&state=...
  Cl->>AS: POST /oauth/token (code, code_verifier, redirect_uri, resource)
  AS-->>Cl: { access_token, refresh_token, token_type:"Bearer", expires_in, scope }
  Cl->>RS: POST /api/v1/mcp (Authorization: Bearer access_token)
  RS->>RS: validate token (hash lookup, expiry, audience==resource, scopes, mcp.enabled)
  RS-->>Cl: JSON-RPC result
```

### 5.3 Security properties
- **PKCE S256 mandatory** (OAuth 2.1) for all clients.
- **Resource indicators (RFC 8707):** the client passes `resource=https://<host>/api/v1/mcp`; the issued token's `audience` is bound to it; the RS rejects tokens whose audience ≠ the MCP resource. Prevents a token minted for another service from being replayed here.
- **Consent screen** lists granted scopes *and explicitly states the hard limits* ("This connection cannot issue refunds, take payments, verify transactions, or read API keys").
- **Opaque tokens, hashed at rest.** Access + refresh tokens are random secrets; only `token_prefix` + `SHA-256(token)` are stored (mirrors `SecurityHelpers::generateApiKey()` and the `BearerAuthMiddleware` prefix-lookup + `hash_equals` pattern). Format `ompmcp_{prefix}.{secret}` — a deliberately different prefix from API keys' `op_` so the two can never be confused.
- **Short access TTL** (≈1 h, configurable) + **rotating refresh tokens** (old refresh invalidated on use; reuse → revoke the chain).
- **Instant revocation / kill switch:** revoking a token or toggling `mcp.enabled=0` denies all subsequent calls (validation is a live DB check, not a stateless JWT).
- **Scopes** map to tool groups: `mcp:invoices`, `mcp:payment_links`, `mcp:customers`, `mcp:transactions:read`, `mcp:reports`, `mcp:refunds:read`, `mcp:balance:read`. **No scope** grants any forbidden op — they have no tool to map to.
- **Dynamic client registration** is **admin-gated** (a registration produces a *pending* client an admin approves) to avoid anonymous client sprawl.

---

## 6. Admin enable / disable

Uses the existing settings system (`op_system_settings`: `group_name`, `key_name`, `value`, `type`, `merchant_id` nullable for global; brand→global cascade) via `SettingsRepository`.

Seeds (group `mcp`):
| key | type | default | meaning |
|---|---|---|---|
| `enabled` | bool | `0` (global) | master switch; per-brand override allowed |
| `rate_limit_per_min` | int | `60` | per-token request cap |
| `token_ttl` | int | `3600` | access-token seconds |
| `refresh_ttl` | int | `2592000` | refresh-token seconds (30 d) |
| `allowed_tools` | json | (all) | optional per-brand allowlist subset |

Resolution in `McpResourceMiddleware`:
```php
$enabled = $this->settings->getScoped('mcp', 'enabled', $merchantId, '0') === '1';
if (!$enabled) {
    return Response::json(['error' => 'mcp_disabled'], 404); // behave as if absent
}
```

**Admin UI** (`src/Controller/Admin/McpController.php` + `templates/admin/mcp/index.twig`) mirrors the `SettingsController` + `templates/admin/settings/index.twig` tab pattern:
- Toggle **Enable MCP** (global, and per active brand).
- **Clients**: list / approve / disable registered MCP clients.
- **Tokens**: list active tokens (prefix, client, scopes, last_used_at, expiry) with **Revoke**.
- **Tools**: per-tool enable checkboxes (writes `mcp.allowed_tools`).
- **Activity**: recent `mcp.tool.call` audit rows.
Every change is written through `SettingsRepository::setScoped(...)` and logged via `AuditLogger::log(...)`.

---

## 7. Defense-in-depth security plan

| Control | Implementation |
|---|---|
| **No-loss guarantee** | Deny-by-default registry + hard deny-list + CI test (§2.3, §10.2). |
| **AuthN** | OAuth 2.1, PKCE, opaque hashed tokens, audience binding, short TTL + refresh rotation. |
| **AuthZ** | Per-tool scope check; deny if token lacks the tool's `scope()`. |
| **Tenant isolation** | Token bound to one `merchant_id`; every handler uses `->forTenant($merchantId)`; unscoped repo methods are off-limits. |
| **Kill switch** | `mcp.enabled` (global + brand) + token/client revocation; live DB check. |
| **Rate limiting** | Reuse `RateLimiterMiddleware` keyed by token prefix; `mcp.rate_limit_per_min`. |
| **Input validation** | JSON-Schema `inputSchema` per tool; reject unknown fields; clamp pagination (`per_page` ≤ 100). |
| **Audit** | `AuditLogger::log()` for `mcp.authorize`, `mcp.token.issued/refreshed/revoked`, `mcp.client.registered`, and **every** `mcp.tool.call` (tool, arg summary, result status, ip, ua) → `op_audit_logs` (HMAC-signed). |
| **PII handling** | Customer reads return full decrypted PII (per decision); each PII read is audit-logged; pagination capped to prevent bulk exfiltration; never returns `key_hash`, secrets, or internal-only columns. |
| **Idempotency** | Reuse `IdempotencyMiddleware` so a retried `invoice.create` doesn't duplicate. |
| **Transport** | HTTPS only (HSTS is already global); CORS/Origin validated against configured client origins. |
| **Error hygiene** | JSON-RPC errors / `isError` text only; no stack traces (consistent with `Kernel` prod handler). |
| **Body/Batch limits** | 1 MB cap; JSON-RPC batch disabled. |

---

## 8. Data model

```sql
-- Registered MCP/OAuth clients (admin-approved)
CREATE TABLE op_oauth_clients (
  id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  client_id         VARCHAR(64)  NOT NULL,
  client_name       VARCHAR(150) NOT NULL,
  client_secret_hash VARCHAR(255) NULL,            -- NULL for public+PKCE clients
  redirect_uris     JSON         NOT NULL,
  type              ENUM('public','confidential') NOT NULL DEFAULT 'public',
  status            ENUM('pending','active','disabled') NOT NULL DEFAULT 'pending',
  created_by        BIGINT UNSIGNED NULL,
  created_at        DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_oauth_client (client_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Short-lived authorization codes (PKCE)
CREATE TABLE op_oauth_auth_codes (
  id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  code_hash         VARCHAR(255) NOT NULL,         -- SHA-256 of the code
  client_id         VARCHAR(64)  NOT NULL,
  merchant_id       BIGINT UNSIGNED NOT NULL,
  user_id           BIGINT UNSIGNED NOT NULL,
  scopes            JSON         NOT NULL,
  code_challenge    VARCHAR(128) NOT NULL,
  code_challenge_method ENUM('S256') NOT NULL DEFAULT 'S256',
  redirect_uri      VARCHAR(500) NOT NULL,
  resource          VARCHAR(255) NOT NULL,         -- audience binding
  expires_at        DATETIME(6)  NOT NULL,         -- ~60s
  used_at           DATETIME(6)  NULL,
  created_at        DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_oauth_code (code_hash),
  KEY idx_oauth_code_client (client_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Access + refresh tokens (hashed, revocable)
CREATE TABLE op_oauth_tokens (
  id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  token_prefix      VARCHAR(12)  NOT NULL,         -- fast lookup
  token_hash        VARCHAR(255) NOT NULL,         -- SHA-256(full token)
  type              ENUM('access','refresh') NOT NULL,
  client_id         VARCHAR(64)  NOT NULL,
  merchant_id       BIGINT UNSIGNED NOT NULL,
  user_id           BIGINT UNSIGNED NOT NULL,
  scopes            JSON         NOT NULL,
  resource          VARCHAR(255) NOT NULL,         -- audience
  parent_token_id   BIGINT UNSIGNED NULL,          -- refresh rotation chain
  last_used_at      DATETIME(6)  NULL,
  expires_at        DATETIME(6)  NOT NULL,
  revoked_at        DATETIME(6)  NULL,
  created_at        DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_oauth_token_prefix (token_prefix),
  KEY idx_oauth_token_merchant (merchant_id, type),
  KEY idx_oauth_token_lookup (token_prefix, type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Settings seeds
INSERT INTO op_system_settings (group_name, key_name, value, type, merchant_id) VALUES
  ('mcp','enabled','0','bool',NULL),
  ('mcp','rate_limit_per_min','60','int',NULL),
  ('mcp','token_ttl','3600','int',NULL),
  ('mcp','refresh_ttl','2592000','int',NULL);
```
> Ship the DDL in `database/schema.sql` (fresh installs) **and** as a forward migration under `update/releases/<next>/migrations/*.sql` (existing installs). **Audit** reuses the existing `op_audit_logs` + `AuditLogger` — no new audit table needed.

---

## 9. Implementation plan (phased, for the write-enabled build)

| Phase | Deliverable | Verify |
|---|---|---|
| **P0** | Schema (`op_oauth_*`) + settings seeds + DI registrations skeleton | `php -l` clean; migration applies; settings readable |
| **P1** | OAuth 2.1 AS: well-known metadata, `/oauth/authorize` + consent, `/oauth/token` (PKCE S256, resource binding, refresh rotation), repos + `OAuthServer` | Drive the full code→token flow with MCP Inspector; PKCE mismatch → rejected |
| **P2** | `McpResourceMiddleware` + `mcp` middleware group + `enabled` gate | Valid token passes; missing/expired/disabled → 401/404; audience mismatch → 401 |
| **P3** | `McpServer` (JSON-RPC) + `Tool` interface + `ToolRegistry` (allowlist + deny-list) + `McpController` + route | `initialize`/`tools/list`/`ping` work; unknown method → -32601 |
| **P4** | Tools: invoice / payment_link / customer / transaction / report / balance / refund-read with `inputSchema` + `forTenant` handlers | Each tool round-trips against a sandbox merchant; schema validation rejects bad args |
| **P5** | Admin UI (enable/disable, clients, tokens, tool toggles, audit) | Toggle off → endpoint 404; revoke token → denied |
| **P6** | Hardening: rate limit, full audit wiring, deny-list CI test, CORS/Origin, body cap; tests; client docs | All §12 tests green |

---

## 10. Important code examples

> Idiomatic OwnPay PHP 8.2: `OwnPay\…` namespaces, constructor DI via `Container`, `Request`/`Response`, `TenantScope::forTenant()`.

### 10.1 Tool interface + a write tool
```php
<?php declare(strict_types=1);
namespace OwnPay\Mcp;

interface Tool
{
    public function name(): string;             // e.g. "invoice.create"
    public function title(): string;            // human label
    public function description(): string;      // model-facing description
    public function scope(): string;            // required OAuth scope, e.g. "mcp:invoices"
    public function inputSchema(): array;       // JSON Schema (object)
    /** @return array{content: array, isError?: bool, structuredContent?: array} */
    public function handle(array $args, McpContext $ctx): array;
}
```

```php
<?php declare(strict_types=1);
namespace OwnPay\Mcp\Tools;

use OwnPay\Container;
use OwnPay\Mcp\{Tool, McpContext};
use OwnPay\Service\Payment\InvoiceService;

final class InvoiceCreateTool implements Tool
{
    public function __construct(private Container $c) {}

    public function name(): string  { return 'invoice.create'; }
    public function title(): string { return 'Create invoice'; }
    public function scope(): string { return 'mcp:invoices'; }
    public function description(): string
    {
        return 'Create a draft invoice for the merchant. Does NOT take payment; '
             . 'returns the invoice and its hosted checkout token/URL.';
    }

    public function inputSchema(): array
    {
        return [
            'type' => 'object',
            'additionalProperties' => false,
            'properties' => [
                'customer_id' => ['type' => 'integer'],
                'currency'    => ['type' => 'string', 'minLength' => 3, 'maxLength' => 3],
                'due_date'    => ['type' => 'string', 'format' => 'date'],
                'notes'       => ['type' => 'string', 'maxLength' => 2000],
                'tax'         => ['type' => 'number', 'minimum' => 0],
                'discount'    => ['type' => 'number', 'minimum' => 0],
                'items'       => [
                    'type' => 'array', 'minItems' => 1,
                    'items' => [
                        'type' => 'object', 'additionalProperties' => false,
                        'required' => ['description', 'quantity', 'unit_price'],
                        'properties' => [
                            'description' => ['type' => 'string', 'maxLength' => 255],
                            'quantity'    => ['type' => 'integer', 'minimum' => 1],
                            'unit_price'  => ['type' => 'number', 'minimum' => 0],
                        ],
                    ],
                ],
            ],
            'required' => ['items'],
        ];
    }

    public function handle(array $args, McpContext $ctx): array
    {
        /** @var InvoiceService $svc */
        $svc = $this->c->get(InvoiceService::class);
        $invoice = $svc->create($ctx->merchantId, $args);  // tenant-scoped inside the service

        return [
            'structuredContent' => $invoice,
            'content' => [[
                'type' => 'text',
                'text' => "Created invoice {$invoice['invoice_number']} "
                        . "(total {$invoice['total']} {$invoice['currency']}). "
                        . "Checkout token: {$invoice['token']}",
            ]],
        ];
    }
}
```

### 10.2 ToolRegistry — allowlist + hard deny-list guard
```php
<?php declare(strict_types=1);
namespace OwnPay\Mcp;

final class ToolRegistry
{
    /** Forbidden patterns — registration throws if a tool name/handler matches. */
    private const DENY = '/refund(?!\.(list|get))|initiate|callback|verify|complete|'
                       . 'mark[_-]?paid|charge|capture|payout|api[_-]?key|secret|'
                       . 'ledger|password|setting|user|role|webhook/i';

    /** @var array<string, Tool> */
    private array $tools = [];

    public function register(Tool $tool): void
    {
        $name = $tool->name();
        // refund.list / refund.get are explicitly allowed read-only; everything else matching DENY is rejected.
        if (preg_match(self::DENY, $name) && !in_array($name, ['refund.list', 'refund.get'], true)) {
            throw new \LogicException("MCP: refusing to register forbidden tool '{$name}'");
        }
        $this->tools[$name] = $tool;
    }

    /** @return list<array{name:string,title:string,description:string,inputSchema:array}> */
    public function list(array $grantedScopes): array
    {
        $out = [];
        foreach ($this->tools as $t) {
            if (!in_array($t->scope(), $grantedScopes, true)) continue;
            $out[] = [
                'name' => $t->name(), 'title' => $t->title(),
                'description' => $t->description(), 'inputSchema' => $t->inputSchema(),
            ];
        }
        return $out;
    }

    public function call(string $name, array $args, McpContext $ctx): array
    {
        $tool = $this->tools[$name] ?? null;
        if ($tool === null) {
            return ['isError' => true, 'content' => [['type' => 'text', 'text' => "Unknown tool: {$name}"]]];
        }
        if (!in_array($tool->scope(), $ctx->scopes, true)) {
            return ['isError' => true, 'content' => [['type' => 'text', 'text' => 'Insufficient scope']]];
        }
        Validator::assert($args, $tool->inputSchema());   // JSON-Schema validation
        return $tool->handle($args, $ctx);
    }
}
```

### 10.3 McpServer — JSON-RPC dispatch
```php
<?php declare(strict_types=1);
namespace OwnPay\Mcp;

final class McpServer
{
    public const PROTOCOL = '2025-06-18';

    public function __construct(private ToolRegistry $registry) {}

    /** @param array $msg decoded JSON-RPC request @return ?array response (null for notifications) */
    public function dispatch(array $msg, McpContext $ctx): ?array
    {
        if (($msg['jsonrpc'] ?? null) !== '2.0') {
            return self::err($msg['id'] ?? null, -32600, 'Invalid Request');
        }
        $id = $msg['id'] ?? null;
        $method = (string)($msg['method'] ?? '');
        $params = (array)($msg['params'] ?? []);

        return match ($method) {
            'initialize' => self::ok($id, [
                'protocolVersion' => $params['protocolVersion'] ?? self::PROTOCOL,
                'capabilities'    => ['tools' => ['listChanged' => false]],
                'serverInfo'      => ['name' => 'OwnPay MCP', 'version' => '1.0.0'],
            ]),
            'notifications/initialized' => null,                       // notification
            'ping'       => self::ok($id, (object)[]),
            'tools/list' => self::ok($id, ['tools' => $this->registry->list($ctx->scopes)]),
            'tools/call' => self::ok($id, $this->registry->call(
                (string)($params['name'] ?? ''), (array)($params['arguments'] ?? []), $ctx
            )),
            default => self::err($id, -32601, "Method not found: {$method}"),
        };
    }

    private static function ok($id, $result): array { return ['jsonrpc' => '2.0', 'id' => $id, 'result' => $result]; }
    private static function err($id, int $c, string $m): array {
        return ['jsonrpc' => '2.0', 'id' => $id, 'error' => ['code' => $c, 'message' => $m]];
    }
}
```

### 10.4 McpController (resource endpoint)
```php
<?php declare(strict_types=1);
namespace OwnPay\Controller\Api;

use OwnPay\Container;
use OwnPay\Http\{Request, Response};
use OwnPay\Mcp\{McpServer, McpContext};
use OwnPay\Service\System\AuditLogger;

final class McpController
{
    public function __construct(private Container $c, private McpServer $server) {}

    public function handle(Request $req): Response
    {
        $ctx = new McpContext(
            merchantId: (int)$req->getAttribute('merchant_id'),
            userId:     (int)$req->getAttribute('mcp_user_id'),
            scopes:     (array)$req->getAttribute('mcp_scopes'),
            ip:         $req->header('x-forwarded-for') ?: ($_SERVER['REMOTE_ADDR'] ?? ''),
            userAgent:  $req->header('user-agent') ?? '',
        );

        $msg = $req->json();                       // already size-capped by middleware
        if (!is_array($msg)) {
            return Response::json(['jsonrpc' => '2.0', 'id' => null,
                'error' => ['code' => -32700, 'message' => 'Parse error']], 400);
        }

        $resp = $this->server->dispatch($msg, $ctx);

        if (($msg['method'] ?? '') === 'tools/call') {
            $this->c->get(AuditLogger::class)->log(
                $ctx->merchantId, $ctx->userId, 'mcp.tool.call', 'mcp_tool',
                0, null, ['tool' => $msg['params']['name'] ?? null], $ctx->ip
            );
        }
        return $resp === null ? Response::empty(202) : Response::json($resp, 200);
    }
}
```

### 10.5 McpResourceMiddleware (auth + kill switch + context)
```php
<?php declare(strict_types=1);
namespace OwnPay\Middleware;

use OwnPay\Http\{Request, Response};
use OwnPay\Repository\{OAuthTokenRepository, SettingsRepository};

final class McpResourceMiddleware
{
    public function __construct(
        private OAuthTokenRepository $tokens,
        private SettingsRepository $settings,
        private string $mcpResourceUri          // canonical https://<host>/api/v1/mcp
    ) {}

    public function handle(Request $request, callable $next): Response
    {
        $token = $request->bearerToken();
        if ($token === null || !str_starts_with($token, 'ompmcp_')) {
            return $this->challenge();           // 401 + WWW-Authenticate → resource metadata
        }
        $prefix = substr($token, 7, 12);
        $row = $this->tokens->findActiveAccessByPrefix($prefix);
        if ($row === null || !hash_equals($row['token_hash'], hash('sha256', $token))) {
            return $this->challenge();
        }
        if ($row['revoked_at'] !== null || \OwnPay\Support\DateHelper::isPast($row['expires_at'])) {
            return $this->challenge();
        }
        if ($row['resource'] !== $this->mcpResourceUri) {           // audience binding (RFC 8707)
            return Response::json(['error' => 'invalid_audience'], 401);
        }
        $mid = (int)$row['merchant_id'];
        if ($this->settings->getScoped('mcp', 'enabled', $mid, '0') !== '1') {
            return Response::json(['error' => 'mcp_disabled'], 404); // kill switch
        }

        $request->setAttribute('merchant_id', $mid);
        $request->setAttribute('mcp_user_id', (int)$row['user_id']);
        $request->setAttribute('mcp_scopes', json_decode((string)$row['scopes'], true) ?: []);
        $this->tokens->touchLastUsed((int)$row['id']);

        return $next($request);
    }

    private function challenge(): Response
    {
        return Response::json(['error' => 'unauthorized'], 401, [
            'WWW-Authenticate' => 'Bearer resource_metadata="' . $this->mcpResourceUri
                . '/.well-known/oauth-protected-resource"',
        ]);
    }
}
```

### 10.6 OAuth token endpoint — PKCE + rotation (essentials)
```php
// OAuthController::token()  (group: api-public)
$code = (string)$req->json('code');
$verifier = (string)$req->json('code_verifier');
$row = $this->codes->findValidByHash(hash('sha256', $code)); // not used, not expired
if ($row === null) return Response::apiError('invalid_grant', 'bad code', null, 400);

// PKCE S256: BASE64URL(SHA256(verifier)) === stored challenge
$calc = rtrim(strtr(base64_encode(hash('sha256', $verifier, true)), '+/', '-_'), '=');
if (!hash_equals($row['code_challenge'], $calc)) {
    return Response::apiError('invalid_grant', 'PKCE failed', null, 400);
}
if ((string)$req->json('resource') !== $row['resource']) {       // audience must match
    return Response::apiError('invalid_target', 'resource mismatch', null, 400);
}
$this->codes->markUsed((int)$row['id']);                          // single-use

$access  = $this->oauth->mintToken('access',  $row, (int)$this->settings->get('mcp','token_ttl','3600'));
$refresh = $this->oauth->mintToken('refresh', $row, (int)$this->settings->get('mcp','refresh_ttl','2592000'));
return Response::json([
    'access_token' => $access, 'refresh_token' => $refresh,
    'token_type' => 'Bearer', 'expires_in' => 3600, 'scope' => implode(' ', json_decode($row['scopes'], true)),
]);
// refresh_token grant: validate refresh, REVOKE it (rotation), mint a new pair; reuse of a revoked refresh → revoke whole chain.
```

### 10.7 DI registration (`config/services.php`)
```php
$c->singleton(\OwnPay\Mcp\ToolRegistry::class, static function (\OwnPay\Container $c) {
    $r = new \OwnPay\Mcp\ToolRegistry();
    foreach ([
        \OwnPay\Mcp\Tools\InvoiceCreateTool::class,
        \OwnPay\Mcp\Tools\InvoiceListTool::class,
        \OwnPay\Mcp\Tools\PaymentLinkCreateTool::class,
        \OwnPay\Mcp\Tools\CustomerSearchTool::class,
        \OwnPay\Mcp\Tools\TransactionSearchTool::class,
        // ... all allowlisted tools (NO refund.create / payment.* / api-key tools exist)
    ] as $cls) {
        $r->register(new $cls($c));
    }
    return $r;
});
$c->singleton(\OwnPay\Mcp\McpServer::class, fn($c) => new \OwnPay\Mcp\McpServer($c->get(\OwnPay\Mcp\ToolRegistry::class)));
```

### 10.8 Routes + middleware group
```php
// config/routes/api.php
$router->post('/api/v1/mcp',                              'Api\\McpController@handle', 'mcp');
$router->get ('/.well-known/oauth-protected-resource',   'Api\\OAuthController@protectedResourceMeta', 'api-public');
$router->get ('/.well-known/oauth-authorization-server', 'Api\\OAuthController@authServerMeta',         'api-public');
$router->post('/oauth/token',                            'Api\\OAuthController@token',                  'api-public');
$router->post('/oauth/register',                         'Api\\OAuthController@register',               'api-public');
$router->get ('/oauth/authorize',                        'Api\\OAuthController@authorize',              'web');
$router->post('/oauth/authorize',                        'Api\\OAuthController@consent',                'web');

// config/middleware.php
'mcp' => [
    \OwnPay\Middleware\CorsMiddleware::class,
    \OwnPay\Middleware\RateLimiterMiddleware::class,
    \OwnPay\Middleware\McpResourceMiddleware::class,   // replaces BearerAuth — OAuth tokens, not API keys
    \OwnPay\Middleware\IdempotencyMiddleware::class,
],
```

### 10.9 CI guard test (the no-loss tripwire)
```php
public function test_registry_refuses_forbidden_tools(): void
{
    $r = new \OwnPay\Mcp\ToolRegistry();
    $this->expectException(\LogicException::class);
    $r->register(new class implements \OwnPay\Mcp\Tool {
        public function name(): string { return 'refund.create'; }   // must be rejected
        public function title(): string { return 'x'; }
        public function description(): string { return 'x'; }
        public function scope(): string { return 'mcp:refunds'; }
        public function inputSchema(): array { return ['type' => 'object']; }
        public function handle(array $a, \OwnPay\Mcp\McpContext $c): array { return []; }
    });
}
```

---

## 11. Client integration

### 11.1 Native remote (clients that support remote MCP + OAuth)
Point the client at `https://<host>/api/v1/mcp`. It discovers the AS via `/.well-known/oauth-protected-resource`, runs the OAuth 2.1 + PKCE flow (§5.2), and stores the access/refresh tokens.

### 11.2 stdio-only clients (e.g. Claude Desktop) via `mcp-remote`
```json
{
  "mcpServers": {
    "ownpay": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "https://pay.example.com/api/v1/mcp"]
    }
  }
}
```
`mcp-remote` opens a browser for the OAuth consent, then bridges stdio↔HTTP. No API key, secret, or `.env` value is ever placed in client config.

### 11.3 Testing client
Use **MCP Inspector** (`npx @modelcontextprotocol/inspector`) to run `initialize` → `tools/list` → `tools/call` and to exercise the OAuth flow.

---

## 12. Verification & test plan

**Protocol**
- `initialize` returns the negotiated `protocolVersion` + `tools` capability; `ping` → `{}`.
- `tools/list` returns **only** allowlisted tools the token's scopes permit.
- `tools/call` with an unregistered/forbidden name (e.g. `refund.create`) → `isError`/method-not-found; the tool does not exist.

**OAuth / security**
- Full code→token flow succeeds with PKCE S256; a wrong `code_verifier` → `invalid_grant`.
- A token with `resource` ≠ MCP URI → `401 invalid_audience`.
- Expired or revoked token → `401`; refresh rotation invalidates the old refresh; reuse → chain revoked.
- `mcp.enabled=0` (global or brand) → `/api/v1/mcp` returns `404` and `/oauth/authorize` refuses.

**Safety / isolation**
- **Deny-list CI test** (§10.9) is red if any forbidden tool is ever registered.
- **Tenant-isolation test:** a token bound to brand A calling `transaction.get` for a brand-B trx returns not-found (handler uses `forTenant`).
- **Audit:** every `tools/call`, token issuance, and consent writes an `op_audit_logs` row (HMAC-signed).
- **Rate limit:** exceeding `mcp.rate_limit_per_min` → `429`.

**Tooling**
- `php -l` clean on all new files; PHPStan L9 clean; the migration applies to a fresh DB and an existing DB.

---

## 13. Risk register / future work
| Item | Note |
|---|---|
| SSE streaming | Off by default (PHP-FPM friction). Add later if a tool needs progressive output. |
| JWT access tokens | Opaque+DB chosen for instant revocation; JWT is a future option if introspection cost matters. |
| Fine-grained per-tool scopes | v1 groups scopes by domain; can split to per-tool scopes later. |
| Multi-user / staff consent | v1 is owner-centric; extend consent + token binding for staff roles later. |
| Bulk PII exfiltration | Mitigated by pagination caps + audit; revisit field-level masking if requirements change (currently full PII per decision). |
| Write-tool abuse (spam invoices) | Rate limit + idempotency + audit; consider per-tool quotas. |

---

## 14. Summary
A native, OAuth 2.1-secured MCP server that lets the owner's AI assistant **create invoices, payment links and customers, and read transactions/reports/balance** — and **provably cannot** refund, take or verify payments, touch API keys, or cross tenant boundaries. Safety is guaranteed by a **deny-by-default tool registry + hard deny-list + CI tripwire**, layered with OAuth scopes and `forTenant` isolation, and gated by an **admin kill switch**. Build it in the seven phases of §9; verify with §12.
