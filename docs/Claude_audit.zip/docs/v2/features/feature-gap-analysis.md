# OwnPay — Feature Gap Analysis (scope‑accurate)

> **Date:** 2026‑05‑31. Evidence‑based review of what's missing, dead, or improvable — **bounded to OwnPay's actual job.** Items the owner confirmed belong to the *merchant* are explicitly parked in §1 so they aren't re‑raised.

## 0. Operating model (the lens for everything below)
**OwnPay is a single‑owner, multi‑brand payment‑gateway _aggregator / orchestrator_.** It connects many payment gateways (+ MFS / SMS‑matching on a paired phone) in one place and **processes & routes payments**. Consequences:
- **Funds land directly in the owner's own accounts.** OwnPay does **not** hold, settle, or pay out funds — the owner handles cash‑out himself.
- **All business & customer concerns live on the merchant site**, not in OwnPay: customer order history, discounts/coupons/vouchers, installments, customer‑facing emails/receipts/analytics, subscription scheduling.
- **OwnPay's responsibilities are narrow and deep:** process/verify/match payments across gateways, isolate brands, expose a clean API + webhooks for the merchant to integrate, stay secure, and self‑update.

## 1. Explicitly OUT OF SCOPE (parked — do not build into OwnPay)
| Previously flagged | Why it's NOT OwnPay's job |
|---|---|
| Settlement / payout / withdrawal ledgering | Single‑owner; money arrives in the owner's account directly; cash‑out is the owner's, off‑platform. |
| Customer self‑service portal / order history | The customer checks history on the **merchant** website. |
| Coupons / vouchers / discount codes | Pricing/promotions are **merchant** business logic. OwnPay only processes the final amount. |
| Installment plans | OwnPay aggregates gateways; it isn't a lender/BNPL provider. Installments are a merchant/gateway product. |
| Customer emails / receipts / analytics mail | Customer communication is the **merchant's** job (OwnPay just fires the webhook/event the merchant acts on). |
| Subscription/billing **scheduling** | The merchant owns the schedule and calls OwnPay's API when a charge is due (see §3 for the one in‑scope primitive: tokenization/mandates). |
| "Test suite can't run (PHP 8.2)" | **False positive.** Tests run on a separate PHP **8.3** build machine. Not a gap. |

> Net effect: §1 removes settlement, customer portal, coupons, installments, customer email, and the test‑suite "gap" from the backlog.

---

## 2. Important features that are MISSING / broken (in‑scope, prioritized)

### 2a. Confirmed defects (fix first — they're broken, not just absent)
| Item | Impact | Evidence |
|---|---|---|
| **Internal alerting is non‑functional** | `AlertService` reads/writes `op_alerts`, but that table **doesn't exist** → operational/security/balance‑discrepancy alerts silently fail. Critical for an unattended money router. | `op_alerts` absent from `schema.sql`; `AlertService` references it (FIND‑S1). |
| **Queue worker points at a missing table** | Background jobs that run through the DB worker break ("table not found") → async webhooks/notifications/maintenance degrade. (A `Redis`/`File` queue layer *does* exist; this is the DB worker name mismatch.) | Schema has `op_queue_jobs`; `QueueWorkerJob` queries `op_job_queue` (FIND‑S2). |
| **Gateway fleet is not trustworthy** | The aggregator's *entire purpose* is processing money through gateways — yet many adapters are stubs/simulations and some accept `mock_` tokens or `return true` from `verifyWebhook()` in live mode. | FIND‑004/005; ~24 of ~140 adapters have no real HTTP call. |
| **`Database::getInstance()` throws in prod** | Refunds and gateway callbacks (mark‑paid) hit a service‑locator that isn't initialized → those paths fail at runtime. | FIND‑003 (empirically verified earlier). |

### 2b. Genuinely missing aggregator capabilities (the core value‑add of "many gateways in one place")
| Item | Why it fits OwnPay (payment processing, not merchant logic) | Status |
|---|---|---|
| **Automatic gateway routing + failover** | Today a gateway is **picked manually at checkout**. An aggregator's signature feature is routing a payment to the best gateway (by method/currency/brand/success‑rate/cost) and **failing over** when one is down. | No router/selector/failover engine found (only the HTTP `Router`, webhook *retry*, and the mock *fallback*). |
| **Gateway health monitoring + circuit breaker + auto‑disable** | Track each gateway's success/error rate; auto‑disable a failing gateway and alert the owner. Pure ops/reliability of the payment layer. | No `success_rate`/`auto‑disable`/circuit‑breaker logic found. Ties directly to fixing 2a alerting. |

> 2b items are *enhancements*, not defects — manual gateway selection may be acceptable today. But for "connect multiple gateways at one place," routing + health are the highest‑leverage in‑scope additions.

---

## 3. Good‑to‑have, MISSING (in‑scope, payment‑processing only)
- **Tokenization / saved‑mandate (merchant‑initiated transactions)** — the *one* subscription‑adjacent primitive that **is** OwnPay's job: let the merchant securely re‑charge later via a token, so the **merchant** can build subscriptions/retries on top. (No `tokenize`/`vault`/`mandate` found in core.)
- **3‑D Secure / SCA orchestration** for the card gateways — handle the challenge/redirect flow uniformly across adapters. (No 3DS/SCA layer found.)
- **Fuller REST API surface** — the services exist but the public API exposes only payments/transactions/refunds/customers/api‑keys/webhooks. Add **invoices, payment‑links, disputes, reports** endpoints so the merchant can integrate the whole platform (see §5).
- **OpenAPI spec + a thin SDK or Postman collection** — developer experience for the merchant integrating OwnPay.
- **Per‑gateway sandbox/test mode + a unified test‑charge harness** — let the merchant verify each connected gateway end‑to‑end safely.
- **Webhook event normalization + replay + dead‑letter view** — give the merchant one consistent event schema across all gateways, with replay. (Retry already exists — see §5.)
- **Native MCP server** — already designed (`mcp.md`) and given a build runbook (`mcp-implementation-plan.md`).

---

## 4. Present but USELESS / dead weight (remove or wire)
| Item | Status | Action |
|---|---|---|
| `op_maintenance_locks`, `op_plugin_settings` | Dead tables, zero code refs (FIND‑020) | Drop, or wire if intended. |
| `op_queue_jobs` (table) | Orphaned — worker uses `op_job_queue` | Reconcile to one name (fixes 2a queue defect). |
| `MfsService` | Orphaned dead code with a parser arg‑swap bug; never called (FIND‑001) | Delete, or fix‑and‑wire if the non‑device MFS path is ever needed. |
| `TransactionRepository::findPendingMatchGlobal`, `getGlobalBrandBreakdown` | Unscoped (cross‑brand) methods; the global matcher is dead and a leak risk (FIND‑013) | Remove the dead unscoped matcher. |
| **Inflated "140 gateways" catalog** | Many adapters are stubs/`mock_` simulations | Implement, or clearly mark/disable non‑functional adapters so the catalog is honest (overlaps 2a + §5). |

---

## 5. Present but mediocre → good with improvement (in‑scope)
- **Gateway fleet integrity (security‑critical):** gate every `mock_` path to non‑live, implement real `verifyWebhook`/`refund`, add an abstract base + a CI conformance test (FIND‑004/005). Turn "140 listed" into "N that actually work."
- **Refund flow:** correct, but it holds the external gateway HTTP call **inside** the DB transaction with a row lock → restructure as a saga (reserve → call gateway outside txn → finalize) (FIND‑002).
- **Public REST API completeness:** expose invoices / payment‑links / disputes / reports (services already exist) so the merchant can drive the full platform programmatically.
- **SMS / MFS matching:** OwnPay's `OP‑xxxx` trx_id and the MFS provider TrxID are different namespaces, so `findByTrxId` rarely matches and it leans on amount‑only matching → capture the customer‑entered provider TrxID and key matching on it (FIND‑016/017).
- **Resilience knobs:** rate limiter fails **open** on DB outage (fail closed for auth/pairing — FIND‑007); plugin sandbox treats null as allow (default‑deny — FIND‑009); SSRF guard is IPv4‑only with a DNS‑rebind TOCTOU window (FIND‑008).
- **Webhook delivery:** retry exists (`WebhookRetryCron`); improve with exponential backoff + a dead‑letter view so the merchant sees stuck deliveries.
- **Reconciliation & disputes:** `ReconciliationService` + `DisputeService`/`op_disputes` exist — flesh them into full workflows (gateway‑report matching, dispute states + evidence) so they're usable, not skeletal.

---

## 6. What OwnPay already does well (so we don't "fix" non‑problems)
Confirmed present and appropriate to the model: double‑entry **ledger** (`op_ledger_accounts/transactions/entries`), **fees** (`op_fee_rules`/`FeeService`), **idempotency** (`op_idempotency_keys`/middleware), **multi‑currency + FX** (`op_currencies`/`op_exchange_rates`/`CurrencyService`), **disputes** + **reconciliation** services, **webhooks** in/out with retry, **mail/SMS provider abstraction** (`MailProviderInterface`/`SmsProviderInterface`/`op_comm_log` — used for *owner/merchant* notifications, correctly not customer‑facing), **multi‑brand isolation + custom domains + theming**, **2FA/Argon2id/CSRF/CSP/rate‑limit**, **self‑update** (signed manifest + migrations), **plugins/events**, and the **mobile companion** (device pairing + SMS push + notifications).

---

## 7. Confidence & method
- **Confirmed** (schema + service inventory + prior audit): everything in §2a, §4, §5, §6, and the §2b/§3 "not found" claims (verified by `schema.sql` table list, `src/Service` inventory, and targeted greps for routing/failover/health/tokenization/3DS this session).
- **Judgement calls** (priority/ordering of §2b and §3) are recommendations, not defects.
- §1 reflects the owner's explicit scope corrections (2026‑05‑31).

### Suggested order of work
1. **Fix the confirmed defects (2a):** `op_alerts`, the queue table name, gateway `mock_`/verify security, `Database` DI.
2. **API completeness (§5)** so merchants integrate the whole platform.
3. **Aggregator value‑adds (2b → §3):** gateway health + routing/failover, then tokenization/mandates and 3DS/SCA.
4. **Cleanup (§4)** and the resilience knobs (§5).
