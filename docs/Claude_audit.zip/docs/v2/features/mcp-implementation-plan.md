# OwnPay MCP Server — AI Implementation Runbook (Zero‑Mistake Build Guide)

> **Audience:** an AI model that will *build* the MCP server described in [`mcp.md`](./mcp.md). That document is the **design/why**; **this document is the exact how** — an ordered, copy‑paste runbook.
> **Mandate:** after you finish, **every existing feature must still work** and **every new option must be fully functional**. Mistakes are not acceptable. When anything is unclear, you **STOP and verify against the real code** — never guess.
> **All APIs, signatures, table patterns, and conventions in this runbook were verified against the live codebase.** Where a detail must be re‑confirmed on your machine, the step says **VERIFY** and tells you exactly what to check.

---

## 0. READ THIS FIRST — Rules of Engagement (Prime Directives)

You MUST obey every rule below. They are ordered; rule 1 is the most important.

### 0.1 The hard rules (non‑negotiable)
1. **Never enable a money‑moving or secret action.** Do **not** create, call, wrap, or register any tool that touches: `RefundService::create`, `GatewayApiService::initiatePayment`, `GatewayApiService::handleCallback`, `CheckoutController::submitVerification`/`handleCallback`, `ApiKeyService` (any method), `op_api_keys` (any read/write), `TransactionRepository::findPendingMatchGlobal`, `TransactionRepository::getGlobalBrandBreakdown`, ledger writes, settings/user/role mutation, or gateway secrets. If you are unsure whether something moves money, **treat it as forbidden**.
2. **Additive only on shared files.** When editing `config/routes/api.php`, `config/middleware.php`, `config/services.php`, `database/schema.sql`: **add lines, never delete or rewrite existing lines.** Insert at the marked anchors.
3. **Every DB read/write is tenant‑scoped.** Use `->forTenant($merchantId)` (the `TenantScope` trait) for all merchant data. Never call an unscoped query for merchant data.
4. **No scalar constructor parameters in any class the container builds** (middleware, controllers, services, repos). The DI container autowires *class* dependencies but **throws on a primitive/string parameter that has no default** (`src/Container.php` line ~284: *"Cannot resolve primitive parameter"*). Read scalars from env/config **inside** the method instead. (See 0.3.)
5. **Verify after every step.** Run the step's **CHECK** command. If it fails, fix before continuing. Do not batch‑create files and verify at the end.
6. **3‑strike rule.** If the same step fails 3 times, **stop** and write what you tried + the exact error into `output/change-log/` and surface it. Do not thrash.
7. **Do not modify any file outside the explicit file list** in this runbook (plus the working artifacts in §0.7).
8. **No new Composer/npm dependencies.** Everything here uses only PHP standard library + existing project code. (The release ships `vendor` with `--no-dev`; adding deps can break the build.)
9. **Preserve security middleware.** Never remove a middleware from a group. The MCP endpoint must keep `global` + the new `mcp` group.
10. **Fail closed.** On any auth/validation doubt, return an error (401/403/JSON‑RPC error), never a success.
11. **Snapshot before editing an existing file** (copy to `output/snapshots/<name>.before-<UTCstamp>.<ext>`).
12. **Log your work** (CLAUDE.md policy) — a timestamped entry in `output/change-log/` per phase.

### 0.2 Framework conventions you MUST follow (verified)
These are the **real** APIs. Use them exactly.

**`OwnPay\Http\Request`** (`src/Http/Request.php`):
- `json(?string $key=null, mixed $default=null): mixed` — decoded JSON body (cached). `json()` → full array.
- `bearerToken(): ?string` — token after `Authorization: Bearer `.
- `header(string $key, string $default=''): string` — case‑insensitive.
- `param(string $key, string $default=''): string` — route param like `{id}`.
- `getAttribute(string $key, mixed $default=null)` / `setAttribute(string $key, mixed $value)` — middleware context (this is how `merchant_id` flows to controllers).
- `method(): string`, `ip(): string`, `userAgent(): string`, `host(): string`, `scheme(): string`, `query()`, `post()`, `input()`.

**`OwnPay\Http\Response`** (`src/Http/Response.php`) — all static factories return a `Response`:
- `Response::json(array|object $data, int $status=200, array $headers=[]): self` (auto‑adds `Content-Type: application/json` + `X-API-Version`).
- `Response::apiSuccess(mixed $data=null, ?array $meta=null, int $status=200, array $headers=[]): self` → `{ "success": true, "data": ..., "meta": ... }`.
- `Response::apiError(string $code, string $message, ?string $field=null, int $status=400, array $headers=[]): self` → `{ "success": false, "error": ..., "errors": [...], "request_id": ... }`.
- `Response::empty(int $status=204)`, `Response::redirect(string $url, int $status=302)`, `Response::html(string,int)`, `->withHeader(string,string)`.

**Container** (`src/Container.php`): `singleton(string, Closure)`, `bind(string, Closure)`, `get(string)`, `has(string)`, `alias(string,string)`. Autowires unregistered classes by constructor type‑hints; injects itself for a `Container` param.

**Middleware contract** (mirror `src/Middleware/BearerAuthMiddleware.php`):
```php
final class XMiddleware {
    public function __construct(private \OwnPay\Container $container) {}   // ONLY Container
    public function handle(\OwnPay\Http\Request $request, callable $next): \OwnPay\Http\Response {
        // ... resolve services via $this->container->get(...) ...
        return $next($request);                 // continue, OR return Response to short‑circuit
    }
}
```
Kernel resolves middleware via `container->get($class)` with `new $class($container)` fallback (`src/Kernel.php` ~352). **A middleware listed in a group but whose class is missing throws a fatal** — so the class + namespace + autoload must be correct.

**Controller contract** (mirror `src/Controller/Api/HealthController.php`):
```php
final class XController {
    public function __construct(private \OwnPay\Container $c) {}
    public function method(\OwnPay\Http\Request $req): \OwnPay\Http\Response {
        $mid = (int) $req->getAttribute('merchant_id');
        // ... $this->c->get(SomeService::class) ...
        return \OwnPay\Http\Response::apiSuccess([...]);
    }
}
```
Routes map `'Api\\XController@method'` → class `OwnPay\Controller\Api\XController`.

**Repository contract** (mirror `src/Repository/ApiKeyRepository.php` + `BaseRepository.php`):
- Extend `BaseRepository`, `use TenantScope;`, set `protected string $table` and `protected array $fillable`.
- DB access: `$this->db->fetchOne($sql,$params)`, `fetchAll`, `fetchColumn`, `insert($sql,$params)` (returns id), `update($sql,$params)` (rows), `delete`, `exists`, `count`.
- Inherited writes: `$this->create($data)` (INSERT, returns id, filtered by `$fillable`), `$this->update($id,$data)`, `$this->delete($id)`.
- TenantScope: `->forTenant($mid)`, `requireTenant()`, `createScoped($data)`, `updateScoped($id,$data)`, `findScoped($id)`, `paginateScoped(...)`.

### 0.3 The autowire trap (the #1 way to break this build)
A class the container builds **cannot** have a constructor like `__construct(string $uri)` or `__construct(SomeRepo $r, int $ttl)` — the scalar (`$uri`, `$ttl`) makes autowiring **throw**. Two safe patterns:
- **Preferred:** constructor takes only `Container $c` (or only class deps); read scalars inside the method from `getenv()` / `config.app` / the request.
- **If you truly need a configured object:** register it explicitly in `config/services.php` with a factory closure that supplies the scalar.
In this runbook, **all middleware/controllers take only `Container $c`**, and we register `ToolRegistry` + `McpServer` explicitly. Follow that and you will not hit the trap.

### 0.4 Reference files to imitate (open them when unsure)
| Need | Mirror this file |
|---|---|
| Middleware shape + token hashing | `src/Middleware/BearerAuthMiddleware.php` |
| Controller shape | `src/Controller/Api/HealthController.php` |
| Repository (hashed credential) | `src/Repository/ApiKeyRepository.php` |
| Repository base/CRUD/TenantScope | `src/Repository/BaseRepository.php`, `src/Repository/TenantScope.php` |
| Service registration style | `config/services.php` |
| Safe domain services (signatures) | `src/Service/Payment/InvoiceService.php`, `PaymentLinkService.php`, `src/Service/Customer/CustomerPiiService.php`, `src/Repository/TransactionRepository.php` |
| Settings read/write | `src/Repository/SettingsRepository.php` |
| Audit write | `src/Service/System/AuditLogger.php` |

### 0.5 How to run checks on this machine (Windows / XAMPP)
- Syntax: `& "C:\xampp\php\php.exe" -l "C:\xampp\htdocs\<path>.php"` → must print `No syntax errors detected`.
- All new files at once (PowerShell): loop `php -l` over the new files; **every** file must pass.
- Tests: `& "C:\xampp\php\php.exe" "C:\xampp\htdocs\vendor\bin\phpunit" --filter <TestName>`.
  - **Known constraint (audit FIND‑006):** PHPUnit `^12.5` needs PHP 8.3; this box is 8.2, so PHPUnit may not run here. Still **write** the tests; run them on the 8.3 build machine, or temporarily verify logic with a throwaway script in `output/` (delete it after).
- Static analysis (if available): `& "C:\xampp\php\php.exe" "C:\xampp\htdocs\vendor\bin\phpstan" analyse --level=9 src/Mcp src/Service/OAuth` → 0 errors.

### 0.6 Naming + IDs
- MCP token format: **`ompmcp_<12hex>.<64hex>`** (deliberately different from API keys' `op_…`).
- Scopes: `mcp:invoices`, `mcp:payment_links`, `mcp:customers`, `mcp:transactions:read`, `mcp:reports`, `mcp:balance:read`, `mcp:refunds:read`.
- Settings group: `mcp` (`enabled`, `rate_limit_per_min`, `token_ttl`, `refresh_ttl`).

### 0.7 Working artifacts (allowed extra writes)
`output/change-log/*.md`, `output/snapshots/*`, and (optionally) throwaway probes in `output/` that you delete. Nothing else outside the file list.

---

## 1. Phase −1 — PRE‑FLIGHT VERIFICATION (do not skip)

**Goal:** confirm the assumptions this runbook is built on, on *your* copy of the code, before writing anything.

**Step 1.1 — Read these files fully and confirm the signatures:**
- `src/Http/Request.php`, `src/Http/Response.php` → confirm methods in §0.2 exist with those signatures.
- `src/Container.php` → confirm `singleton/get` and the autowire‑throws‑on‑scalar behavior.
- `src/Kernel.php` (around lines 240–368) → confirm `runMiddleware` resolves middleware via `container->get()` and `Router::dispatch($handler, $req)` runs the controller.
- `config/middleware.php`, `config/routes/api.php`, `config/services.php` → confirm the structure shown in this runbook.
- `src/Repository/BaseRepository.php`, `TenantScope.php`, `ApiKeyRepository.php` → confirm `create/update/findByPrefix/forTenant/createScoped/updateScoped`.
- `src/Core/Database.php` → confirm `fetchOne/fetchAll/fetchColumn/insert/update/delete` signatures (this runbook uses these names).

**Step 1.2 — Confirm the safe domain service signatures you will call** (open each; if a signature differs, adapt your tool handler to the real one — do NOT force the runbook's version):
- `InvoiceService::create(int $merchantId, array $data): array` and `update(int $merchantId, int $id, array $data): array`.
- `PaymentLinkService::create(int $merchantId, array $data): array`, `update(...)`, `listForMerchant(int $merchantId)`, `find(int $merchantId, int $id)`.
- `CustomerPiiService::create(int $merchantId, array $data): array`, `update(...)`, `get(int $merchantId, int $id)`, `findByContact(int $merchantId, string $identifier)`, `list(int $merchantId, int $page, int $perPage)`.
- `TransactionRepository`: `listFiltered(array $filters, int $limit, int $offset)`, `countFiltered(array $filters)`, `findScoped($id)`, `findByTrxId(string)`, `stats(string $from, string $to)`, `getTodayStats(int $merchantId)`, `getReportData(int,$from,$to,?gw)`, `getExportData(...)`. (All via `->forTenant($mid)` where scoped.)
- For **balance**: open `src/Service/**` for the ledger balance accessor (e.g. a `LedgerService`/`LedgerRepository` method that returns the merchant payable balance). **Record the exact method**; the `balance.get` tool will call it. If none exists, compute from `TransactionRepository::stats()` and clearly label it "approximate" — do **not** write to the ledger.
- For **how the admin session identifies the logged‑in user + active brand** (needed by the OAuth consent screen): open `src/Middleware/SessionMiddleware.php` + the admin auth (`src/Service/Auth/*` / how `$_SESSION` stores the user id / `BrandContext`). **Record exactly** how to get `current user_id` and `active merchant_id`. The consent step reuses this — never invent a new session scheme.

**Step 1.3 — Confirm router can serve dotted paths** (`/.well-known/oauth-authorization-server`). Grep `src/Http/Router.php` for how patterns are matched. If literal dots are fine (they usually are), proceed. If not, register the metadata under a route the router accepts and have `protectedResourceMeta` point to it.

**Step 1.4 — Snapshot the 4 shared files** you will edit:
```
output/snapshots/middleware.before-<stamp>.php
output/snapshots/api.before-<stamp>.php           (config/routes/api.php)
output/snapshots/services.before-<stamp>.php
output/snapshots/schema.before-<stamp>.sql
```

**CHECK 1:** You can state, in one sentence each, the real signatures of the services in 1.2, and how to get the logged‑in user in 1.3. If you cannot, re‑read before coding.

---

## 2. Phase 0 — Database tables + settings

**Create** `update/releases/<next-version>/migrations/2026XXXX_mcp_oauth.sql` **and** append the same DDL to `database/schema.sql` (additive, at the end, before any trailing `COMMIT`/footer):

```sql
-- ===== MCP / OAuth 2.1 (additive) =====
CREATE TABLE IF NOT EXISTS op_oauth_clients (
  id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  client_id          VARCHAR(64)  NOT NULL,
  client_name        VARCHAR(150) NOT NULL,
  client_secret_hash VARCHAR(255) NULL,
  redirect_uris      JSON         NOT NULL,
  type               ENUM('public','confidential') NOT NULL DEFAULT 'public',
  status             ENUM('pending','active','disabled') NOT NULL DEFAULT 'pending',
  created_by         BIGINT UNSIGNED NULL,
  created_at         DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_oauth_client (client_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS op_oauth_auth_codes (
  id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  code_hash         VARCHAR(255) NOT NULL,
  client_id         VARCHAR(64)  NOT NULL,
  merchant_id       BIGINT UNSIGNED NOT NULL,
  user_id           BIGINT UNSIGNED NOT NULL,
  scopes            JSON         NOT NULL,
  code_challenge    VARCHAR(128) NOT NULL,
  code_challenge_method ENUM('S256') NOT NULL DEFAULT 'S256',
  redirect_uri      VARCHAR(500) NOT NULL,
  resource          VARCHAR(255) NOT NULL,
  expires_at        DATETIME(6)  NOT NULL,
  used_at           DATETIME(6)  NULL,
  created_at        DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_oauth_code (code_hash),
  KEY idx_oauth_code_client (client_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS op_oauth_tokens (
  id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  token_prefix      VARCHAR(12)  NOT NULL,
  token_hash        VARCHAR(255) NOT NULL,
  type              ENUM('access','refresh') NOT NULL,
  client_id         VARCHAR(64)  NOT NULL,
  merchant_id       BIGINT UNSIGNED NOT NULL,
  user_id           BIGINT UNSIGNED NOT NULL,
  scopes            JSON         NOT NULL,
  resource          VARCHAR(255) NOT NULL,
  parent_token_id   BIGINT UNSIGNED NULL,
  last_used_at      DATETIME(6)  NULL,
  expires_at        DATETIME(6)  NOT NULL,
  revoked_at        DATETIME(6)  NULL,
  created_at        DATETIME(6)  NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (id),
  UNIQUE KEY uq_oauth_token_prefix (token_prefix),
  KEY idx_oauth_token_merchant (merchant_id, type),
  KEY idx_oauth_token_lookup (token_prefix, type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO op_system_settings (group_name, key_name, value, type, merchant_id) VALUES
  ('mcp','enabled','0','bool',NULL),
  ('mcp','rate_limit_per_min','60','int',NULL),
  ('mcp','token_ttl','3600','int',NULL),
  ('mcp','refresh_ttl','2592000','int',NULL)
ON DUPLICATE KEY UPDATE value = value;
```

**CHECK 2:** Apply the migration to a scratch DB (or the dev DB) and confirm the 3 tables exist and the 4 settings rows are present:
```sql
SHOW TABLES LIKE 'op_oauth_%';                 -- 3 rows
SELECT key_name FROM op_system_settings WHERE group_name='mcp';  -- 4 rows
```

---

## 3. Phase 1 — OAuth 2.1 Authorization Server

### 3.1 Repositories
Create `src/Repository/OAuthClientRepository.php`, `OAuthAuthCodeRepository.php`, `OAuthTokenRepository.php`. They mirror `ApiKeyRepository`. Example (token repo — the others follow the same shape):

```php
<?php declare(strict_types=1);
namespace OwnPay\Repository;

final class OAuthTokenRepository extends BaseRepository
{
    use TenantScope;
    protected string $table = 'op_oauth_tokens';
    protected array $fillable = [
        'token_prefix','token_hash','type','client_id','merchant_id','user_id',
        'scopes','resource','parent_token_id','last_used_at','expires_at','revoked_at',
    ];

    /** Active (non-revoked, non-expired) ACCESS token by prefix. */
    public function findActiveAccessByPrefix(string $prefix): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM {$this->table}
             WHERE token_prefix = :p AND type = 'access'
               AND revoked_at IS NULL AND expires_at > NOW(6) LIMIT 1",
            ['p' => $prefix]
        );
    }

    public function findActiveRefreshByPrefix(string $prefix): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM {$this->table}
             WHERE token_prefix = :p AND type = 'refresh'
               AND revoked_at IS NULL AND expires_at > NOW(6) LIMIT 1",
            ['p' => $prefix]
        );
    }

    public function touchLastUsed(int $id): void
    {
        $this->db->update("UPDATE {$this->table} SET last_used_at = NOW(6) WHERE id = :id", ['id' => $id]);
    }

    public function revoke(int $id): void
    {
        $this->db->update("UPDATE {$this->table} SET revoked_at = NOW(6) WHERE id = :id", ['id' => $id]);
    }

    /** Revoke an entire refresh-rotation chain (reuse detection). */
    public function revokeChain(int $rootId): void
    {
        $this->db->update(
            "UPDATE {$this->table} SET revoked_at = NOW(6)
             WHERE (id = :id OR parent_token_id = :id2) AND revoked_at IS NULL",
            ['id' => $rootId, 'id2' => $rootId]
        );
    }

    public function listActiveForMerchant(int $merchantId): array
    {
        return $this->db->fetchAll(
            "SELECT id, token_prefix, type, client_id, scopes, last_used_at, expires_at, created_at
             FROM {$this->table}
             WHERE merchant_id = :mid AND revoked_at IS NULL AND expires_at > NOW(6)
             ORDER BY created_at DESC",
            ['mid' => $merchantId]
        );
    }
}
```
`OAuthAuthCodeRepository`: add `findValidByHash(string $hash): ?array` (`WHERE code_hash=:h AND used_at IS NULL AND expires_at > NOW(6)`) and `markUsed(int $id)`. `OAuthClientRepository`: add `findByClientId(string $clientId): ?array` and an `active` filter.

### 3.2 `src/Service/OAuth/OAuthServer.php`
Holds the security‑critical logic. Constructor takes only the three repos (all autowirable). No scalars.

```php
<?php declare(strict_types=1);
namespace OwnPay\Service\OAuth;

use OwnPay\Repository\{OAuthClientRepository, OAuthAuthCodeRepository, OAuthTokenRepository};

final class OAuthServer
{
    public function __construct(
        private OAuthClientRepository $clients,
        private OAuthAuthCodeRepository $codes,
        private OAuthTokenRepository $tokens,
    ) {}

    /** Verify PKCE: BASE64URL(SHA256(verifier)) === stored challenge (S256). */
    public function verifyPkce(string $verifier, string $challenge): bool
    {
        $calc = rtrim(strtr(base64_encode(hash('sha256', $verifier, true)), '+/', '-_'), '=');
        return hash_equals($challenge, $calc);
    }

    /** Issue a single-use authorization code (returns the plaintext code). */
    public function issueCode(string $clientId, int $merchantId, int $userId, array $scopes,
                              string $challenge, string $redirectUri, string $resource): string
    {
        $code = bin2hex(random_bytes(32));
        $this->codes->create([
            'code_hash' => hash('sha256', $code),
            'client_id' => $clientId, 'merchant_id' => $merchantId, 'user_id' => $userId,
            'scopes' => json_encode(array_values($scopes)),
            'code_challenge' => $challenge, 'code_challenge_method' => 'S256',
            'redirect_uri' => $redirectUri, 'resource' => $resource,
            'expires_at' => (new \DateTimeImmutable('+60 seconds'))->format('Y-m-d H:i:s.u'),
        ]);
        return $code;
    }

    /** Mint a token row; returns the plaintext token string ompmcp_<prefix>.<secret>. */
    public function mintToken(string $type, array $grant, int $ttlSeconds, ?int $parentId = null): string
    {
        $prefix = bin2hex(random_bytes(6));      // 12 hex chars
        $secret = bin2hex(random_bytes(32));
        $token  = "ompmcp_{$prefix}.{$secret}";
        $this->tokens->create([
            'token_prefix' => $prefix,
            'token_hash'   => hash('sha256', $token),
            'type'         => $type,
            'client_id'    => $grant['client_id'],
            'merchant_id'  => (int) $grant['merchant_id'],
            'user_id'      => (int) $grant['user_id'],
            'scopes'       => is_string($grant['scopes']) ? $grant['scopes'] : json_encode(array_values($grant['scopes'])),
            'resource'     => $grant['resource'],
            'parent_token_id' => $parentId,
            'expires_at'   => (new \DateTimeImmutable("+{$ttlSeconds} seconds"))->format('Y-m-d H:i:s.u'),
        ]);
        return $token;
    }
}
```

### 3.3 `src/Controller/Api/OAuthController.php`
Constructor `Container $c` only. Resolve repos/server/settings inside methods. **The authorize/consent steps reuse the existing admin session** (per Pre‑flight 1.2) to know `user_id` + active `merchant_id`. Build the canonical resource from the request: `$resource = $req->scheme().'://'.$req->host().'/api/v1/mcp';`

Methods:
- `authServerMeta(Request): Response` → `Response::json([... issuer, authorization_endpoint, token_endpoint, registration_endpoint, code_challenge_methods_supported:["S256"], grant_types_supported:["authorization_code","refresh_token"], scopes_supported:[...] ...])`.
- `protectedResourceMeta(Request): Response` → `Response::json(['resource' => $resource, 'authorization_servers' => [ $req->scheme().'://'.$req->host() ]])`.
- `authorize(Request): Response` (group `web`): validate `client_id` (active client), `redirect_uri` (must be in the client's `redirect_uris`), `response_type=code`, `code_challenge`+`code_challenge_method=S256`, `scope` (subset of allowed), `resource` (== the MCP resource). **If the user is not logged in, redirect to the admin login** then back. Render `oauth/consent.twig` with the scope list + the request params (carried as hidden fields).
- `consent(Request): Response` (group `web`, CSRF): on **approve**, call `OAuthServer::issueCode(...)` and `Response::redirect($redirectUri.'?code='.$code.'&state='.$state)`. On **deny**, redirect with `?error=access_denied`.
- `token(Request): Response` (group `api-public`): handle `grant_type=authorization_code` and `grant_type=refresh_token`. See exact security checks below.
- `register(Request): Response` (group `api-public`): RFC 7591 — create an `op_oauth_clients` row with `status='pending'` (admin approves later). Return `client_id` (+ `client_secret` only for confidential clients).

**`token()` — authorization_code grant (security‑critical, copy exactly):**
```php
$server   = $this->c->get(\OwnPay\Service\OAuth\OAuthServer::class);
$codeRepo = $this->c->get(\OwnPay\Repository\OAuthAuthCodeRepository::class);
$settings = $this->c->get(\OwnPay\Repository\SettingsRepository::class);

$grantType = (string) $req->json('grant_type');
$resource  = $req->scheme().'://'.$req->host().'/api/v1/mcp';

if ($grantType === 'authorization_code') {
    $code     = (string) $req->json('code');
    $verifier = (string) $req->json('code_verifier');
    $redirect = (string) $req->json('redirect_uri');
    $row = $codeRepo->findValidByHash(hash('sha256', $code));
    if ($row === null)                                   return Response::apiError('invalid_grant','Invalid or expired code',null,400);
    if (!$server->verifyPkce($verifier, $row['code_challenge'])) return Response::apiError('invalid_grant','PKCE verification failed',null,400);
    if ($redirect !== $row['redirect_uri'])              return Response::apiError('invalid_grant','redirect_uri mismatch',null,400);
    if ((string) $req->json('resource') !== $row['resource']) return Response::apiError('invalid_target','resource mismatch',null,400);
    $codeRepo->markUsed((int) $row['id']);               // single use

    $access  = $server->mintToken('access',  $row, (int) ($settings->get('mcp','token_ttl','3600')));
    $refresh = $server->mintToken('refresh', $row, (int) ($settings->get('mcp','refresh_ttl','2592000')));
    return Response::json([
        'access_token'  => $access,
        'refresh_token' => $refresh,
        'token_type'    => 'Bearer',
        'expires_in'    => (int) $settings->get('mcp','token_ttl','3600'),
        'scope'         => implode(' ', json_decode((string) $row['scopes'], true) ?: []),
    ]);
}
// grant_type === 'refresh_token':
//  - parse prefix = substr(token,7,12); look up active refresh by prefix; hash_equals(token_hash, sha256(token)).
//  - If not found but a matching row exists that is already revoked -> REUSE DETECTED: revokeChain(root) and return invalid_grant.
//  - Else: revoke the old refresh (rotation), mint a new access+refresh pair (carry merchant/user/scopes/resource).
```

### 3.4 `templates/oauth/consent.twig`
Mirror the admin layout. The form **must** POST to `/oauth/authorize` and include the framework CSRF field **named `_csrf_token`** (verified: `CsrfMiddleware` checks `_csrf_token`). Show the granted scopes in plain English **and** the limits: *"This connection cannot issue refunds, take or verify payments, or read API keys."* Carry `client_id`, `redirect_uri`, `state`, `scope`, `code_challenge`, `code_challenge_method`, `resource` as hidden inputs.

### 3.5 Routes (additive — append inside the existing closure in `config/routes/api.php`, before the closing `};`)
```php
    // ======================== OAUTH 2.1 (MCP authorization) ========================
    $router->get('/.well-known/oauth-authorization-server', 'Api\\OAuthController@authServerMeta',        'api-public');
    $router->get('/.well-known/oauth-protected-resource',   'Api\\OAuthController@protectedResourceMeta', 'api-public');
    $router->post('/oauth/token',                           'Api\\OAuthController@token',                 'api-public');
    $router->post('/oauth/register',                        'Api\\OAuthController@register',              'api-public');
    $router->get('/oauth/authorize',                        'Api\\OAuthController@authorize',             'web');
    $router->post('/oauth/authorize',                       'Api\\OAuthController@consent',               'web');
```

**CHECK 3:** `php -l` each new file. Then drive the flow with a script/curl: register a client, hit `/oauth/authorize` (logged in) → get a code, POST `/oauth/token` with the matching `code_verifier` → receive `access_token`. A wrong verifier must return `invalid_grant`.

---

## 4. Phase 2 — MCP Resource Middleware + group

### 4.1 `src/Middleware/McpResourceMiddleware.php`
**Constructor takes only `Container`.** Mirrors `BearerAuthMiddleware` exactly.

```php
<?php declare(strict_types=1);
namespace OwnPay\Middleware;

use OwnPay\Container;
use OwnPay\Http\Request;
use OwnPay\Http\Response;
use OwnPay\Repository\{OAuthTokenRepository, SettingsRepository};
use OwnPay\Support\DateHelper;

final class McpResourceMiddleware
{
    public function __construct(private Container $container) {}

    public function handle(Request $request, callable $next): Response
    {
        $token = $request->bearerToken();
        if ($token === null || !str_starts_with($token, 'ompmcp_') || strlen($token) < 20) {
            return $this->challenge($request);
        }
        $prefix = substr($token, 7, 12);

        /** @var OAuthTokenRepository $tokens */
        $tokens = $this->container->get(OAuthTokenRepository::class);
        $row = $tokens->findActiveAccessByPrefix($prefix);
        if ($row === null || !is_string($row['token_hash']) || !hash_equals($row['token_hash'], hash('sha256', $token))) {
            return $this->challenge($request);
        }

        // Audience binding (RFC 8707): the token must be for THIS resource.
        $resource = $request->scheme() . '://' . $request->host() . '/api/v1/mcp';
        if (($row['resource'] ?? '') !== $resource) {
            return Response::json(['error' => 'invalid_audience'], 401);
        }

        $mid = (int) $row['merchant_id'];

        // Kill switch: admin enable/disable (per-brand override → global default).
        /** @var SettingsRepository $settings */
        $settings = $this->container->get(SettingsRepository::class);
        if ($settings->getScoped('mcp', 'enabled', $mid, '0') !== '1') {
            return Response::json(['error' => 'mcp_disabled'], 404);
        }

        $scopes = json_decode((string) $row['scopes'], true);
        $scopes = is_array($scopes) ? $scopes : [];

        $request->setAttribute('merchant_id', $mid);
        $request->setAttribute('mcp_user_id', (int) $row['user_id']);
        $request->setAttribute('mcp_scopes', $scopes);
        $tokens->touchLastUsed((int) $row['id']);

        return $next($request);
    }

    private function challenge(Request $request): Response
    {
        $meta = $request->scheme() . '://' . $request->host() . '/.well-known/oauth-protected-resource';
        return Response::json(['error' => 'unauthorized'], 401)
            ->withHeader('WWW-Authenticate', 'Bearer resource_metadata="' . $meta . '"');
    }
}
```

### 4.2 Add the `mcp` group (additive — insert into `config/middleware.php`, after the `api-public` group, before the closing `];`)
```php
    // ─── MCP: OAuth resource server + rate limit + idempotency ──
    'mcp' => [
        \OwnPay\Middleware\CorsMiddleware::class,
        \OwnPay\Middleware\RateLimiterMiddleware::class,
        \OwnPay\Middleware\McpResourceMiddleware::class,
        \OwnPay\Middleware\IdempotencyMiddleware::class,
    ],
```
(`global` runs before any group automatically — do not duplicate it.)

**CHECK 4:** `php -l` the middleware. Temporarily add a throwaway route `POST /api/v1/mcp-ping` in group `mcp` returning `Response::apiSuccess(['ok'=>true])`; call it with no token → `401` + `WWW-Authenticate`; with a valid token but `mcp.enabled=0` → `404`; set `mcp.enabled=1` → passes. **Remove the throwaway route after.**

---

## 5. Phase 3 — MCP server core

### 5.1 `src/Mcp/McpContext.php`
```php
<?php declare(strict_types=1);
namespace OwnPay\Mcp;

final class McpContext
{
    /** @param list<string> $scopes */
    public function __construct(
        public readonly int $merchantId,
        public readonly int $userId,
        public readonly array $scopes,
        public readonly string $ip,
        public readonly string $userAgent,
    ) {}
}
```

### 5.2 `src/Mcp/Tool.php`
```php
<?php declare(strict_types=1);
namespace OwnPay\Mcp;

interface Tool
{
    public function name(): string;          // e.g. "invoice.create"
    public function title(): string;
    public function description(): string;
    public function scope(): string;         // required OAuth scope
    public function inputSchema(): array;    // JSON Schema (object)
    /** @return array{content: list<array>, isError?: bool, structuredContent?: mixed} */
    public function handle(array $args, McpContext $ctx): array;
}
```

### 5.3 `src/Mcp/SchemaValidator.php` (no external dependency)
Implement a minimal validator for the schema subset used by tools: `type` (object/string/integer/number/boolean/array), `required`, `properties`, `additionalProperties=false`, `enum`, `minimum`/`maximum`, `minLength`/`maxLength`, `items`, `minItems`. On failure, **throw** `\InvalidArgumentException("<field>: <reason>")`. Keep it ~120 lines; do not pull a Composer package.

### 5.4 `src/Mcp/ToolRegistry.php`
```php
<?php declare(strict_types=1);
namespace OwnPay\Mcp;

final class ToolRegistry
{
    // Defense-in-depth: refuse to register anything that looks money-moving / secret.
    private const DENY = '/refund(?!\.(list|get))|initiate|callback|verify|complete|capture|'
                       . 'charge|payout|disburse|mark[_-]?paid|api[_-]?key|secret|credential|'
                       . 'ledger|password|setting|\buser\b|role|permission|webhook/i';
    private const ALLOW_EXCEPTIONS = ['refund.list', 'refund.get'];

    /** @var array<string,Tool> */
    private array $tools = [];

    public function register(Tool $tool): void
    {
        $name = $tool->name();
        if (!in_array($name, self::ALLOW_EXCEPTIONS, true) && preg_match(self::DENY, $name) === 1) {
            throw new \LogicException("MCP: refusing to register forbidden tool '{$name}'");
        }
        $this->tools[$name] = $tool;
    }

    /** @param list<string> $grantedScopes @return list<array> */
    public function listTools(array $grantedScopes): array
    {
        $out = [];
        foreach ($this->tools as $t) {
            if (!in_array($t->scope(), $grantedScopes, true)) continue;
            $out[] = ['name'=>$t->name(),'title'=>$t->title(),'description'=>$t->description(),'inputSchema'=>$t->inputSchema()];
        }
        return $out;
    }

    /** @return array{content: list<array>, isError?: bool, structuredContent?: mixed} */
    public function call(string $name, array $args, McpContext $ctx): array
    {
        $tool = $this->tools[$name] ?? null;
        if ($tool === null) {
            return ['isError'=>true,'content'=>[['type'=>'text','text'=>"Unknown tool: {$name}"]]];
        }
        if (!in_array($tool->scope(), $ctx->scopes, true)) {
            return ['isError'=>true,'content'=>[['type'=>'text','text'=>'Insufficient scope for '.$name]]];
        }
        try {
            SchemaValidator::assert($args, $tool->inputSchema());
            return $tool->handle($args, $ctx);
        } catch (\InvalidArgumentException $e) {
            return ['isError'=>true,'content'=>[['type'=>'text','text'=>'Invalid arguments: '.$e->getMessage()]]];
        } catch (\Throwable $e) {
            // Never leak internals.
            return ['isError'=>true,'content'=>[['type'=>'text','text'=>'Tool error.']]];
        }
    }
}
```

### 5.5 `src/Mcp/McpServer.php`
```php
<?php declare(strict_types=1);
namespace OwnPay\Mcp;

final class McpServer
{
    public const PROTOCOL = '2025-06-18';

    public function __construct(private ToolRegistry $registry) {}

    /** @param array<string,mixed> $msg @return array<string,mixed>|null (null = notification) */
    public function dispatch(array $msg, McpContext $ctx): ?array
    {
        if (($msg['jsonrpc'] ?? null) !== '2.0' || !isset($msg['method'])) {
            return self::err($msg['id'] ?? null, -32600, 'Invalid Request');
        }
        $id = $msg['id'] ?? null;
        $method = (string) $msg['method'];
        $params = is_array($msg['params'] ?? null) ? $msg['params'] : [];

        switch ($method) {
            case 'initialize':
                $ver = is_string($params['protocolVersion'] ?? null) ? $params['protocolVersion'] : self::PROTOCOL;
                return self::ok($id, [
                    'protocolVersion' => $ver,
                    'capabilities'    => ['tools' => ['listChanged' => false]],
                    'serverInfo'      => ['name' => 'OwnPay MCP', 'version' => '1.0.0'],
                ]);
            case 'notifications/initialized':
                return null;                       // notification → no response
            case 'ping':
                return self::ok($id, (object) []);
            case 'tools/list':
                return self::ok($id, ['tools' => $this->registry->listTools($ctx->scopes)]);
            case 'tools/call':
                $name = is_string($params['name'] ?? null) ? $params['name'] : '';
                $args = is_array($params['arguments'] ?? null) ? $params['arguments'] : [];
                return self::ok($id, $this->registry->call($name, $args, $ctx));
            default:
                return self::err($id, -32601, "Method not found: {$method}");
        }
    }

    private static function ok(mixed $id, mixed $result): array { return ['jsonrpc'=>'2.0','id'=>$id,'result'=>$result]; }
    private static function err(mixed $id, int $c, string $m): array { return ['jsonrpc'=>'2.0','id'=>$id,'error'=>['code'=>$c,'message'=>$m]]; }
}
```

### 5.6 `src/Controller/Api/McpController.php`
```php
<?php declare(strict_types=1);
namespace OwnPay\Controller\Api;

use OwnPay\Container;
use OwnPay\Http\Request;
use OwnPay\Http\Response;
use OwnPay\Mcp\{McpServer, McpContext};

final class McpController
{
    public function __construct(private Container $c) {}

    public function handle(Request $req): Response
    {
        // Body cap (mirror webhook controller 1MB guard).
        $raw = $req->rawBody() ?? '';
        if (strlen($raw) > 1048576) {
            return Response::json(['jsonrpc'=>'2.0','id'=>null,'error'=>['code'=>-32600,'message'=>'Payload too large']], 413);
        }
        $msg = $req->json();
        if (!is_array($msg) || $msg === []) {
            return Response::json(['jsonrpc'=>'2.0','id'=>null,'error'=>['code'=>-32700,'message'=>'Parse error']], 400);
        }
        // No JSON-RPC batch (keep surface small): reject list payloads.
        if (array_is_list($msg)) {
            return Response::json(['jsonrpc'=>'2.0','id'=>null,'error'=>['code'=>-32600,'message'=>'Batch not supported']], 400);
        }

        $ctx = new McpContext(
            merchantId: (int) $req->getAttribute('merchant_id'),
            userId:     (int) $req->getAttribute('mcp_user_id'),
            scopes:     (array) $req->getAttribute('mcp_scopes', []),
            ip:         $req->ip(),
            userAgent:  $req->userAgent(),
        );

        $server = $this->c->get(McpServer::class);
        $resp = $server->dispatch($msg, $ctx);

        // Audit tool calls (best-effort; never block the response).
        if (($msg['method'] ?? '') === 'tools/call') {
            try {
                $audit = $this->c->get(\OwnPay\Service\System\AuditLogger::class);
                $audit->log($ctx->merchantId, $ctx->userId, 'mcp.tool.call', 'mcp_tool', 0,
                    null, ['tool' => $msg['params']['name'] ?? null], $ctx->ip);
            } catch (\Throwable) { /* audit must not break the call */ }
        }

        return $resp === null ? Response::empty(202) : Response::json($resp, 200);
    }
}
```
> **VERIFY** the `AuditLogger::log(...)` argument order against `src/Service/System/AuditLogger.php` and adapt the call if it differs. If `rawBody()` / `array_is_list()` are unavailable, use `$req->json()` size via `json_encode` and `array_keys($msg) !== range(...)` respectively.

### 5.7 Route (additive — append in `config/routes/api.php`)
```php
    // ======================== MCP RESOURCE ========================
    $router->post('/api/v1/mcp', 'Api\\McpController@handle', 'mcp');
```

### 5.8 DI registration (additive — insert before the closing `};` of `config/services.php`)
```php
    // ─── MCP server ────────────────────────────────────────────
    $c->singleton(\OwnPay\Mcp\ToolRegistry::class, static function (\OwnPay\Container $c): \OwnPay\Mcp\ToolRegistry {
        $r = new \OwnPay\Mcp\ToolRegistry();
        foreach ([
            \OwnPay\Mcp\Tools\InvoiceCreateTool::class,
            \OwnPay\Mcp\Tools\InvoiceUpdateTool::class,
            \OwnPay\Mcp\Tools\InvoiceCancelTool::class,
            \OwnPay\Mcp\Tools\InvoiceGetTool::class,
            \OwnPay\Mcp\Tools\InvoiceListTool::class,
            \OwnPay\Mcp\Tools\PaymentLinkCreateTool::class,
            \OwnPay\Mcp\Tools\PaymentLinkUpdateTool::class,
            \OwnPay\Mcp\Tools\PaymentLinkDeactivateTool::class,
            \OwnPay\Mcp\Tools\PaymentLinkGetTool::class,
            \OwnPay\Mcp\Tools\PaymentLinkListTool::class,
            \OwnPay\Mcp\Tools\CustomerCreateTool::class,
            \OwnPay\Mcp\Tools\CustomerUpdateTool::class,
            \OwnPay\Mcp\Tools\CustomerGetTool::class,
            \OwnPay\Mcp\Tools\CustomerSearchTool::class,
            \OwnPay\Mcp\Tools\CustomerListTool::class,
            \OwnPay\Mcp\Tools\TransactionSearchTool::class,
            \OwnPay\Mcp\Tools\TransactionGetTool::class,
            \OwnPay\Mcp\Tools\TransactionStatsTool::class,
            \OwnPay\Mcp\Tools\TransactionReportTool::class,
            \OwnPay\Mcp\Tools\TransactionExportTool::class,
            \OwnPay\Mcp\Tools\BalanceGetTool::class,
            \OwnPay\Mcp\Tools\RefundListTool::class,
            \OwnPay\Mcp\Tools\RefundGetTool::class,
        ] as $cls) {
            $r->register(new $cls($c));     // each tool ctor takes only Container
        }
        return $r;
    });
    $c->singleton(\OwnPay\Mcp\McpServer::class, static fn(\OwnPay\Container $c) =>
        new \OwnPay\Mcp\McpServer($c->get(\OwnPay\Mcp\ToolRegistry::class)));
```

**CHECK 5:** `php -l` all new files. With a valid token, POST `initialize` → returns `protocolVersion`+`serverInfo`; POST `tools/list` → returns only the tools whose `scope()` the token holds; POST `ping` → `{}`; POST a `tools/call` with `{"name":"refund.create",...}` → result `isError:true` ("Unknown tool"). Registering a forbidden tool must throw at boot (proven by the test in §7).

---

## 6. Phase 4 — Tools

Each tool: `src/Mcp/Tools/<Name>Tool.php`, ctor `Container $c` only, resolves its service inside `handle()`, and **always scopes by `$ctx->merchantId`**. Create the classes listed in 5.8.

### 6.1 Exemplar — write tool (clone for all create/update tools)
```php
<?php declare(strict_types=1);
namespace OwnPay\Mcp\Tools;

use OwnPay\Container;
use OwnPay\Mcp\{Tool, McpContext};
use OwnPay\Service\Payment\InvoiceService;

final class InvoiceCreateTool implements Tool
{
    public function __construct(private Container $c) {}
    public function name(): string  { return 'invoice.create'; }
    public function title(): string { return 'Create invoice'; }
    public function scope(): string { return 'mcp:invoices'; }
    public function description(): string {
        return 'Create a draft invoice for the merchant. Does NOT take payment; returns the invoice and its hosted checkout token.';
    }
    public function inputSchema(): array {
        return ['type'=>'object','additionalProperties'=>false,'required'=>['items'],'properties'=>[
            'customer_id'=>['type'=>'integer'],
            'currency'=>['type'=>'string','minLength'=>3,'maxLength'=>3],
            'due_date'=>['type'=>'string'],
            'notes'=>['type'=>'string','maxLength'=>2000],
            'tax'=>['type'=>'number','minimum'=>0],
            'discount'=>['type'=>'number','minimum'=>0],
            'items'=>['type'=>'array','minItems'=>1,'items'=>['type'=>'object','additionalProperties'=>false,
                'required'=>['description','quantity','unit_price'],'properties'=>[
                    'description'=>['type'=>'string','maxLength'=>255],
                    'quantity'=>['type'=>'integer','minimum'=>1],
                    'unit_price'=>['type'=>'number','minimum'=>0],
                ]]],
        ]];
    }
    public function handle(array $args, McpContext $ctx): array {
        /** @var InvoiceService $svc */
        $svc = $this->c->get(InvoiceService::class);
        $inv = $svc->create($ctx->merchantId, $args);   // service is tenant-scoped internally
        return [
            'structuredContent' => $inv,
            'content' => [['type'=>'text','text'=>"Created invoice {$inv['invoice_number']} — total {$inv['total']} {$inv['currency']} (token {$inv['token']})."]],
        ];
    }
}
```

### 6.2 Exemplar — read/search tool (clone for all read tools)
```php
<?php declare(strict_types=1);
namespace OwnPay\Mcp\Tools;

use OwnPay\Container;
use OwnPay\Mcp\{Tool, McpContext};
use OwnPay\Repository\TransactionRepository;

final class TransactionSearchTool implements Tool
{
    public function __construct(private Container $c) {}
    public function name(): string  { return 'transaction.search'; }
    public function title(): string { return 'Search transactions'; }
    public function scope(): string { return 'mcp:transactions:read'; }
    public function description(): string { return 'Search the merchant transactions with filters (status, gateway, text, date range). Read-only.'; }
    public function inputSchema(): array {
        return ['type'=>'object','additionalProperties'=>false,'properties'=>[
            'status'=>['type'=>'string'],
            'gateway'=>['type'=>'string'],
            'q'=>['type'=>'string','maxLength'=>120],
            'date_from'=>['type'=>'string'],
            'date_to'=>['type'=>'string'],
            'page'=>['type'=>'integer','minimum'=>1],
            'per_page'=>['type'=>'integer','minimum'=>1,'maximum'=>100],
        ]];
    }
    public function handle(array $args, McpContext $ctx): array {
        /** @var TransactionRepository $repo */
        $repo = $this->c->get(TransactionRepository::class)->forTenant($ctx->merchantId);  // TENANT SCOPE
        $perPage = min(100, max(1, (int)($args['per_page'] ?? 20)));
        $page    = max(1, (int)($args['page'] ?? 1));
        $filters = array_intersect_key($args, array_flip(['status','gateway','q','date_from','date_to']));
        $total = $repo->countFiltered($filters);
        $items = $repo->listFiltered($filters, $perPage, ($page-1)*$perPage);
        $data = ['items'=>$items,'total'=>$total,'page'=>$page,'per_page'=>$perPage];
        return ['structuredContent'=>$data,'content'=>[['type'=>'text','text'=>"Found {$total} transaction(s); page {$page}."]]];
    }
}
```

### 6.3 Exemplar — read‑only refund tool (NEVER create)
```php
<?php declare(strict_types=1);
namespace OwnPay\Mcp\Tools;

use OwnPay\Container;
use OwnPay\Mcp\{Tool, McpContext};
use OwnPay\Repository\RefundRepository;

final class RefundListTool implements Tool
{
    public function __construct(private Container $c) {}
    public function name(): string  { return 'refund.list'; }          // allowlisted read exception
    public function title(): string { return 'List refunds (read-only)'; }
    public function scope(): string { return 'mcp:refunds:read'; }
    public function description(): string { return 'List existing refund records for the merchant. READ-ONLY — cannot create or issue a refund.'; }
    public function inputSchema(): array {
        return ['type'=>'object','additionalProperties'=>false,'properties'=>[
            'page'=>['type'=>'integer','minimum'=>1],
            'per_page'=>['type'=>'integer','minimum'=>1,'maximum'=>100],
        ]];
    }
    public function handle(array $args, McpContext $ctx): array {
        /** @var RefundRepository $repo */
        $repo = $this->c->get(RefundRepository::class)->forTenant($ctx->merchantId);
        $perPage = min(100, max(1, (int)($args['per_page'] ?? 20)));
        $page    = max(1, (int)($args['page'] ?? 1));
        $res = $repo->paginateScoped($page, $perPage);     // TenantScope read; VERIFY method name vs RefundRepository
        return ['structuredContent'=>$res,'content'=>[['type'=>'text','text'=>'Listed refunds (read-only).']]];
    }
}
```

### 6.4 Spec for the remaining tools (clone the matching exemplar; exact backing call shown)
| Tool class | scope | inputSchema (key fields) | handle() backing call |
|---|---|---|---|
| `InvoiceUpdateTool` | `mcp:invoices` | `id`(int, req), invoice fields | `InvoiceService::update($ctx->merchantId, (int)$args['id'], $args)` |
| `InvoiceCancelTool` | `mcp:invoices` | `id`(int, req) | `InvoiceService::update($ctx->merchantId, $id, ['status'=>'cancelled'])` |
| `InvoiceGetTool` | `mcp:invoices` | `id`(int, req) | `InvoiceRepository::forTenant($mid)->findScoped($id)` |
| `InvoiceListTool` | `mcp:invoices` | `page`,`per_page` | `InvoiceService::listForMerchant($mid)` (or repo paginateScoped) |
| `PaymentLinkCreateTool` | `mcp:payment_links` | `title`,`amount`,`currency`,`is_amount_fixed`,`expires_at`… | `PaymentLinkService::create($mid, $args)` |
| `PaymentLinkUpdateTool` | `mcp:payment_links` | `id`(req)+fields | `PaymentLinkService::update($mid, $id, $args)` |
| `PaymentLinkDeactivateTool` | `mcp:payment_links` | `id`(req) | `PaymentLinkService::update($mid, $id, ['status'=>'inactive'])` |
| `PaymentLinkGetTool` | `mcp:payment_links` | `id`(req) | `PaymentLinkService::find($mid, $id)` |
| `PaymentLinkListTool` | `mcp:payment_links` | — | `PaymentLinkService::listForMerchant($mid)` |
| `CustomerCreateTool` | `mcp:customers` | `email`,`phone`,`name`,`metadata` | `CustomerPiiService::create($mid, $args)` |
| `CustomerUpdateTool` | `mcp:customers` | `id`(req)+fields | `CustomerPiiService::update($mid, $id, $args)` |
| `CustomerGetTool` | `mcp:customers` | `id`(req) | `CustomerPiiService::get($mid, $id)` |
| `CustomerSearchTool` | `mcp:customers` | `identifier`(email/phone, req) | `CustomerPiiService::findByContact($mid, $identifier)` |
| `CustomerListTool` | `mcp:customers` | `page`,`per_page` | `CustomerPiiService::list($mid, $page, $perPage)` |
| `TransactionGetTool` | `mcp:transactions:read` | `trx_id`(req) | `TransactionRepository::forTenant($mid)->findByTrxId($trxId)` |
| `TransactionStatsTool` | `mcp:transactions:read` | `from`,`to` (optional) | `forTenant($mid)->stats($from,$to)` or `getTodayStats($mid)` |
| `TransactionReportTool` | `mcp:reports` | `from`,`to`,`gateway?` | `forTenant($mid)->getReportData($mid,$from,$to,$gw)` |
| `TransactionExportTool` | `mcp:reports` | `from`,`to`,`gateway?` | `forTenant($mid)->getExportData($mid,$from,$to,$gw)` (return as text/CSV in content) |
| `BalanceGetTool` | `mcp:balance:read` | — | the ledger balance accessor recorded in Pre‑flight 1.2 (READ ONLY) |
| `RefundGetTool` | `mcp:refunds:read` | `id`(req) | `RefundRepository::forTenant($mid)->findScoped($id)` |

> Full PII is returned by the customer read tools (per the product decision). The `customer.*` read handlers therefore return the service's decrypted output as‑is; the `mcp.tool.call` audit entry records that a PII read occurred (do not log the PII values themselves).

**CHECK 6:** `php -l` every tool. With a token granting all scopes: `tools/list` lists all 23 tools; `tools/call` `invoice.create` creates a draft invoice for the token's merchant; `transaction.search` returns only that merchant's rows; a bad‑args call returns `isError:true` with the field message.

---

## 7. Phase 5 — Admin UI (enable/disable, clients, tokens)

Create `src/Controller/Admin/McpController.php` (ctor `Container $c`), routes in `config/routes/web.php` under the **`admin`** group (mirror an existing admin route), and `templates/admin/mcp/index.twig` (mirror `templates/admin/settings/index.twig` layout — extend the same base, include the sidebar). Features:
- **Enable toggle** (global + active brand): writes `mcp.enabled` via `SettingsRepository::setScoped('mcp','enabled', $value, $mid,'bool')`. Every change → `AuditLogger::log(..., 'mcp.enabled', ...)`.
- **Clients**: list `op_oauth_clients`, approve `pending`→`active`, disable.
- **Tokens**: list `OAuthTokenRepository::listActiveForMerchant($mid)`; **Revoke** button → `revoke(id)` (+ audit `mcp.token.revoked`).
- All admin forms include the framework CSRF field `_csrf_token` (the `admin` group runs `CsrfMiddleware`).

**CHECK 7:** From the admin UI, toggle MCP off → an MCP call returns `404 mcp_disabled`; toggle on → works. Revoke a token → subsequent calls with it → `401`.

---

## 8. Phase 6 — Hardening + tests

### 8.1 Hardening (already wired by the group; confirm)
- **Rate limit:** the `mcp` group includes `RateLimiterMiddleware`. Confirm it keys per credential; if it keys by IP only, that is acceptable for v1. (Do not weaken it.)
- **CORS/Origin:** `CorsMiddleware` is in the group. Ensure the MCP/OAuth responses get appropriate CORS for browser‑based clients; default‑deny otherwise.
- **Body cap + no batch:** enforced in `McpController` (§5.6).
- **Audit:** tool calls + token lifecycle + consent are logged via `AuditLogger`.
- **HTTPS:** HSTS is global; no change needed.

### 8.2 Tests (write all; run on PHP‑8.3 build box if local PHPUnit can't run — see §0.5)
- `tests/Unit/Mcp/ToolRegistryDenyListTest.php` — registering `refund.create` (and `payments.initiate`, `apikey.read`) **throws** `\LogicException`; `refund.list` registers fine.
- `tests/Unit/Mcp/McpServerTest.php` — `initialize`/`ping`/`tools/list` shapes; unknown method → `-32601`; `tools/call` unknown tool → `isError`.
- `tests/Integration/Mcp/TenantIsolationTest.php` — a context for merchant A cannot read merchant B's transaction (handler uses `forTenant`).
- `tests/Integration/OAuth/OAuthFlowTest.php` — code→token works; wrong PKCE verifier → `invalid_grant`; audience mismatch → rejected; refresh rotation invalidates the old refresh.

`ToolRegistryDenyListTest` (the tripwire — copy):
```php
public function test_forbidden_tools_are_refused(): void
{
    $r = new \OwnPay\Mcp\ToolRegistry();
    foreach (['refund.create','payment.initiate','apikey.read','ledger.adjust','settings.update'] as $bad) {
        $threw = false;
        try { $r->register(new FakeTool($bad)); } catch (\LogicException) { $threw = true; }
        $this->assertTrue($threw, "Expected refusal for {$bad}");
    }
}
```

**CHECK 8 (final gate):**
1. `php -l` passes on **every** new file.
2. PHPStan L9 on `src/Mcp` + `src/Service/OAuth` + new controllers/middleware → 0 errors (run on a box where it runs).
3. All §8.2 tests green (on PHP 8.3).
4. **Regression:** existing routes still respond — smoke‑test `GET /api/v1/health` (200 with a normal API key), an admin page loads, a checkout page loads. Nothing in the existing API/mobile/admin changed behavior.

---

## 9. Definition of Done (acceptance — all must be ✅)
- [ ] MCP endpoint `POST /api/v1/mcp` works end‑to‑end via the OAuth 2.1 + PKCE flow.
- [ ] `tools/list` shows **only** safe tools the token's scopes allow; all 23 tools function.
- [ ] `tools/call` for any forbidden name → `isError` / unknown tool. No refund/payment/verify/api‑key tool exists.
- [ ] Deny‑list test is **red** if a forbidden tool is ever registered (tripwire active).
- [ ] Tenant isolation proven (A cannot read B).
- [ ] Admin enable/disable works (global + brand); disabled → `404`. Token revoke → `401`.
- [ ] OAuth: wrong PKCE → `invalid_grant`; audience mismatch → rejected; refresh rotates.
- [ ] **Every pre‑existing feature still works** (regression smoke test passed).
- [ ] `php -l` clean on all new files; PHPStan L9 clean; tests green on 8.3.
- [ ] `output/change-log/` entry written per phase; `task_plan.md` updated + re‑attested.

## 10. Rollback (if a phase fails irrecoverably)
- New files are isolated under `src/Mcp/`, `src/Service/OAuth/`, new repos/controllers/middleware, `templates/oauth|admin/mcp` → delete them.
- Shared‑file edits were additive at marked anchors → remove exactly those added blocks (or restore from `output/snapshots/`).
- Drop the 3 `op_oauth_*` tables + the `mcp` settings rows.
- No existing code was modified, so removal returns the app to its prior state. **Never** run a destructive git reset without explicit permission.

## 11. Troubleshooting (symptom → cause → fix)
| Symptom | Cause | Fix |
|---|---|---|
| `Cannot resolve primitive parameter $x` at boot | A scalar in a constructor the container builds | Remove the scalar; read it from env/config/request inside the method, or register the class with a factory (§0.3) |
| `Middleware class not found: ...Mcp...` | Namespace/path/autoload mismatch | Ensure `src/Middleware/McpResourceMiddleware.php` namespace is `OwnPay\Middleware`; run `composer dump-autoload` on the build box |
| MCP call returns `401` with a fresh token | Prefix/hash mismatch or audience mismatch | Confirm prefix = `substr(token,7,12)`; confirm the token's `resource` equals `scheme://host/api/v1/mcp` |
| MCP call returns `404 mcp_disabled` | `mcp.enabled` not set for the brand | Toggle on in admin, or `SettingsRepository::setScoped('mcp','enabled','1',$mid,'bool')` |
| `tools/list` empty | Token scopes don't include the tools' scopes | Grant the right scopes at consent; check `mcp_scopes` attribute |
| Existing API routes break after edit | A shared file was rewritten, not appended | Restore from `output/snapshots/`, re‑apply only the additive blocks |
| `tools/call` works for a forbidden name | A forbidden tool got registered | This must be impossible — fix `ToolRegistry::DENY`; the tripwire test must fail the build |
| Token endpoint accepts any verifier | PKCE check skipped/incorrect | Use the exact `verifyPkce()` (BASE64URL(SHA256(verifier)) + `hash_equals`) |

---

### Final reminder
Build **phase by phase**, run each **CHECK**, and never register a tool that can move money or read secrets. If reality ever differs from this runbook, trust the **real code** (you verified it in Phase −1) and adapt the handler to the real signature — but never relax a security rule in §0.1.
