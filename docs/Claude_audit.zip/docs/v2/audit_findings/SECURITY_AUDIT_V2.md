# OwnPay — Independent Security Audit v2

> A consolidated, independent security pass over the full OwnPay codebase, mapped to **OWASP Top 10 (2021)**, **PCI-DSS**, and **CWE**. This complements (does not repeat) `ownpay_master_audit_report.md` — it re-states the security posture, integrates the Round-2-surfaced issues, and ends with a single prioritized release security checklist.
>
> *Note on method:* the `security-review` skill is designed to review a branch **diff**; there is no diff here (audit-only). This is therefore a full-codebase posture review using the evidence gathered across both rounds. Every item cites file:line.

## 1. Overall security posture
OwnPay is, for a pre-release custom framework, **above-average secure by design**. The defensive baseline is real and verified:
- **SQLi:** PDO `ATTR_EMULATE_PREPARES=false` + typed `bindValue` everywhere; identifier/table-name allowlisting (`Database.php:240-256,391,410`). PHPStan L9 clean.
- **XSS:** Twig `autoescape='html'` (`TwigFactory:98`); `| raw` only on hook output.
- **CSRF:** synchronizer-token + `hash_equals` + rotation; `/api/*` exempt only because it is bearer/JWT-authed (`CsrfMiddleware`, verified vs `routes/api.php`).
- **Headers/CSP:** global CSP w/ per-request nonce, HSTS, XFO DENY, nosniff, Referrer/Permissions-Policy (`SecurityHeadersMiddleware`).
- **AuthN:** Argon2id, session-fixation regeneration, IP+email lockout, XFF trusted only behind `TRUSTED_PROXIES` (`Authenticator`, `Request::ip`).
- **Crypto/JWT:** HS256 hardcoded (no alg-confusion), CSPRNG tokens/OTPs, field encryption, GCM SMS transport.
- **SSRF:** webhook URL validation blocks private/reserved/metadata IPs (IPv4) (`UrlValidator`).
- **Tenant isolation:** clone-based `TenantScope` with fail-closed `requireTenant()`; brand-scoped plugin activation.
- **Dependencies:** `composer audit` / `npm audit` = 0 advisories.

The risks are **concentrated**, not systemic: a few wiring defects and an inconsistent plugin/gateway contract.

## 2. Vulnerability register (OWASP-mapped)

### A01 — Broken Access Control
- **FIND-019 (HIGH):** pairing route in JWT-guarded group → bootstrap deadlock; conversely a reminder that auth grouping is hand-managed (`routes/api.php` ↔ `middleware.php`). *(also availability)*
- **FIND-010 (LOW):** `DomainMiddleware:72` trusts client `Host: localhost` to bypass brand scoping.
- **PASS:** tenant isolation, `/admin` blocked on custom domains, permission middleware re-asserted (AUD-21).

### A02 — Cryptographic Failures
- **PASS:** Argon2id, AES-256-GCM, `random_bytes`/`random_int` for OTP/JWT-jti/tokens, field encryption. **Watch:** `Authenticator` TOTP drift ±2 steps (FIND-012, tighten to ±1). Update signing = RSA-2048 + SHA-256 (acceptable; consider RSA-3072/Ed25519 long-term).

### A03 — Injection
- **PASS (SQLi):** parameterized throughout. **NEW (XSS):** `update/index.html` renders `marked.parse(changelog)` into `innerHTML` unsanitized (U2) — add DOMPurify. **Watch:** admin-supplied SMS-template regexes run via `preg_match` (ReDoS surface; semi-trusted configurer).

### A04 — Insecure Design
- **FIND-003 (CRITICAL):** static service-locator (`Database::getInstance`) split from DI → refunds/callbacks dead (CWE-665). The single biggest *design* lesson — eliminate static locators.
- **FIND-002 (MED):** external HTTP inside a DB transaction holding `FOR UPDATE` (CWE-667).
- **FIND-007 (MED):** rate limiter **fails open** on DB error (CWE-636).
- **FIND-S1/S2 (HIGH):** schema/code drift breaks alerts + queue at runtime (availability).
- **FIND-020 (LOW):** dead/unused tables (`op_maintenance_locks`, `op_queue_jobs`, `op_plugin_settings`) — schema hygiene; `op_queue_jobs` is the schema half of FIND-S2 (`SCHEMA_REVIEW.md` §6).

### A05 — Security Misconfiguration
- **NEW (build-update):** the release zip ships `.claude/`, `output/`, `CLAUDE.md`, the audit prompt (B3); and `composer update` ships dev tooling (B2). Risk of leaking internal config/notes into every customer install and bloating the trusted vendor tree. *(Also confirm the private key `.pem` is git-ignored.)*
- **PASS:** `APP_DEBUG=false` default; exception handler masks paths/SQL; `.htaccess`/nginx deny `.env`/`vendor`/schema (verified live 403/404).

### A06 — Vulnerable & Outdated Components
- **FIND-006 (MED):** `phpunit ^12.5` requires PHP 8.3 while the project targets 8.2 → test tier unrunnable → regressions like FIND-003 ship undetected. Align versions and **make CI green** — an untested money platform is itself a security risk.
- **PASS:** lean dependency tree; 0 known advisories.

### A07 — Identification & Authentication Failures
- **FIND-004 (CRITICAL):** un-gated `mock_` token → payment-confirmation bypass (CWE-287/345) across affirm/afterpay/bitpay.
- **FIND-005 (HIGH):** gateway `verifyWebhook(): return true` no-ops + fake `refund()` (CWE-345).
- **NEW (create-module M1):** the scaffolder **generates** the same insecure defaults (`verify()` returns success, `verifyWebhook` returns true) — it manufactures A07 vulnerabilities for every new gateway. Fix the scaffold to be secure-by-default.
- **PASS:** JWT alg-confusion rejected; refresh rotation + jti blacklist; OTP single-use; pairing rate-limited.

### A08 — Software & Data Integrity Failures
- **PASS:** update pipeline = SHA-256 + RSA signature verify with embedded public key + domain allowlist + backup/rollback (`UpdateService`). **Watch:** `update/index.html` loads CDN `marked`/fonts without SRI/CSP (U3) — supply-chain exposure for the registry page.

### A09 — Logging & Monitoring Failures
- **FIND-S1 (HIGH):** the **alerting channel itself is broken** (`op_alerts` missing) — security/operational alerts (e.g. balance discrepancies) silently fail to persist. This is a monitoring blind spot exactly where it matters.
- **PASS:** webhook deliveries log payload **hash** only (PCI-safe); log-forging newline stripping; audit log with HMAC signature.

### A10 — SSRF
- **PASS (IPv4):** `UrlValidator::isValidWebhookUrl` blocks private/reserved + `169.254.169.254`. **FIND-008 (LOW):** DNS-rebind TOCTOU (no IP pinning) + IPv6 AAAA not resolved.

## 3. PCI-DSS relevance (payment platform)
- **No PAN/card data stored** by core (gateway-redirect model); webhook logs store hashes only — good scope minimization.
- **Req 6 (secure SW):** FIND-003/004/005/019 and the broken test tier (FIND-006) are the blockers — a payment app must have a runnable, green test suite and no auth/verification bypass before handling live money.
- **Req 8 (auth):** Argon2id + 2FA + lockout = strong; ensure admin password policy ≥ 12 chars (installer min is 8 — tighten).
- **Req 10 (logging):** fix FIND-S1 so security events are actually recorded; ensure audit-log HMAC key (`AUDIT_HMAC_SECRET`) is provisioned (installer generates it ✓).

## 4. Prioritized security remediation checklist (for first release)
**Must-fix (security blockers):**
- [ ] A07/A04 — FIND-004 (gate `mock_` to non-live, fleet-wide + conformance test).
- [ ] A07 — FIND-005 (real `verifyWebhook`; no fake `refund`).
- [ ] A04 — FIND-003 (kill the static service-locator; DI).
- [ ] A01 — FIND-019 (pairing/refresh bootstrap group).
- [ ] A07 — create-module M1 (secure-by-default scaffold, or it re-creates A07 forever).
- [ ] A09/A04 — FIND-S1/S2 (alerts + queue schema).

**High:**
- [ ] A06 — FIND-006 (runnable green tests).
- [ ] A05 — build-update B2/B3 (no `.claude`/secrets/dev-deps in the shipped zip).
- [ ] A03 — index.html U2 (sanitize changelog markdown).
- [ ] A04 — FIND-002 (HTTP outside DB txn).

**Medium/Low (fast-follow):**
- [ ] A04 — FIND-007 (fail-closed rate limit) · FIND-009 (default-deny plugin sandbox).
- [ ] A10 — FIND-008 (SSRF IP-pinning + IPv6).
- [ ] A01 — FIND-010 (Host-header) · A02 — FIND-012 (TOTP window) · business-logic FIND-016/017.
- [ ] A08 — index.html U3 (SRI/CSP) · ReDoS guard on admin SMS-template regex.
- [ ] Req 8 — raise installer admin password minimum to ≥ 12 chars.

## 5. Bottom line
The cryptographic, injection, session, and transport foundations are solid. **First-release security hinges on closing the verification-bypass cluster (FIND-004/005 + the scaffold that reproduces it), the DI/bootstrap defects (FIND-003/019), restoring the alerting+queue subsystems (FIND-S1/S2), and getting a green test suite (FIND-006).** None require architectural change — they are wiring, contract-enforcement, and schema fixes, all enumerated with code in `IMPLEMENTATION_PLAN.md`.
