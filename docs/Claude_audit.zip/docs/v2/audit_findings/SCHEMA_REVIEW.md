# Database Schema Review — `database/schema.sql`

> Cross-check of `schema.sql` against the code that uses it. Markdown-only. The 52 defined tables and every `op_*` code reference were enumerated this session; the two gaps below were verified directly (table + columns + wiring).

## Verdict
The schema is **comprehensive and column-compliant** (the strict naming checks from the master report all PASS), but there are **two real gaps — both wired into live cron jobs**, so they fail at runtime, not just in theory:
1. **`op_alerts` table is MISSING** (used by `AlertService`, which `BalanceVerificationJob` and `NotificationService` depend on).
2. **`op_job_queue` (code) ≠ `op_queue_jobs` (schema)** — wrong table name *and* incompatible columns; the queue worker runs every minute against a table that doesn't exist.

---

## 1. Table inventory (52 tables defined in `schema.sql`)
Merchants/RBAC: `op_merchants`, `op_roles`, `op_permissions`, `op_role_permissions`, `op_merchant_users`, `op_api_keys` · Domains: `op_domains` · Gateways/Currency: `op_gateways`, `op_gateway_configs`, `op_manual_gateways`, `op_currencies`, `op_exchange_rates` · Settings: `op_system_settings` · Customers: `op_customers` · Payments: `op_payment_intents`, `op_transactions`, `op_idempotency_keys`, `op_refunds`, `op_payment_links`, `op_payment_link_fields`, `op_invoices`, `op_invoice_items` · Webhooks: `op_webhooks`, `op_webhook_events`, `op_webhook_delivery_logs`, `op_webhook_deliveries` · Ledger: `op_ledger_accounts`, `op_ledger_transactions`, `op_ledger_entries` · Disputes/Fees: `op_disputes`, `op_fee_rules` · Audit: `op_audit_logs`, `op_login_attempts` · Devices/SMS: `op_device_pairing_tokens`, `op_paired_devices`, `op_mobile_notifications`, `op_sms_templates`, `op_sms_parsed` · Plugins: `op_plugins`, `op_brand_plugins`, `op_plugin_migrations`, `op_plugin_settings` · System: `op_rate_limits`, `op_sessions`, `op_queue_jobs`, `op_cache`, `op_languages` · Comms: `op_comm_log` · Updates: `op_update_history`, `op_maintenance_locks`, `op_migrations`.

Cross-check of every `op_*` reference in `src/`, `modules/`, `cli/`, `config/` against this list found **exactly two discrepancies** (below). All other referenced tables exist.

---

## 2. FIND-S1 — `op_alerts` table missing (HIGH; live)
**Evidence (consumer):** `src/Service/Notification/AlertService.php` runs `INSERT INTO op_alerts (merchant_id, type, title, message, severity, status, created_at)` (`:42`), plus `SELECT … WHERE merchant_id=:mid AND status='unread'` (`:58`), `UPDATE … SET status='read'` (`:74`,`:88`), and a `DELETE … WHERE created_at < … AND status='read'` (`:102`). **No `CREATE TABLE op_alerts` exists in `schema.sql`.**
**Wiring (why it's live):** `AlertService` is constructor-injected into `BalanceVerificationJob` (`src/Cron/BalanceVerificationJob.php:28,44`) and `NotificationService` (`src/Service/Notification/NotificationService.php:25,41`). When balance verification detects a discrepancy — the exact moment an operator alert matters most — the alert `INSERT` hits a non-existent table and **throws**, so the safety alert is silently lost.
**Severity:** HIGH — the operational/security alerting channel fails precisely when it is needed.

**Fix — add to `schema.sql` (and as a release migration):**
```sql
CREATE TABLE `op_alerts` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `merchant_id` BIGINT UNSIGNED DEFAULT NULL,
  `type`        VARCHAR(60) NOT NULL,
  `title`       VARCHAR(200) NOT NULL,
  `message`     TEXT NOT NULL,
  `severity`    ENUM('info','warning','critical') NOT NULL DEFAULT 'info',
  `status`      ENUM('unread','read') NOT NULL DEFAULT 'unread',
  `created_at`  DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_merchant_status` (`merchant_id`, `status`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `fk_alerts_merchant` FOREIGN KEY (`merchant_id`)
    REFERENCES `op_merchants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```
> Confirm `AlertService`'s exact `severity` values before finalizing the ENUM (adjust if it also writes e.g. `error`/`success`).

---

## 3. FIND-S2 — `op_job_queue` (code) vs `op_queue_jobs` (schema) mismatch (HIGH; live)
**Evidence:** `src/Cron/QueueWorkerJob.php` queries **`op_job_queue`** with columns `status`, `type`, `priority`, `payload`, `attempts`, `available_at`, `started_at`, `completed_at`, `error`, `id` (`:77-83`, `:102`, `:115`, `:126`, `:139-141`). The schema defines a *different* table **`op_queue_jobs`** with columns `queue`, `handler`, `payload`, `attempts`, `available_at`, `reserved_at`, `error`, `created_at` (`schema.sql:774-786`). So the table the worker reads/writes **does not exist**, and even the columns are incompatible (`status`/`type`/`priority`/`started_at`/`completed_at` are absent; `queue`/`handler`/`reserved_at` are unused).
**Wiring (why it's live):** `QueueWorkerJob` is registered as a cron job — `config/services.php:633`: `$runner->register('QueueWorker', …QueueWorkerJob…, 'every_minute')`. So `run()` executes every minute and immediately fails with "table not found" — the **entire background queue is non-functional**, and any feature that enqueues work silently never runs.
**Severity:** HIGH — broken async subsystem + per-minute cron error noise.

**Fix (recommended — make the schema match the consumer):** Replace `op_queue_jobs` with a `op_job_queue` table matching `QueueWorkerJob`:
```sql
CREATE TABLE `op_job_queue` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `type`         VARCHAR(120) NOT NULL,
  `payload`      JSON NOT NULL,
  `status`       ENUM('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
  `priority`     INT NOT NULL DEFAULT 0,
  `attempts`     TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `available_at` DATETIME DEFAULT NULL,
  `started_at`   DATETIME DEFAULT NULL,
  `completed_at` DATETIME DEFAULT NULL,
  `error`        TEXT DEFAULT NULL,
  `created_at`   DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`),
  KEY `idx_status_priority` (`status`, `priority`, `created_at`),
  KEY `idx_available` (`available_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```
Then drop the unused `op_queue_jobs` (or keep it only if something else uses it — nothing in the code does). **Alternative:** rewrite `QueueWorkerJob` to use `op_queue_jobs`'s Laravel-style columns (`queue`/`handler`/`reserved_at`); more code churn, so the table-side fix above is preferred for first release.

---

## 4. Column-compliance re-affirmation (PASS)
The strict column names verified in the master report remain correct: `op_merchant_users.totp_secret_enc`/`two_factor_enabled`, `op_currencies.decimal_places`, `op_exchange_rates.base_currency`/`target_currency` (+ `uk_pair`), `op_sms_parsed.device_id`/`match_status`, ledger `type`, and the STORED generated columns `op_transactions.invoice_id`/`payment_link_id`. v0.2.0 migrations (`001_schema_sync.sql`, `aud_g5_brand_scoped_settings.sql`) correctly add the device/SMS/notification columns and brand-scoped `op_system_settings.merchant_id`.

## 5. Summary
| ID | Table | Issue | Severity | Fix |
|---|---|---|---|---|
| FIND-S1 | `op_alerts` | missing entirely; used by live cron alerts | HIGH | add `CREATE TABLE op_alerts` |
| FIND-S2 | `op_job_queue`/`op_queue_jobs` | name + column mismatch; queue worker (every minute) broken | HIGH | add `op_job_queue` matching the worker; retire `op_queue_jobs` |

Both must be in the first-release schema (and as a forward migration for any existing 0.2.x installs). No other missing tables/columns were found.

---

## 6. Extra / unused tables — defined in schema but never referenced by runtime code
Verified by grepping every `op_*` reference across `src/`, `modules/`, `cli/`, `config/` (tests excluded). Three tables are defined in `schema.sql` but have **zero runtime references** — they are dead/extra:

| Table | schema.sql | Why it's unused | Recommendation |
|---|---|---|---|
| `op_maintenance_locks` | :846 | Maintenance mode uses a **file** lock (`storage/.maintenance`, checked in `Kernel.php:251`), not this table. | Drop it, or migrate `MaintenanceMode` to use it. Harmless if left (empty table). |
| `op_queue_jobs` | :774 | Dead — the queue worker reads `op_job_queue` (different name + columns; see FIND-S2). | Resolve via FIND-S2: replace with `op_job_queue`; do not keep both. |
| `op_plugin_settings` | :740 | Plugin settings are stored in `op_system_settings` via `SettingsRepository::getGroup('plugin.<slug>')` (see the scaffolded addon `boot()`); this table is never touched. | Drop it, or repoint plugin settings to it. Harmless if left. |

**All other 49 tables are referenced by code** — e.g. `op_languages`→`TranslationService`, `op_webhooks`/`op_webhook_events`/`op_webhook_delivery_logs`→webhook subsystem, `op_payment_link_fields`→`PaymentLinkService`, `op_migrations`/`op_plugin_migrations`→update/plugin migrators, `op_sessions`→settings cleanup.

**Severity: LOW** — extra empty tables waste no meaningful resources and pose no security risk. The only one tied to a real bug is `op_queue_jobs` (FIND-S2).

**Column-level note:** a full dead-column audit (columns defined but never SELECT/INSERT'd) is recommended as a fast-follow — method: for each table, diff the `CREATE TABLE` column list against the columns appearing in repository SQL. No obviously-unused columns were spotted in the hot tables (`op_transactions`, `op_invoices`, `op_customers`, ledger), but a systematic pass should confirm before 1.0. *(Schema edits are out of scope this round — these are recommendations, not applied.)*
