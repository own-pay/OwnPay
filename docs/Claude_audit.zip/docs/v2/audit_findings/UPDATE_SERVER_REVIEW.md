# Update Server Page Review — `update/index.html`

> Review of the public update-registry landing page served at the update server root (e.g. `https://update.ownpay.org/`). Markdown-only. Line refs verified this session.

## Verdict
**Design: current and polished.** A modern glassmorphism dark UI (Outfit + JetBrains Mono, animated gradient blobs, stable/beta tabs, "latest" card + collapsible history, markdown changelogs, copy-to-clipboard, toast). Configuration is correct — it fetches `manifest.json` (relative) and renders the exact structure `build-update.php` produces (`channels.stable|beta`, `releases[]`).

**Information leak: NONE that is sensitive.** This is a **public release registry by design** — version names, release dates, file sizes, SHA-256 checksums, RSA signatures (base64), changelogs, download URLs, min-PHP/min-OwnPay, and migration filenames are all *meant* to be public so clients can discover and verify updates. There is no private key, no server path, no credential, and no app-internal data on the page or in the manifest it reads.

**But there are 2 real bugs and a few hardening gaps**, below.

---

## ✅ Implemented this round (authorized: `update/index.html`)
| Item | Status |
|---|---|
| U1 — `formatBytes()` math bug (`Math.pow(k, k)` → `Math.pow(k, i)`) + zero/negative guard | ✅ implemented |
| U2 — changelog markdown sanitized with **DOMPurify**; `marked`/DOMPurify CDN pinned to major (`@12` / `@3`) | ✅ implemented |
| U4 — palette `--primary` aligned to OwnPay indigo `#6c5ce7` (+ matching glow) | ✅ implemented |
| U3 — SRI hashes / strict CSP | ⏭️ partial — CDN pinned to a major version; SRI/CSP not added (page relies on inline handlers; wrong SRI hashes would break it) |
| U5 — render "latest" from `channels.*` | ⏭️ deferred (cosmetic) |

### ✅ Implemented (Round 3b/3c — branding, premium UX & list resilience)
| Item | Status |
|---|---|
| U7 — list-resilience bug: a broken/missing **latest** release no longer blanks the whole release list | ✅ fixed |
| U8 — GitHub-first download with a same-origin local mirror as fallback | ✅ implemented |
| U9 — real branding (logo/favicon/ecosystem+social), sticky top-nav, hero verify-command, light/dark theme, release search, CSP `<meta>` | ✅ implemented |
| U3 (cont.) — CSP `<meta>` now present; real **SRI** + self-hosting `marked`/DOMPurify still pending | ⏭️ partial |

---

## Findings

### U1 — MEDIUM (bug): `formatBytes()` computes the wrong size
`:685`:
```js
return parseFloat((bytes / Math.pow(k, bytes === 0 ? 1 : k)).toFixed(dm)) + ' ' + sizes[i];
```
The exponent is `k` (**1024**) instead of `i` (the unit index). So every file size divides by `1024^1024` → renders as `0 …` (or `NaN`) with a correct-looking unit label. File sizes on the page are wrong.
**Fix:**
```js
function formatBytes(bytes, decimals = 2) {
    if (!bytes || bytes < 0) return '0 Bytes';
    const k = 1024, dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}
```

### U2 — MEDIUM (security/robustness): unsanitized markdown → `innerHTML`
`:875` and `:945` render the changelog with `marked.parse(latest.changelog)` directly into `innerHTML`. `marked` does **not** sanitize. The changelog comes from `manifest.json`, which you control — so today's risk is low — but if the update server, CDN, or manifest is ever tampered with, this is stored XSS executing in the browser of anyone viewing the registry. Defense-in-depth:
```html
<script src="https://cdn.jsdelivr.net/npm/dompurify@3/dist/purify.min.js"></script>
```
```js
const safe = (md) => DOMPurify.sanitize(marked.parse(md || '*No changelog provided.*'));
// ...innerHTML uses ${safe(latest.changelog)} / ${safe(rel.changelog)}
```

### U3 — LOW (supply chain): no SRI / no CSP on CDN assets
`:10-12` load Google Fonts + `marked.min.js` from `cdn.jsdelivr.net` with no Subresource Integrity hash and no Content-Security-Policy. A CDN compromise would execute arbitrary JS on the registry. Add SRI to the `marked` script and serve a CSP header (or `<meta http-equiv>`), e.g. `script-src 'self' https://cdn.jsdelivr.net; object-src 'none'; base-uri 'none'`. For maximum control, self-host `marked`+`DOMPurify` on the update server.

### U4 — LOW (consistency): palette mismatch with the app
`--primary: #6366f1` (`:20`) matches the installer-seeded brand color but differs from the admin console's `--op-primary: #6C5CE7` (`public/assets/css/admin.css:19`). Pick one canonical OwnPay indigo across the update page, admin console, and installer seed (see `DESIGN.md` §1.2 palette finding).

### U5 — INFO (correctness): client-side version sort
`renderPage()` sorts releases with `localeCompare(..., {numeric:true})` (`:776-777`). This is fine for simple `x.y.z` but mis-orders pre-release tags (`1.0.0` vs `1.0.0-rc1`). The authoritative latest is already chosen server-side in `manifest.channels.*`; consider rendering "latest" from `channels.stable/beta` rather than re-deriving it client-side, to avoid divergence.

### U6 — INFO: graceful-degradation is good
`checkZipExists()` HEAD-probes the download and `showNoUpdateFound()` renders a clean empty state on fetch failure (`:711-748`, `:802-813`). No stack traces or server errors are exposed. 👍

> **UPDATE (Round 3c):** `checkZipExists()` has since been **removed**. While it degraded gracefully for a *total* fetch failure, its per-release HEAD probe on the **latest** download was wired into `renderChannel()` so that one failed probe blanked the **entire** history list (and cross-origin HEAD is unreliable — it could false-negative a valid GitHub asset). See **U7**. Download availability is now handled by the GitHub-first `downloadBlock()` (**U8**) instead of a render-time HEAD check.

### U7 — HIGH (bug, FIXED Round 3c): a broken *latest* release wiped the entire list
**Symptom (reported):** if the newest release in the manifest had a configuration problem or a missing/unreachable download link, **no releases rendered at all** — including older, perfectly good versions.
**Root cause:** `renderChannel()` was `async` and `await`ed `checkZipExists(latest.download_url)`; on a falsy result it ran `historyList.innerHTML = ''; return`, so a single bad *latest* download blanked the whole channel (latest **and** history). The cross-origin HEAD probe was also unreliable (CORS / opaque responses), so it could false-negative on a valid GitHub asset.
**Fix (applied — `update/index.html`):** `renderChannel()` is now synchronous and resilient:
- `const valid = (releases || []).filter(r => r && r.version)` — skip only structurally-broken entries, keep the rest;
- feature `valid[0]`, render history `valid.slice(1)` **independently** (a latest-release problem can no longer hide history);
- the HEAD-probe gate is gone; when no download URL can be derived, `downloadBlock()` renders a `Download unavailable` badge *inside* the otherwise-complete card rather than blanking anything.
**Verify:** craft a manifest whose latest release has `download_url` removed/garbled → the latest card still renders (with the unavailable badge) **and** every older version still lists; an entry missing `version` is skipped, not fatal. (Round 3c: inline JS syntax-validated; render logic read-back confirmed.) Change-log `20260531-015730`.

### U8 — MEDIUM (enhancement, IMPLEMENTED Round 3c): GitHub-first download + local mirror fallback
**Requirement:** downloads must prefer GitHub; fall back to the same-origin update-server mirror only when GitHub can't be used.
**Implementation (`update/index.html`):**
- `githubUrl(rel)` — returns the manifest `download_url` when it is a `github.com` URL, else builds the conventional asset URL `https://github.com/own-pay/OwnPay/releases/download/v<ver>/ownpay-<ver>.zip` (version `encodeURIComponent`'d);
- `localMirrorUrl(rel)` — derives a relative same-origin path (`releases/<ver>/ownpay-<ver>.zip`) from the manifest;
- `downloadBlock(rel, opts)` — primary **"Download (GitHub)"** button + secondary **"or use direct mirror"** link; degrades to an unavailable badge if neither URL resolves.
**Design note:** GitHub is offered as the primary *link* rather than HEAD-probed, precisely because the removed probe (U7) both caused the list-wipe bug and was unreliable cross-origin. The mirror is always shown as a visible fallback.
**Verify:** a release carrying a GitHub `download_url` shows GitHub as primary; one without still gets a conventional GitHub link + mirror; neither present → unavailable badge with the list intact. Change-log `20260531-015730`.

### U9 — LOW (branding + premium UX, IMPLEMENTED Round 3b/3c)
Real brand/ecosystem and the optional premium upgrades were applied (work logged in change-logs `20260531-012008` and `20260531-015730`):
- **Branding:** real logo (`https://ownpay.org/ownpay_logo.png`, with a gradient-"OP" `onerror` fallback) + favicon/apple-touch (`ownpay_icon.png`) + Open Graph tags; footer ecosystem nav (Home / Blog / Learn / Support / Docs) + GitHub & Facebook social.
- **UX:** sticky top-nav; hero band with a copy-able `sha256sum -c checksum.sha256` verify command; light/dark theme toggle with an anti-flash `localStorage` init; release search/filter (by version/date) with an empty-state note.
- **Hardening:** `Content-Security-Policy` `<meta>` + `color-scheme`; `marked`/DOMPurify pinned (`@12` / `@3`); changelog still rendered via `DOMPurify.sanitize(marked.parse(...))`.
- **Remaining (folds into U3):** add real SRI and/or self-host `marked`+DOMPurify under `/vendor` to drop the CDN; tighten CSP from `'unsafe-inline'` to nonces/hashes.

---

## On "is there any information leaking?" — explicit answer
No sensitive leakage. The only data surfaced is **intended public release metadata**:
- checksums + signatures → required for clients to verify integrity/authenticity (public by nature).
- migration filenames + breaking notes → normal open-source release transparency; they reveal *that* a schema change exists, not secrets.
- No private key, `.env`, server path, DB detail, or customer data appears on the page or in `manifest.json`.

The page is safe to expose publicly. Apply U1 (size bug) and U2/U3 (sanitize + SRI/CSP) before relying on it for production releases; U4/U5 are polish.
