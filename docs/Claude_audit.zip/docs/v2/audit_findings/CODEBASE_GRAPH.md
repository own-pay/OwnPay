# OwnPay — Codebase Graph & Criticality Map

> Visual map of the OwnPay codebase with **criticality annotations**. "Critical" = editing this carelessly can break the whole system or money/security flows — change it only with tests and understanding. Tiers: 🔴 **critical** (money/security/bootstrap core) · 🟠 **supporting** (important, scoped blast radius) · 🟢 **leaf** (low risk).

## 1. Directory map (application; `vendor/`, `node_modules/` omitted)
```
public/index.php            🔴 single front controller (only PHP file in webroot)
src/
  Kernel.php                🔴 boot + request lifecycle orchestrator
  Container.php             🔴 PSR-11 DI + reflection autowiring
  Core/Database.php         🔴 PDO wrapper, transactions, prepared stmts, query hooks/sandbox
  Http/{Request,Response,Router}.php   🔴 HTTP layer + routing
  Repository/{BaseRepository,TenantScope}.php  🔴 CRUD + tenant isolation
  Repository/*Repository.php           🟠 per-table data access (35+)
  Service/Payment/*        🔴 Ledger, Refund, GatewayApi, Transaction, Invoice, Fee, Currency, Idempotency, Mfs
  Service/{Sms,Device,Domain,Brand,Notification,Auth,Gateway,System,Admin,Customer,Communication}/*  🟠
  Middleware/*             🔴 Session/Csrf/Permission/JwtAuth/SecurityHeaders/RateLimiter/Domain (16)
  Gateway/{GatewayAdapterInterface,GatewayBridge,WebhookInboundProcessor,GatewayDefaults}.php  🔴
  Plugin/{PluginLoader,PluginRegistry,PluginSandbox,PluginManager,...}.php  🔴 sandbox/loading
  Event/EventManager.php    🔴 hooks/filters + sandbox enforcement
  Security/*               🔴 Authenticator, FieldEncryptor, UrlValidator, ...
  Cron/*                   🟠 SmsVerification, BalanceVerification, QueueWorker, CurrencyUpdate, WebhookRetry, SystemUpdate
  Update/*                 🟠 UpdateService, BackupService, HealthChecker, MaintenanceMode
  Cache/*, Queue/*, View/*, Support/*, Enum/*, Model/*  🟢/🟠
config/{services,middleware,routes/*,app,database,hooks}.php  🔴 wiring
database/schema.sql         🔴 source of truth for 52 tables
modules/gateways/* (~140)   🟠 payment adapters · modules/addons/* · modules/themes/*
templates/* (79 Twig)       🟢 views (autoescaped) · public/assets/*  🟢
cli/{build-update,create-module}.php  🟠 build tooling (not shipped at runtime)
update/ (index.html, manifest.json, releases/, *.pem)  🟠 update server side
```

## 2. Bootstrap & request lifecycle
```mermaid
flowchart TD
  IDX[public/index.php] --> K[Kernel::handle]
  K --> BOOT[Kernel::boot]
  BOOT --> ENV[.env load] --> DI[config/services.php → Container] --> PLUG[PluginLoader::boot]
  PLUG --> MW[config/middleware.php + AUD-21 re-assert] --> RT[Router::loadRoutes]
  K --> REQ[Request::capture] --> FR[filter system.request]
  FR --> PR[processRequest: install/maintenance gate]
  PR --> MATCH[Router::match] --> ONION[middleware onion: global+group]
  ONION --> CTRL[Controller@action] --> RESP[Response]
  RESP --> FRESP[filter system.response] --> SEND[send] --> SHUT[action system.shutdown]
```

## 3. Layer dependency (allowed direction = downward)
```mermaid
flowchart TD
  C[Controllers] --> S[Services]
  S --> R[Repositories + TenantScope]
  R --> DB[(Core\Database / PDO)]
  C -.uses.-> MW[Middleware]
  S --> GW[Gateway\Bridge → modules/gateways]
  S --> EV[Event\EventManager]
  EV --> SB[Plugin\PluginSandbox]
  S --> SEC[Security\*]
  classDef crit fill:#3a1f1f,stroke:#e17055,color:#fff;
  class C,S,R,DB,MW,GW,EV,SB,SEC crit;
```

## 4. Payment + callback flow
```mermaid
sequenceDiagram
  participant Cust as Customer
  participant CO as CheckoutController
  participant GAS as GatewayApiService
  participant BR as GatewayBridge→Adapter
  participant WH as UnifiedWebhookController
  participant LS as LedgerService
  Cust->>CO: open checkout
  CO->>GAS: initiatePayment()
  GAS->>BR: initiate() (real cURL)
  BR-->>Cust: redirect to gateway
  Cust->>WH: gateway callback /webhook/{gw}
  WH->>WH: verifyWebhookSignature (403 on fail)
  WH->>GAS: handleCallback() [FOR UPDATE]
  GAS->>LS: recordPaymentReceived() (debit==credit)
  Note over GAS: ⚠ FIND-003 getInstance throw breaks this entry today
```

## 5. SMS / MFS ingestion + matching
```mermaid
flowchart LR
  APP[Companion App] -->|GCM POST| SC[Api/Mobile/SmsController]
  SC --> SPS[SmsParserService::processBatch]
  SPS --> DEC[AES-256-GCM decrypt] --> DEDUP[isDuplicate] --> RX[SmsRegexParser] --> HEU[SmsHeuristicParser]
  RX --> STORE[(op_sms_parsed)]
  CRON[Cron/SmsVerificationJob] --> STORE
  CRON --> MATCH[findByTrxId → findPendingMatch] --> LS[LedgerService.recordPaymentReceived]
  CFG[ConfigController filter-rules] -->|whitelist + negative kw| APP
```

## 6. Plugin / event / sandbox
```mermaid
flowchart TD
  PL[PluginLoader::discover modules/*] --> PR[PluginRegistry]
  PR --> EM[EventManager addAction/addFilter owner-scoped]
  EM -->|brand active?| ISA[isOwnerActive → BrandContext]
  EM -->|db.query.before| SBX[PluginSandbox::validateSql]
  DBE[Database::execute] --> SBX
  classDef crit fill:#3a1f1f,stroke:#e17055,color:#fff;
  class PL,PR,EM,SBX,DBE crit;
```

## 7. Critical Components table — what's critical & WHY (read before editing)

| Tier | Component (file) | What it is | Why critical — what breaks if edited carelessly | Edit-safety |
|---|---|---|---|---|
| 🔴 | `src/Kernel.php` | Boot + lifecycle | Wrong boot order or middleware handling can disable security middleware, break plugin/hook injection, or 500 every request. AUD-21 re-assert and AUD-G1 plugin-before-middleware ordering are load-bearing. | Never reorder boot steps or remove the security-middleware re-assert. Test full request + admin auth after any change. |
| 🔴 | `src/Container.php` | PSR-11 DI + autowiring | A resolution/cycle bug breaks construction of *every* service. | Don't change resolution semantics without the container tests; avoid new circular deps. |
| 🔴 | `src/Core/Database.php` | PDO wrapper, `transaction()`, typed binding, query hooks/sandbox | Any change to binding/`EMULATE_PREPARES` reopens SQLi; breaking `transaction()` reentrancy breaks refund/ledger atomicity; the `db.query.before` filter + sandbox gate plugin SQL. | Keep `ATTR_EMULATE_PREPARES=false` + typed `bindValue`; keep nested-transaction guard; never interpolate params. |
| 🔴 | `src/Repository/TenantScope.php` + `BaseRepository.php` | Tenant isolation + CRUD/fillable | Weakening `requireTenant()` (fail-closed) or the `updateScoped` `merchant_id` unset = cross-brand data leakage/IDOR. Empty `$fillable` disables mass-assignment protection. | Always go through `forTenant()`; never relax the scope check; keep `$fillable` defined on new repos. |
| 🔴 | `src/Service/Payment/LedgerService.php` | Double-entry ledger | Breaking the debit==credit assertion or double-post guard corrupts the books / enables double-credit. | Keep the bccomp balance check + FOR UPDATE idempotency guard; test with imbalanced + duplicate inputs. |
| 🔴 | `src/Service/Payment/RefundService.php` | Refund lifecycle | Removing the FOR UPDATE locks/over-refund/negative guards enables double or excess refunds (direct loss). | Preserve all guards; move the gateway HTTP **out** of the txn (FIND-002) carefully. |
| 🔴 | `src/Service/Payment/GatewayApiService.php` | Payment init + callback completion | Trusting callback amount or skipping signature verify enables free/underpaid orders; uses the stored amount today (good). | Keep stored-amount completion; add the amount-equality check (FIND-016); don't bypass `verify`. |
| 🔴 | `src/Gateway/GatewayAdapterInterface.php` + `GatewayBridge.php` + `modules/gateways/*` | Gateway contract + adapters | An adapter that accepts `mock_` in live or `verifyWebhook(){return true}` = payment bypass (FIND-004/005). Changing the interface ripples to ~140 adapters. | Enforce secure-by-default via an abstract base + CI conformance test; never weaken `verify`/`verifyWebhook`. |
| 🔴 | `src/Event/EventManager.php` + `Plugin/PluginSandbox.php` | Hooks/filters + plugin SQL sandbox | A regression lets a plugin rewrite core SQL or run for the wrong brand. | Keep owner-stack push/pop, brand-scoped `isOwnerActive`, and the `db.query.before` sandbox re-check (default-deny null sandbox — FIND-009). |
| 🔴 | `src/Middleware/{JwtAuth,SecurityHeaders,Csrf,Permission,Session,RateLimiter,Domain}.php` | Security middleware | Removing/misordering = auth bypass, CSRF, missing CSP/HSTS, or brand-scope leak. Note FIND-019 (pairing must be on a non-JWT bootstrap group). | Changes require an auth + headers regression pass; never make a missing middleware silently skip. |
| 🔴 | `config/{services,middleware,routes/*}.php` | Wiring | A bad binding/group breaks DI or silently drops a security layer from a route. | Keep service↔consumer signatures in sync; verify middleware groups per route. |
| 🔴 | `database/schema.sql` | Schema source of truth | Drift from code = runtime failures (see `op_alerts`/`op_job_queue`). Column renames break repositories. | Change schema **and** code together; ship a forward migration; keep strict column names. |
| 🟠 | `src/Cron/*` | Scheduled jobs | A broken job silently stops reconciliation/queue/SMS-matching (FIND-S2). | Verify the cron runner registration + the table it touches. |
| 🟠 | `src/Update/UpdateService.php` + `cli/build-update.php` | Self-update + packaging | A signature/verify regression or a bad zip (FIND build-update B1) breaks updates/installs platform-wide. | Keep SHA-256+RSA verify; test "zip = fresh install" after builder edits. |
| 🟠 | `src/Service/Sms/*` + `Repository/Sms*` | MFS matching | Parser/arg or dedup changes mis-credit or fail to credit offline payments (FIND-001/017/018). | Keep `attemptParse($rawMessage,$sender,$brandId)` order; test regex+heuristic+match. |
| 🟢 | `templates/*` (Twig) | Views | Twig autoescape protects most XSS; risk only via `\| raw` on attacker-controlled data. | Don't pipe untrusted data through `\| raw`. |
| 🟢 | `public/assets/*`, `src/View/*`, `Support/*`, `Enum/*` | Presentation/util | Low blast radius. | Normal review. |

## 8. Golden rules (derived from the criticality map)
1. **Never** call `Database::getInstance()` — inject `Database` (FIND-003).
2. **Always** scope brand data via `->forTenant($mid)`.
3. **Never** let a gateway adapter accept `mock_` in live or return `true` from `verifyWebhook` without verifying.
4. **Never** remove/relax a security middleware or the ledger balance/refund guards.
5. **Change schema and code together**, with a migration.
6. Run **PHPStan L9 + the test suite** after touching any 🔴 component.
