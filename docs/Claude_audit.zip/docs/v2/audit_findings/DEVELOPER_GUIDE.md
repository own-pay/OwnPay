# OwnPay — Developer Guide

> Practical onboarding + day-to-day guide for working on OwnPay. Read alongside `ARCHITECTURE.md` (how it's built) and `CODEBASE_GRAPH.md` (what's critical). Conventionally a root doc; placed here per the audit bundle.

## 1. Prerequisites & local setup
- **PHP 8.2+** with extensions: `pdo_mysql, curl, openssl, mbstring, json, bcmath, fileinfo, gd` (the installer Step 1 checks these).
- **Composer 2.4+**, **MySQL/MariaDB**, **Node 18+** (only for JS/CSS linting).
- Local stack: XAMPP works (PHP at `C:\xampp\php\php.exe`, composer phar at `C:\xampp\php\composer.phar`).
```bash
composer install                 # PHP deps (dev incl.)
npm install                      # only for eslint/stylelint
# Document root should be the project root or public/ (.htaccess rewrites all → public/index.php)
# Then visit the site → the install wizard runs (writes .env + storage/.installed)
```
> ⚠ **Known issue (FIND-006):** the pinned `phpunit ^12.5` requires PHP **8.3**, but the project targets 8.2 — the test suite won't run on 8.2 until this is aligned. See `IMPLEMENTATION_PLAN.md` B3.

## 2. Running & installing
All requests route through `public/index.php` (front controller). Until `storage/.installed` exists, the app redirects to `/install` (a 4-step wizard: requirements → DB → admin → settings). The wizard generates `APP_KEY`, `ENCRYPTION_KEY`, `JWT_SECRET`, `AUDIT_HMAC_SECRET` (all CSPRNG) and seeds currencies/permissions. Never commit `.env`.

## 3. Layout & where things live
See `CODEBASE_GRAPH.md` §1. In short: controllers in `src/Controller/*`, business logic in `src/Service/*`, data access in `src/Repository/*`, SQL schema in `database/schema.sql`, routes in `config/routes/*`, DI in `config/services.php`, middleware groups in `config/middleware.php`, payment adapters in `modules/gateways/*`.

## 4. Core patterns (the way OwnPay does things)

### Request → Controller → Service → Repository → Database
Controllers are thin; they read the `Request`, call a Service, return a `Response`. Services orchestrate; Repositories own SQL. Controllers must **never** touch PDO directly.

### Tenant scoping — ALWAYS
Every brand-owned query goes through `->forTenant($merchantId)`:
```php
$txn = $this->transactions->forTenant($mid)->findByTrxId($trxId);   // scoped clone
$id  = $this->invoices->forTenant($mid)->createScoped($data);       // injects merchant_id
```
`requireTenant()` throws if you forget — that's intentional (fail closed). `updateScoped()` ignores any `merchant_id` in the payload (no cross-tenant migration). New repositories must declare `$fillable` (mass-assignment allowlist).

### Dependency injection (no service locators)
Register services in `config/services.php` as singletons; constructor-inject dependencies. The container autowires unregistered classes by reflection. **Do not** use `Database::getInstance()` (FIND-003) — inject `OwnPay\Core\Database`.

### Database access
```php
$rows = $db->fetchAll("SELECT * FROM op_x WHERE merchant_id = :mid", ['mid' => $mid]);
$db->transaction(function () use ($db) { /* ... */ });   // reentrant; rolls back on throw
```
Always parameterize. Never string-concat user input into SQL. Column/table identifiers that must be dynamic go through `sanitizeColumn()` / the table-name regex.

### Events & hooks
```php
$events->addAction('payment.transaction.completed', [$this, 'onPaid'], 15, $ownerSlug);
$value = $events->applyFilter('checkout.csp.sources', $value);
```
Actions are fire-and-forget; filters mutate a value. Plugin hooks run **only when the plugin is active for the current brand**. Filters are untyped — consumers must validate the returned type (core does, e.g. `Kernel.php:54`).

## 5. Adding a payment gateway (the secure way)
1. Scaffold: `php cli/create-module.php` → choose "Gateway", pick a category. It creates `modules/gateways/<slug>/{manifest.json,<Studly>Gateway.php,assets/}`.
2. Implement `GatewayAdapterInterface`:
   - `initiate()` — make a **real** outbound cURL call to the provider; return the redirect/form.
   - `verify()` — **query the provider API** to confirm the payment; **never** trust callback params; reject `mock_*` tokens when `mode==='live'`.
   - `verifyWebhook()` — real constant-time signature check (`hash_equals`); **never** `return true` blindly.
   - `refund()` — call the provider; never fake success.
3. Declare CSP sources in `manifest.json` (consumed by `SecurityHeadersMiddleware`).
4. Test in sandbox, then live. The CI **gateway-conformance test** (see `IMPLEMENTATION_PLAN.md` A2) will reject un-gated `mock_` and no-op `verifyWebhook`.
> The current scaffold ships insecure defaults (FIND-004/005 pattern) — until `create-module.php` is fixed (M1), replace the generated `verify()`/`verifyWebhook()` with real logic before shipping.

## 6. Adding an addon / theme
`create-module.php` also scaffolds addons (capability picker → `Capability` enum; hooks/routes/settings in manifest) and themes (PHP or Twig engine). Note the scaffold bugs to fix: addon `handleWebhook` should use `$req->json()` (not `jsonBody()`); theme PHP path's `$this->events` is invalid (see `MODULE_BUILDER_REVIEW.md`).

## 7. Tooling
```bash
php vendor/bin/phpstan.phar analyse        # level 9 — keep it at 0 errors
php vendor/bin/phpunit                      # FIND-006: needs PHP 8.3 today (align first)
php vendor/bin/parallel-lint src cli modules config
php vendor/bin/twig-cs-fixer lint templates
npm run lint:js && npm run lint:css
php composer.phar audit ; npm audit         # keep at 0 advisories
```
PHPStan level 9 currently passes with **0 errors** — keep it that way; it's the main automated safety net while the unit tests are blocked.

## 8. Build & release
`php cli/build-update.php` packages a signed release zip + updates `update/manifest.json`. Key facts (and pending fixes in `UPDATE_BUILDER_REVIEW.md`):
- The zip is **both** the self-update payload **and** a fresh-install bundle.
- `vendor/` is included (use `--no-dev` so PHPUnit/PHPStan don't ship).
- The **public key** is embedded in `src/Update/UpdateService.php` (`UPDATE_PUBLIC_KEY`) and **not** bundled as a file; the **private key never ships**.
- Until B1 is fixed, the zip omits the `storage/` skeleton → a fresh install fails; add the empty-dir skeleton first.

## 9. Conventions
- `declare(strict_types=1)` everywhere; PSR-4 (`OwnPay\` → `src/`, `OwnPay\Modules\…` → `modules/`).
- Full docblocks on public methods (the codebase is heavily annotated for PHPStan L9).
- DB tables are `op_`-prefixed (configurable prefix `{$p}` at install). Money in DECIMAL + `bcmath`; never float arithmetic for money.
- Follow `CLAUDE.md`: pre-change declaration, timestamped change-logs in `output/change-log/`, snapshots before bulk edits, no blind global replace, no destructive rollback.

## 10. Gotchas / Do-not list
- ❌ `Database::getInstance()` (broken in prod) → ✅ inject `Database`.
- ❌ a gateway that returns success for `mock_` in live, or `verifyWebhook(){return true}`.
- ❌ querying brand data without `forTenant()`; ❌ a repo without `$fillable`.
- ❌ removing/reordering security middleware; ❌ `| raw` on untrusted data in Twig.
- ❌ external HTTP inside a DB transaction holding a row lock (FIND-002).
- ❌ editing `schema.sql` without a matching code change + migration (and vice-versa).
- ✅ run PHPStan L9 + (once runnable) the tests after touching any 🔴 component (`CODEBASE_GRAPH.md`).

## 11. Reference
- Findings + severities: `ownpay_master_audit_report.md`
- Ordered fixes → first release: `IMPLEMENTATION_PLAN.md`
- Security posture: `SECURITY_AUDIT_V2.md`
- CLI/update/schema reviews: `UPDATE_BUILDER_REVIEW.md`, `MODULE_BUILDER_REVIEW.md`, `UPDATE_SERVER_REVIEW.md`, `SCHEMA_REVIEW.md`
- Architecture & criticality: `ARCHITECTURE.md`, `CODEBASE_GRAPH.md`
