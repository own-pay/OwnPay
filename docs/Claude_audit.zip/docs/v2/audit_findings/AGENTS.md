# AGENTS.md — OwnPay Agent & Contributor Guidelines

> Operating rules for AI agents (and humans) working on **OwnPay**, a self-hosted, single-owner, multi-brand payment gateway. OwnPay moves real money — a single logic gap, race condition, IDOR, or verification bypass can cause direct financial loss. Treat every change with that gravity. (Conventionally a root file; placed here per the audit bundle.)

## 0. Read first
`ARCHITECTURE.md` (how it works) · `CODEBASE_GRAPH.md` (what's critical & why) · `DEVELOPER_GUIDE.md` (how to build things) · `ownpay_master_audit_report.md` + `IMPLEMENTATION_PLAN.md` (open issues & the path to release) · the project root `CLAUDE.md` (mandatory working policy).

## 1. The Sovereign Core Principle (never violate)
OwnPay is **single-owner, multi-brand** — NOT SaaS multi-tenant. One super-admin owns the platform; brands ("stores") operate under it; staff belong to brands. The DB tenant key is **always `merchant_id`** (UI calls it "Brand/Store"). Any change that breaks brand isolation, lets staff/clients of Brand A reach Brand B, or bypasses scoping is **release-blocking**.

## 2. Hard rules (do / don't)
**DO**
- Inject dependencies via the DI container; constructor-inject `OwnPay\Core\Database`.
- Scope every brand query with `->forTenant($merchantId)`; declare `$fillable` on new repositories.
- Use prepared statements with bound params for **all** SQL; `bcmath` (never float) for money.
- Make gateways **secure-by-default**: `verify()` queries the provider; reject `mock_*` when `mode==='live'`; `verifyWebhook()` does a real `hash_equals` check; `refund()` calls the provider or throws.
- Keep changes to schema and code **together**, with a forward migration.
- Follow `CLAUDE.md`: pre-change declaration → timestamped change-log in `output/change-log/` → snapshot before bulk edits → post-change report. Use the planning-with-files skill (`.planning/`), and **re-attest** `task_plan.md` after each edit.

**DON'T**
- ❌ Use `Database::getInstance()` (it throws in prod — FIND-003).
- ❌ Ship a gateway that auto-confirms a `mock_` token in live, or `verifyWebhook(){ return true; }` (FIND-004/005).
- ❌ Remove, reorder, or weaken security middleware (Session/Csrf/Permission/JwtAuth/SecurityHeaders/RateLimiter/Domain), or the ledger balance / refund guards.
- ❌ Query brand data without tenant scope; ❌ pipe untrusted data through Twig `| raw`.
- ❌ Make an external HTTP call inside a DB transaction holding a row lock (FIND-002).
- ❌ Put pairing/bootstrap routes behind the JWT middleware (FIND-019).
- ❌ Run destructive git/file operations or blind global replaces (CLAUDE.md §4/§6).

## 3. Critical files — handle with extreme care
The 🔴 components in `CODEBASE_GRAPH.md` §7: `Kernel.php`, `Container.php`, `Core/Database.php`, `Repository/{TenantScope,BaseRepository}.php`, `Service/Payment/{Ledger,Refund,GatewayApi}.php`, `Gateway/*` + `modules/gateways/*` contract, `Event/EventManager.php` + `Plugin/PluginSandbox.php`, the security middleware, `config/{services,middleware,routes}.php`, and `database/schema.sql`. Editing any of these can break money flows or security platform-wide — change only with understanding, tests, and a change-log entry.

## 4. Security mandates (payment-grade)
- Verification > trust: never complete a payment on a callback's say-so without provider verification + amount match (FIND-016).
- Fail **closed**: auth, rate limiting, and plugin sandboxing should deny on error, not allow (FIND-007/009).
- Secrets: never log JWTs, reset tokens, raw SMS bodies, or card data; webhook logs store payload **hashes** only. Never commit `.env` or the update **private key**.
- Crypto: `random_bytes`/`random_int` for tokens/OTPs; Argon2id for passwords; HS256 JWT with hardcoded alg.

## 5. Required verification before you call a task "done"
1. `php vendor/bin/phpstan.phar analyse` → **0 errors** (level 9).
2. `php vendor/bin/phpunit` green (once FIND-006 is fixed) — at minimum add/adjust tests for what you changed.
3. `parallel-lint` + `twig-cs-fixer` + `eslint`/`stylelint` clean for touched code; `composer audit`/`npm audit` = 0.
4. If you touched a 🔴 component: prove the end-to-end flow (create→pay→callback→refund, or pair→ingest→match).
5. If the task is **audit/analysis only**: make **no** code edits — deliver markdown; state explicitly that no source changed.

## 6. Workflow & memory (Manus-style, mandatory here)
- Before multi-step work, create/restore `.planning/{date-task}/` (`task_plan.md`, `findings.md`, `progress.md`). Apply the **2-action rule** (write findings after ~2 reads), **read-before-decide** (re-read the plan before key decisions), and the **3-strike protocol** (escalate after 3 failed attempts).
- "Guess nothing": cite exact `file:line` and paste evidence for any claim; don't fabricate.

## 7. Conventions
PSR-4 + `declare(strict_types=1)`; full docblocks (needed for PHPStan L9); `op_`-prefixed tables; thin controllers / logic in services / SQL in repositories. Keep new code consistent with the heavily-annotated existing style.

## 8. Current release blockers (context for any work right now)
`FIND-003` (DI/getInstance), `FIND-004/005` (gateway verification bypass + the scaffold that reproduces it), `FIND-019` (pairing JWT deadlock), `FIND-S1/S2` (`op_alerts`/`op_job_queue` schema), `FIND-006` (test suite unrunnable). Don't add features that depend on the queue, alerts, refunds, or gateway callbacks until these are closed (see `IMPLEMENTATION_PLAN.md`).

> Golden rule: **when unsure whether a change is safe, check `CODEBASE_GRAPH.md` for the component's criticality, write down your plan, and verify with tests — money and trust are on the line.**
