# OwnPay — Production Implementation Plan (Path to First Release)

> The ordered, copy-pasteable remediation plan for every finding in `ownpay_master_audit_report.md` plus the Round-2 reviews (`UPDATE_BUILDER_REVIEW.md`, `MODULE_BUILDER_REVIEW.md`, `UPDATE_SERVER_REVIEW.md`, `SCHEMA_REVIEW.md`). Markdown-only — no code is applied here; this is the build sheet for a later write-enabled run.
>
> **Release rule:** OwnPay does **not** ship until every item in **Phase A (Release Blockers)** is closed and the **Release Gate Checklist** (bottom) is fully green.

## How to use this
Work top-down. Each item has: **Where** (file:line) · **Fix** (exact code/diff intent) · **Verify** (how to prove it's fixed). Do Phase A first (these break or bypass money flows), then B, then C. Re-run PHPStan L9 + the test suite after each phase.

---

## PHASE A — Release Blockers (must all be closed)

### A1 · FIND-003 (CRITICAL) — `Database::getInstance()` throws in prod → refunds + gateway callbacks dead
**Where:** `src/Core/Database.php:126-132`; callers `src/Service/Payment/RefundService.php:80`, `src/Service/Payment/GatewayApiService.php:193`, `src/Controller/Checkout/CheckoutController.php:796`.
**Fix (preferred — DI):** add `Database` as a constructor dependency to `RefundService`, `GatewayApiService`, `CheckoutController`; replace `Database::getInstance()` with `$this->db`; register the dependency in `config/services.php`. **Fallback (fast):** in the `Database` factory (`config/services.php:106-108`) populate the singleton:
```php
// Database.php — add:
public static function setInstance(self $i): void { self::$instance = $i; }
// config/services.php:106-108 — make the factory:
$db = new \OwnPay\Core\Database(ensureType($c->get(\PDO::class), \PDO::class));
\OwnPay\Core\Database::setInstance($db);   // so getInstance() == container instance
return $db;
```
**Verify:** boot-replica probe (autoload+.env+services.php) → `Database::getInstance()` returns the instance (no throw); issue a sandbox gateway webhook → transaction transitions to `completed`; create a refund → succeeds. Add a regression test asserting `getInstance() === container->get(Database::class)`.

### A2 · FIND-004 (CRITICAL) — un-gated `mock_` payment-confirmation bypass (affirm/afterpay/bitpay…)
**Where:** `modules/gateways/affirm/AffirmGateway.php:130-133,156-162,214-219`, `…/afterpay/AfterpayGateway.php:119-122,145-151,195-198`, `…/bitpay/BitpayGateway.php:132-138` (audit all adapters).
**Fix:** in every adapter, gate the `mock_` acceptance to non-live (mirror `apple-pay`/`google-pay`), remove the live mock-token fallback in `initiate()`, and replace `verifyWebhook(): return true` with a real constant-time check. Then institutionalize it:
1. Add an **abstract `BaseGateway`** (or trait) that provides a final `verify()` wrapper rejecting `mock_*` when `mode==='live'`.
2. Add a **CI conformance test** that fails the build if any `modules/gateways/*` file matches `str_starts_with($…, 'mock_')` without an adjacent `mode==='live'` guard, or contains `verifyWebhook(...){ return true; }`.
**Verify:** the conformance test passes for the whole fleet; manual: a `mock_` token returns `failed` in live mode for every adapter.

### A3 · FIND-019 (HIGH/blocker) — device pairing blocked by JWT middleware
**Where:** `config/routes/api.php:40` (+ token-refresh `:54`), `config/middleware.php:72-76`, `src/Middleware/JwtAuthMiddleware.php:47-54`.
**Fix:** add a JWT-free bootstrap group and move pairing + token-refresh to it (OTP / refresh-JWT-in-body authenticate them):
```php
// config/middleware.php
'mobile-bootstrap' => [\OwnPay\Middleware\CorsMiddleware::class, \OwnPay\Middleware\RateLimiterMiddleware::class],
// config/routes/api.php
$router->post('/api/mobile/v1/devices', 'Api\\Mobile\\DeviceController@pair', 'mobile-bootstrap');
$router->post('/api/mobile/v1/devices/token-refreshes', 'Api\\Mobile\\DeviceController@refresh', 'mobile-bootstrap');
```
**Verify:** a tokenless device completes pairing (201); refresh works with an expired access token; all other `/api/mobile/v1/*` still 401 without a valid JWT.

### A4 · FIND-005 (HIGH) — gateway `verifyWebhook`/`refund` stubs
**Where:** e.g. `affirm:214-219`, `afterpay:195-198`, `2checkout:241-259` (header-presence only) + `:308-315` (`refund` always-success). Audit all adapters.
**Fix:** implement real per-provider signature verification (`hash_equals`); `refund()` must call the provider API or return an explicit unsupported error — never fake success. Covered by the same A2 conformance test (extend it to flag `refund(){ return ['success'=>true…] }` without an HTTP call).
**Verify:** unsigned webhook → 403; a refund with no provider call is impossible (test asserts a cURL/HTTP call or a thrown `NotSupported`).

### A5 · FIND-S1 + FIND-S2 (HIGH; live) — schema gaps break alerts + the queue
**Where:** `database/schema.sql` (+ a forward migration). See `SCHEMA_REVIEW.md` for the exact `CREATE TABLE op_alerts` and `op_job_queue` DDL.
**Fix:** add `op_alerts`; add `op_job_queue` matching `QueueWorkerJob` (retire `op_queue_jobs`). Ship both in `schema.sql` (fresh install) **and** as `update/releases/<next>/migrations/*.sql` (existing installs).
**Verify:** cron `QueueWorker` runs clean (no "table not found"); a forced balance discrepancy writes an `op_alerts` row and surfaces in the admin alerts panel.

### A6 · build-update B1 (BLOCKER) — zip is not a valid fresh-install
**Where:** `cli/build-update.php:406` (storage excluded), `:502-516` (files-only). See `UPDATE_BUILDER_REVIEW.md` §3.
**Fix:** keep storage *contents* excluded but `addEmptyDir()` + `.gitkeep` the runtime skeleton (`storage`, `storage/cache`, `storage/logs`, `storage/temp`, `storage/languages`, `public/assets/uploads`).
**Verify:** extract a freshly-built zip into an empty docroot → installer Step 1 shows "Writable: storage/ = Yes" → full install completes with no errors.

> **Phase A exit:** A1–A6 closed. At this point refunds work, callbacks complete, no free-payment bypass, pairing works, alerts+queue function, and the distributable zip installs cleanly.

---

## PHASE B — High Priority (before public launch)

### B1 · FIND-001 — `MfsService` parser argument swap (dead code trap)
`src/Service/Payment/MfsService.php:65`: fix to `parse($body, $sender, $merchantId)` **or delete the orphaned class**; add a unit test pinning parser argument order. (Live SMS path is already correct.)

### B2 · FIND-002 — external gateway HTTP inside the refund DB transaction
`src/Service/Payment/RefundService.php:83-207` (call at `:170`). Restructure to a saga: reserve+validate in a short txn → call the gateway **outside** the txn → finalize status+ledger in a second short txn. **Verify:** concurrent refund load test shows no lock-wait timeouts; row lock is not held across the HTTP call.

### B3 · FIND-006 — test suite unrunnable on PHP 8.2
`composer.json:7` (`^8.2`) vs `:37` (`phpunit ^12.5` needs 8.3). Either raise the floor to `^8.3` consistently (README + `InstallerController::checkRequirements:668`) or pin `phpunit ^11.5`. **Verify:** `vendor/bin/phpunit` runs green on the supported minimum PHP.

### B4 · build-update B2/B3 — production vendor + exclusion gaps
`cli/build-update.php`: use `composer install --no-dev --optimize-autoloader` for the packaged vendor; add `output/`, `.claude/`, `CLAUDE.md`, `ownpay_master_audit_prompt.txt` to exclusions (or switch to an allowlist). See `UPDATE_BUILDER_REVIEW.md` §2,§4. **Verify:** built zip contains no dev deps / no `.claude`/`output`; PHP-8.2-clean.

### B5 · create-module M1/M2 — secure-by-default scaffold
`cli/create-module.php`: generated `verify()`/`initiate()` should `throw "not implemented"` (not return success); `verifyWebhook()` fail-closed when no secret; fix `$req->jsonBody()` → `$req->json()`. See `MODULE_BUILDER_REVIEW.md` M1/M2. **Verify:** a freshly scaffolded gateway refuses to auto-confirm in live; a scaffolded addon webhook handler runs without fatal.

### B6 · index.html U1/U2 — size bug + unsanitized changelog
`update/index.html:685` (formatBytes) and `:875,:945` (sanitize `marked.parse` with DOMPurify). See `UPDATE_SERVER_REVIEW.md`. **Verify:** correct sizes render; a `<img onerror>` in a changelog does not execute.

---

## PHASE C — Medium/Low Hardening (fast-follow)

| ID | Where | Fix | Verify |
|---|---|---|---|
| FIND-016 | `GatewayApiService::handleCallback:211-227` | assert callback `amount` == stored order amount (±0.01) before completing | tampered low-amount callback → rejected |
| FIND-017 | manual checkout submit + `SmsVerificationJob:117` | store customer-entered provider TrxID into a matched column; key SMS matching on it | SMS auto-matches by provider TrxID, not only amount |
| FIND-007 | `RateLimiterMiddleware:115-119` | fail **closed** for login/2FA/pairing when limiter backend is down | DB-down → auth routes 503, not bypass |
| FIND-009 | `EventManager:317-330` + `PluginRegistry` | treat null sandbox as deny for `db.query.before` (or assign every plugin a default-deny sandbox) | a no-sandbox plugin cannot rewrite core SQL |
| FIND-008 | `src/Security/UrlValidator.php:145-184` | pin resolved IP for the outbound request (`CURLOPT_RESOLVE`); resolve AAAA | DNS-rebind + IPv6-internal blocked |
| FIND-010 | `DomainMiddleware:72` | only treat `localhost` as master when `REMOTE_ADDR` is loopback | spoofed `Host: localhost` cannot bypass brand scope |
| FIND-011 | `InvoiceService:142,152,218,227` | clamp `unit_price`/`discount` ≥ 0; cap discount ≤ subtotal+tax | negative-total invoice rejected |
| FIND-014 | `GatewayApiService::sanitizeFormHtml:249-271` | prefer an allowlist HTML sanitizer over regex; document inline-script trust boundary | malicious inline JS in `form_html` stripped |
| FIND-015 | `MobileNotificationService:226-239` | require the DB-backed repo; remove the shared-temp-file fallback | no notification data written to `sys_get_temp_dir()` |
| FIND-012 | `Authenticator::verifyCodeWithReplayGuard` | tighten TOTP drift to ±1 step | ±90s codes rejected |
| FIND-013 | `TransactionRepository::findPendingMatchGlobal` + ~24 no-`curl_exec` gateways | remove dead unscoped matcher; go-live review each skeleton gateway | dead method gone; skeleton gateways labeled |
| FIND-018 | `SmsDataRepository::isDuplicate` / `op_sms_parsed` | add a global `trx_id` uniqueness/dedup safeguard | replayed trx_id cannot create a second match path |
| FIND-020 | `database/schema.sql:740/774/846` | drop (or wire) dead tables `op_maintenance_locks`, `op_queue_jobs`, `op_plugin_settings`; fold `op_queue_jobs` into the FIND-S2 fix | grep shows 0 code refs; schema lints |
| create-module M3-M6 | `cli/create-module.php` | fix theme `$this->events`; create default icon; add README/test stub; slug-collision check | see `MODULE_BUILDER_REVIEW.md` |
| index.html U3-U5 | `update/index.html` | SRI+CSP on CDN; unify palette; render "latest" from `channels.*` | see `UPDATE_SERVER_REVIEW.md` |
| build-update B4-B6 | `cli/build-update.php` | auto-write public key into `UpdateService.php`; robust composer resolution; fix `release.json` notes | see `UPDATE_BUILDER_REVIEW.md` |

---

## Coverage map (every finding is accounted for)
| Finding | Phase |
|---|---|
| FIND-003, FIND-004, FIND-019, FIND-005, FIND-S1, FIND-S2, build-update B1 | **A (blocker)** |
| FIND-001, FIND-002, FIND-006, build-update B2/B3, create-module M1/M2, index.html U1/U2 | **B** |
| FIND-016, FIND-017, FIND-007, FIND-009, FIND-008, FIND-010, FIND-011, FIND-014, FIND-015, FIND-012, FIND-013, FIND-018, FIND-020, create-module M3-M6, index.html U3-U5, build-update B4-B6 | **C** |
| U7, U8, U9 (update page: list-resilience, GitHub-first, branding/UX), create-module M4 (scaffold CSRF) | **Addendum** (Round 3b/3c) |

---

## Release Gate Checklist (all must be ✅ to ship v1.0)
- [ ] A1 — `Database` resolved via DI; `getInstance()` no longer throws in prod (refunds + callbacks proven working).
- [ ] A2 — no gateway auto-confirms a `mock_` token in live; conformance test green across all `modules/gateways/*`.
- [ ] A3 — device pairing + token-refresh succeed without a pre-existing JWT.
- [ ] A4 — every gateway `verifyWebhook` does real signature verification; no `refund` fakes success.
- [ ] A5 — `op_alerts` + `op_job_queue` exist (schema + migration); QueueWorker + alerts run clean.
- [ ] A6 — a freshly-built release zip installs as a fresh OwnPay with **zero** errors.
- [ ] B3 — PHPUnit runs **green** on the declared minimum PHP; PHPStan L9 still 0 errors.
- [ ] Phase B complete (FIND-001/002, build-update, create-module, index.html size/XSS).
- [ ] `composer audit` / `npm audit` = 0; web-exposure check (`.env`, schema, logs) = 403/404.
- [ ] Full regression: create → pay (sandbox + one real gateway) → webhook complete → refund → ledger balanced; SMS device pair → ingest → match.
- [ ] Sign-off: the master report's severity matrix shows **0 CRITICAL, 0 release-blocking HIGH** open.

> When this checklist is green, OwnPay is ready for its first public release. Phase C should be scheduled as a fast-follow `0.1.x`.

---

## ADDENDUM — New Findings Implementation Plan (Round 3b/3c additions)

> Appended after the original A/B/C plan. These items were discovered/applied during the authorized `update/index.html` work and the create-module fixes; they are documented as findings in `UPDATE_SERVER_REVIEW.md` (U7–U9) and `MODULE_BUILDER_REVIEW.md` (M4). **Nothing above is removed** — this only adds the previously-missing fix-plans. Status reflects work already applied; remaining sub-tasks are called out so the plan stays the single source of truth.

### U7 · Update page (HIGH bug) — a broken *latest* release wiped the whole list — ✅ FIXED
**Where:** `update/index.html` — `renderChannel()` (~`:993`); the old `checkZipExists()` HEAD-probe gate (now removed).
**Problem:** `renderChannel()` was `async` and `await`ed `checkZipExists(latest.download_url)`; on a falsy result it did `historyList.innerHTML = ''; return`, so one bad/missing **latest** download blanked the entire channel — latest *and* every older version. Cross-origin HEAD was also unreliable (could false-negative a valid GitHub asset).
**Fix:** made `renderChannel()` synchronous; `const valid = (releases||[]).filter(r => r && r.version)`; feature `valid[0]`, render history `valid.slice(1)` **independently**; removed the HEAD gate; `downloadBlock()` shows a `Download unavailable` badge in-card instead of blanking.
**Verify:** manifest whose latest release has a broken/missing `download_url` → latest card + all older versions still render; an entry missing `version` is skipped, not fatal.
**Status:** ✅ applied Round 3c — change-log `20260531-015730`; inline JS syntax-validated.

### U8 · Update page (enhancement) — GitHub-first download + local mirror fallback — ✅ IMPLEMENTED
**Where:** `update/index.html` — `githubUrl()` (~`:910`), `localMirrorUrl()` (~`:920`), `downloadBlock()` (~`:930`).
**Fix:** GitHub is primary (manifest `github.com` `download_url`, else conventional `…/own-pay/OwnPay/releases/download/v<ver>/ownpay-<ver>.zip`); the same-origin mirror is a visible fallback link; an unavailable badge shows if neither resolves. No render-time HEAD probe (that was U7's root cause), so priority is GitHub-first without re-introducing the list-wipe risk.
**Verify:** a release with a GitHub `download_url` shows GitHub as primary; one without still gets a conventional GitHub link + a mirror link; neither present → unavailable badge, list intact.
**Status:** ✅ applied Round 3c — change-log `20260531-015730`.

### U9 · Update page (branding + premium UX) — ✅ IMPLEMENTED · ⏭️ SRI/self-host remaining
**Where:** `update/index.html` (head / style / body / inline script).
**Done:** real logo + favicon + OG tags; footer ecosystem nav (Home/Blog/Learn/Support/Docs) + GitHub & Facebook social; sticky top-nav; hero `sha256sum -c checksum.sha256` verify-command (copy button); light/dark theme toggle with anti-flash `localStorage` init; release search/filter; `CSP <meta>` + `color-scheme`; `marked`@12 / DOMPurify@3 pinned; changelog sanitized via `DOMPurify.sanitize(marked.parse(...))`.
**Remaining (folds into Phase C · index.html U3):** add real **SRI** hashes and/or self-host `marked`+DOMPurify under `/vendor` to drop the CDN dependency; tighten CSP from `'unsafe-inline'` to nonces/hashes.
**Verify:** logo/favicon load (gradient-"OP" fallback on error); nav links resolve; theme persists across reload with no flash; search filters cards; CSP header present.
**Status:** ✅ branding + UX applied Round 3b/3c — change-logs `20260531-012008`, `20260531-015730`. SRI/self-host = open (fast-follow).

### M4 · create-module (MEDIUM — scaffold CSRF) — reconciled, ✅ FIXED
> Makes the existing Phase-C "create-module M3-M6" bucket explicit; detailed in `MODULE_BUILDER_REVIEW.md` M4.
**Where:** `cli/create-module.php` — scaffolded checkout (Twig + raw-PHP template paths).
**Problem (two parts):** (1) the scaffold emitted a CSRF field named `csrf_token`, but `CsrfMiddleware` validates `_csrf_token` → every scaffolded-gateway checkout POST was rejected; (2) the raw-PHP template called `csrf_token()` as a function — it is a Twig global, not a PHP function, so that path fataled.
**Fix:** field renamed to `_csrf_token`; raw-PHP path emits `\OwnPay\Security\SecurityHelpers::csrfToken()`.
**Verify:** scaffold a gateway → its checkout POST passes CSRF validation; the raw-PHP template renders without a fatal.
**Status:** ✅ applied Round 3 — change-logs `20260531-010150`, `20260531-010947`.

### Addendum gate (fast-follow, not release-blocking)
- [x] U7 — broken latest release no longer hides older versions (resilient render).
- [x] U8 — GitHub-first download with same-origin mirror fallback.
- [x] U9 — branding + premium UX shipped on the registry page.
- [x] M4 — scaffolded-gateway checkout CSRF works; no raw-PHP `csrf_token()` fatal.
- [ ] U9/U3 remainder — real SRI or self-hosted `marked`/DOMPurify; CSP tightened off `'unsafe-inline'`.
