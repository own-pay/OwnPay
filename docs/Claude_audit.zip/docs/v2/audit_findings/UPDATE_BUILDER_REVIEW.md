# Update Builder CLI Review — `cli/build-update.php`

> Review of the OwnPay self-update release packager. Markdown-only (no code applied); all fixes are copy-pasteable. Every claim cites `cli/build-update.php` line numbers verified this session.

## Verdict
**Functional, but NOT release-ready.** The builder correctly signs, versions, and packages, and its exclusion list is mostly good. However it has **one release-blocking defect** (the produced zip cannot be used as a clean fresh-install because `storage/` and all empty directories are missing), **exclusion gaps** that leak non-project files into the zip, and a **`composer update` step** that ships dev dependencies (PHPUnit ^12.5 → PHP 8.3) into the distributed `vendor/`.

---

## ✅ Implemented this round (authorized: `build-update.php` + `cli/.buildignore`)
Per your direction, the builder now uses a **`.buildignore`** file — your proposed approach, **adopted** (it's more maintainable than the hardcoded arrays) — plus a hardcoded **secret hard-deny** safety net so a typo in `.buildignore` can never leak `.env`/private keys. The fresh-install **storage skeleton** is also shipped.

| Item | Status |
|---|---|
| `.buildignore`-driven exclusions (`cli/.buildignore` + gitignore-style loader in `build-update.php`) | ✅ implemented |
| Secret hard-deny net (`.env`, `.env.*`, `*private_key*.pem`, `.git/`) regardless of `.buildignore` | ✅ implemented |
| **B1** — `storage/` + `public/assets/uploads` skeleton via `addEmptyDir()` + `.gitkeep` (fresh-install fix) | ✅ implemented |
| **B3** — exclusion gaps (`output/`, `.claude/`, `CLAUDE.md`, `ownpay_master_audit_prompt.txt`, …) | ✅ now covered by `.buildignore` |
| **B2** — `composer install --no-dev` | ⏭️ skipped per your direction (build machine is fully set up) |
| **B5** — composer path resolution | ⏭️ skipped per your direction |
| **B4** — auto-write public key into `UpdateService.php` | ⛔ not applied (would edit an out-of-scope file) |

Verified: `php -l` clean; a path-matching probe passed **33/33** representative cases (secrets denied, project files kept, junk ignored, `.env.example`/`.htaccess`/`composer.*`/`vendor/` shipped). The `.buildignore` design and the rationale below remain the reference; B2/B5/B4 are retained for context only.

---

## 1. Is the builder "perfect"? — Issue summary

| # | Severity | Issue | Evidence |
|---|---|---|---|
| B1 | **BLOCKER** | `storage/` fully excluded + only `addFile()` (no empty dirs) → fresh install fails | `:406` (`'storage/'`), `:502-516` (`isFile()` only) |
| B2 | HIGH | `composer update` ships **dev** deps (phpunit ^12.5 needs PHP 8.3, phpstan) into `vendor/` | `:185-188` |
| B3 | MEDIUM | Exclusion gaps: `output/`, `.claude/`, `ownpay_master_audit_prompt.txt`, `CLAUDE.md` ship in the zip | `:395-446` |
| B4 | LOW | Public key must be **manually pasted** into `UpdateService.php` (error-prone) | `:163-165` |
| B5 | LOW | `passthru('composer update')` assumes `composer` on PATH; no fallback to `composer.phar` | `:185-188` |
| B6 | LOW | `release.json` `notes` hardcoded to `"Verified"`; `version_code` regex strips only suffixes | `:571`, `:609` |

---

## 2. Non-project files in the final zip — what leaks, and the fix

The builder uses three exclusion lists (`:395-451`) applied in `scanAndZip()` (`:458-519`). The current lists are good (they already drop `.git`, `.github`, `.agents`, `.antigravitycli`, `.vscode`, `.phpunit.cache`, `.planning`, `node_modules`, `docs`, `tests`, `cli`, `graphify-out`, `scratch`, `update`, `mobile_app`, plus `.env`, the key `.pem`s, lint configs, root `*.md` like AGENTS/ARCHITECTURE).

**But these non-project paths are NOT excluded and WILL ship:**
- `output/` — audit change-logs, phpstan/lint baselines (created during this engagement). **Not in `$rootExclusions`.**
- `.claude/` — Claude settings, skills, plans, attestations. **Not excluded** (only `.agents`/`.antigravitycli`/`.vscode` are). Could leak internal config.
- `ownpay_master_audit_prompt.txt` — the audit brief at repo root. **Not excluded.**
- `CLAUDE.md` — AI working-policy doc. **Not excluded** (other root `*.md` are individually listed, but `CLAUDE.md` is not).
- Any stray root `*.txt`/scratch files not individually named.

### Fix — corrected exclusion lists (drop-in replacement for `:395-446`)
```php
$rootExclusions = [
    '.git/', '.github/', '.agents/', '.antigravitycli/', '.vscode/', '.idea/',
    '.claude/',           // ADDED — Claude settings/skills/plans/attestations
    '.phpunit.cache/', '.planning/',
    'node_modules/', 'docs/', 'tests/', 'storage/', 'cli/',
    'graphify-out/', 'scratch/', 'output/',   // ADDED — audit/build artifacts
    'update/', 'mobile_app/',
];

$fileExclusions = [
    '.env', '.env.temp', '.gitignore', '.gitattributes', '.graphifyignore',
    '.twig-cs-fixer.cache', '.twig-cs-fixer.php', 'phpunit.xml', 'phpstan.neon',
    'nginx.conf.example',
    'CLAUDE.md',                          // ADDED
    'ownpay_master_audit_prompt.txt',     // ADDED
    'findings.md', 'progress.md', 'task_plan.md',
    'scratch_test.php', 'update_private_key.pem', 'update_public_key.pem',
    'eslint.config.js', 'stylelint.config.js', 'package.json', 'package-lock.json',
    'admin_errors.txt', 'admin_errors_left.txt', 'admin_phpstan_errors.txt', 'headers.txt',
    'AGENTS.md', 'ARCHITECTURE.md', 'CODE_OF_CONDUCT.md', 'CONTRIBUTING.md',
    'ROADMAP.md', 'SECURITY.md', 'SUPPORT.md',
];
```
> Defense-in-depth alternative: switch from a denylist to an **allowlist** of known project roots (`src`, `config`, `database`, `modules`, `public`, `templates`, `vendor`, `composer.json`, `composer.lock`, `.htaccess`, `.env.example`, `README.md`, `LICENSE`). An allowlist can never leak a newly-added junk file.

**Vendor:** correctly **kept** (not excluded) — satisfies your "must keep the vendor folder with all its files" requirement.

---

## 3. Is `storage/` in the zip? Is it required for building? (BLOCKER B1)

- **In the zip?** No — `storage/` is excluded (`:406`).
- **Required to *build*?** No (except the builder writes a temp changelog to `storage/temp` at `:306`, created on demand).
- **Required to *install/run*?** **YES — the directory skeleton is.** Two concrete failures when extracting the current zip and installing:
  1. `InstallerController::checkRequirements()` checks `is_dir($storageDir) && is_writable($storageDir)` — with no `storage/` dir, **Step 1 "Writable: storage/" fails** and the wizard cannot proceed.
  2. `InstallerController::finalize()` does `file_put_contents($this->markerFile, …)` where `markerFile = storage/.installed`; with no `storage/`, this **throws** (no parent dir). Cache/logs/sessions writes fail at runtime too.
- **Root cause:** `scanAndZip()` only adds **files** (`if ($fileinfo->isFile())`, `:502`); `ZipArchive` does not record empty directories, so even non-excluded empty dirs (e.g. `public/assets/uploads`) are lost on extract.

### Fix — ship an empty storage/upload skeleton (add before `$zip->close()` at `:522`)
```php
// Preserve required runtime directory skeleton (contents stay excluded).
$skeletonDirs = [
    'storage', 'storage/cache', 'storage/logs', 'storage/temp',
    'storage/languages', 'storage/framework', 'storage/backups',
    'public/assets/uploads',
];
foreach ($skeletonDirs as $d) {
    $zip->addEmptyDir($d);
    $zip->addFromString($d . '/.gitkeep', '');   // guarantees the dir materializes on extract
}
```
> Keep `storage/` in `$rootExclusions` (so its *contents* — `.installed`, `.env.temp`, logs, cache — never ship), and add the skeleton explicitly as above. This is the single change that makes "zip = clean fresh install" true.

---

## 4. The zip as BOTH update AND fresh-install — gap analysis

For a downloaded `ownpay-{version}.zip` to install with **zero errors**, the extracted tree must contain everything the installer needs and nothing that blocks it:

| Requirement | Status in current zip | Action |
|---|---|---|
| `src/`, `config/`, `database/schema.sql`, `templates/`, `modules/`, `public/`, `vendor/` | ✅ included | — |
| `.env.example` (installer's `finalize()` reads it) | ✅ included (only `.env`/`.env.temp` excluded) | — |
| `.htaccess` (front-controller routing) | ✅ included | — |
| `storage/` writable skeleton | ❌ **MISSING** | **B1 fix** |
| `public/assets/uploads/` dir | ❌ missing (empty dir lost) | B1 fix |
| `storage/.installed` **absent** (so installer runs) | ✅ absent (storage excluded) | — |
| No dev deps / no PHP 8.3-only packages in `vendor/` | ❌ `composer update` ships them | **B2 fix** |
| No leaked junk (`.claude/`, `output/`, prompt.txt) | ❌ leaks | **B3 fix** |

### B2 fix — build a production vendor (don't ship dev tools)
Replace the `composer update` step (`:185-188`) for the packaging path:
```php
// Build a lean, production-only vendor for the release (keeps vendor, drops dev tools like phpunit/phpstan).
$composer = 'composer';                       // or: PHP_BINARY . ' ' . escapeshellarg($composerPharPath)
passthru($composer . ' install --no-dev --optimize-autoloader --classmap-authoritative', $returnVar);
// After packaging, restore the dev environment locally:
//   passthru($composer . ' install');
```
This still **keeps `vendor/`** (your requirement) but excludes `phpunit/phpunit ^12.5` (which requires PHP 8.3 and is the root of FIND-006) and other dev-only packages, shrinking the zip and keeping it PHP 8.2-clean.

---

## 5. Public key — how it's managed & whether to bundle it in the zip

**You do NOT bundle the public key file in the zip.** The model (verified in `build-update.php` + the Round-1 recon of `src/Update/UpdateService.php`):

1. The builder generates a 2048-bit RSA keypair to `update/update_private_key.pem` and `update/update_public_key.pem` (`:108-156`).
2. **Both `.pem` files are excluded from the zip** (`fileExclusions` at `:429-430`).
3. The **public key travels embedded in the application code** — the builder instructs you to paste it into `src/Update/UpdateService.php` as the `UPDATE_PUBLIC_KEY` constant (`:163-165`). Since `src/` ships in the zip, every client already has the public key compiled in and can verify update signatures. ✅ This is the correct design.
4. The **private key never ships** — it stays on your build machine only. (Excluded from the zip; must also be in `.gitignore`.)
5. The **`.pem` files belong on the UPDATE SERVER side**: you publish `update/` (manifest.json + index.html + releases/) to `update.ownpay.org`. The public `.pem` may be published there for transparency, but verification does not depend on it (the embedded constant is authoritative).

**Answer to "will I have to make zip including the public key?":** No. The public key ships *inside the code* (`UpdateService.php` constant), not as a separate file in the zip. Do **not** add the `.pem` to the zip; do **not** ship the private key anywhere.

### B4 improvement — auto-write the key instead of manual paste
Manual copy/paste into a PHP constant is error-prone (a malformed key silently disables verification). After generating the keypair, write it programmatically:
```php
// After openssl_pkey_export(...) produces $publicKeyContent:
$svcPath = $projectRoot . '/src/Update/UpdateService.php';
$svc = (string) file_get_contents($svcPath);
$pemEscaped = var_export($publicKeyContent, true);
$svc = preg_replace(
    '/(const\s+UPDATE_PUBLIC_KEY\s*=\s*)(.*?)(;)/s',
    '${1}' . $pemEscaped . '${3}',
    $svc
);
file_put_contents($svcPath, $svc);
echo "Public key written into src/Update/UpdateService.php automatically.\n";
```
> Keep a one-time **key-rotation warning**: regenerating the keypair invalidates all previously-signed releases for clients that already embedded the old key — only rotate with a migration story.

---

## 6. Minor hardening (B5/B6)
- **B5:** resolve composer robustly — try `composer`, then `php composer.phar`, then a configured path; fail loudly if none found (currently `passthru('composer update')` silently no-ops if composer isn't on PATH on the build host).
- **B6:** `release.json.notes` is hardcoded `"Verified"` (`:571`) — make it the changelog summary or drop it. Confirm `version_code` (`:609`) is only used for display, not for `version_compare` ordering (it strips pre-release suffixes, which would mis-sort `1.0.0` vs `1.0.0-rc1`).

---

## 7. Corrected packaging flow (summary)
1. `composer install --no-dev --optimize-autoloader` (B2).
2. Allowlist (or corrected denylist) scan → add files (B3).
3. `addEmptyDir()` + `.gitkeep` for `storage/*` and `public/assets/uploads` (B1).
4. In-zip `config/app.php` version bump (already correct, `:503-511`).
5. SHA-256 + RSA-sign (already correct, `:532-548`).
6. Restore dev env locally (`composer install`).

**With B1+B2+B3 applied, the produced zip is simultaneously a valid signed update payload and a clean fresh-install bundle** — which is the stated goal.
