# Module Creator CLI Review — `cli/create-module.php`

> Review of the OwnPay gateway/addon/theme scaffolder. Markdown-only. Line refs verified this session (reviewed lines 1–1328 of 1583; the remainder is additional theme HTML templates that follow the same patterns).

## Verdict
**Largely complete and well-architected** — interactive type picker (gateway/addon/theme), auto-slug, capability picker, PSR-4 namespacing, type-specific `manifest.json` (incl. CSP, hooks, routes, settings), and full entrypoint class generation with good security *comments*. **But it has several real defects**: it generates code that calls a **non-existent method**, ships **insecure-by-default** verify/webhook stubs (propagating FIND-004/FIND-005), a **broken `$this` reference** in the theme PHP path, and **missing scaffold assets/tests**. None block using the tool, but they degrade the quality and security of every module it produces.

---

## ✅ Implemented this round (authorized: `cli/create-module.php`)
| Item | Status |
|---|---|
| M1 — secure-by-default gateway stubs: `initiate()`/`verify()`/`refund()` now `throw` "not implemented"; `verifyWebhook()` **fails closed** (returns `false`) when no secret | ✅ implemented |
| M2 — addon `$req->jsonBody()` → `$req->json()` (+ array guard) | ✅ implemented |
| M3 — theme PHP path injects `$events` into the `render_php` scope; templates call `$events->doAction(...)` guarded (fixes invalid `$this->events`) | ✅ implemented |
| M4 — CSRF field renamed `csrf_token` → `_csrf_token`; PHP path value uses `SecurityHelpers::csrfToken()` | ✅ implemented |
| M5 — placeholder `assets/icon.svg` generated + manifest `icon` → `assets/icon.svg` | ✅ implemented |
| M6 — README / test stub / slug-collision check | ⏭️ deferred (lower priority) |
`php -l` clean on the modified CLI.

---

## Findings

### M1 — HIGH (security): scaffold propagates the FIND-004/FIND-005 insecure pattern
The generated gateway `verify()` and `verifyWebhook()` are insecure-by-default:
- `verify()` hardcodes `$paymentSucceeded = true;` and returns `status => 'completed'` (`:606-614`). A developer who ships the scaffold unmodified gets a gateway that **auto-confirms every payment** — exactly FIND-004.
- `verifyWebhook()` returns `true` when `webhook_secret` is empty (`:627-630`) — exactly the FIND-005 no-op pattern.
- `initiate()` returns a `mock_checkout_session` redirect + `mock_session_…` id (`:580-583`).

The scaffold's comments are excellent ("Never trust callback parameters. Query the remote API server", `:419-420`, `:589`), but the *generated default code contradicts them*. A scaffold should be **secure-by-default**: fail closed until implemented.

**Fix — generate "not implemented" stubs that fail safe:**
```php
public function verify(array $callbackData, array $credentials): array
{
    // TODO: query the gateway API to confirm payment before returning success.
    throw new \RuntimeException('{{NAME}} verify() not implemented — refusing to auto-confirm.');
}
public function verifyWebhook(string $rawBody, array $headers, array $credentials): bool
{
    $secret = $credentials['webhook_secret'] ?? '';
    if ($secret === '') { return false; }          // fail closed, NOT `return true`
    $sig = $headers['Signature-Key'] ?? $headers['signature-key'] ?? '';
    return $sig !== '' && hash_equals(hash_hmac('sha256', $rawBody, $secret), $sig);
}
public function initiate(array $params, array $credentials): array
{
    throw new \RuntimeException('{{NAME}} initiate() not implemented.');
}
```
> Tie this to the IMPLEMENTATION_PLAN.md gateway-conformance CI test: the same test that fails the fleet on un-gated `mock_` should also fail any scaffold left unimplemented in `live` mode.

### M2 — HIGH (correctness): generated addon calls a non-existent method
The addon entrypoint's `handleWebhook()` calls `$req->jsonBody()` (`:859`), but `OwnPay\Http\Request` exposes **`json()`** (and `input()`/`all()`/`post()`), not `jsonBody()`. Any scaffolded addon webhook handler **fatals on first call**.
**Fix:** generate `$body = $req->json();` (and `count(is_array($body) ? $body : [])`).

### M3 — MEDIUM (correctness): theme PHP template uses an invalid `$this->events`
In the PHP-template theme path, the generated `checkout.php` calls `$this->events->doAction('checkout.head')` (`:1260`, `:1308`, `:1323`). These files are `include`d by the `render_php` Twig function closure defined in `Theme::register()` (`:944-954`), so `$this` is the `Theme` instance — which has **no `events` property** (it's never stored). Result: undefined-property → fatal when rendering the themed checkout. Also `doAction()` returns `void`, so `<?= $this->events->doAction(...) ?>` prints nothing even if `$this` were valid (the hook mechanism relies on listeners echoing directly, which is itself a fragile pattern).
**Fix:** store the container/events on the Theme instance in `boot()`, expose a helper the template can call, or have `register()` enqueue assets via `addAction` (as the Twig-engine path already does at `:961-968`) instead of calling hooks from inside the PHP view.

### M4 — MEDIUM (correctness/security): CSRF field name + raw-PHP token call were both wrong  ✅ FIXED
Two distinct bugs in the scaffolded checkout forms (confirmed against the live code this round):
1. **Field-name mismatch (PHP *and* Twig paths):** forms used `name="csrf_token"`, but `CsrfMiddleware` validates `$_POST['_csrf_token']` (`:64`) and the real templates use `name="_csrf_token"`. A scaffolded checkout's POST would therefore **always be rejected by CSRF**.
2. **Raw-PHP `csrf_token()` call:** the PHP-template path emitted `<?= csrf_token() ?>` (`:1281`,`:1373`), but `csrf_token` is a **Twig** function/global (`TwigExtensions.php:56`, `services.php:211`), not a plain PHP function — so in a raw-PHP `include` it **fatals** (undefined function).
**Fix applied:** field renamed to `_csrf_token` everywhere; the PHP path now uses `\OwnPay\Security\SecurityHelpers::csrfToken()` (the canonical generator that populates `$_SESSION['_csrf_token']`); the Twig path keeps `{{ csrf_token() }}` (valid).
> Verified non-issue: `hook()` is registered `is_safe=html` (`TwigExtensions.php:60`), so the scaffold's `{{ hook(...) }}` without `|raw` is correct — not a bug.

### M5 — LOW: manifest references an icon that is never created
`manifest.json` sets `'icon' => 'assets/icon.png'` (`:331`) but the scaffold only `mkdir`s `assets/` (`:310`) and never creates `assets/icon.png`. The admin plugin/gateway list will show a broken image. **Fix:** write a tiny default placeholder PNG/SVG, or point `icon` at an existing core default until the dev replaces it.

### M6 — LOW: missing scaffold artifacts ("what's missing")
For a "complete" module creator, also generate:
- `README.md` (module purpose, config fields, install notes).
- A test stub under the module (or a note on where tests live).
- An **uninstall** data-cleanup hint (gateway scaffold's `uninstall()` is empty `:527`; addon's deletes settings `:784-790` — good; document the difference).
- A `.gitkeep` in empty `assets/` dirs so they survive packaging (ties to the `build-update.php` empty-dir issue).
- Slug-collision check against existing gateway slugs (currently only checks directory existence `:235`), to avoid two plugins claiming the same `slug`.

---

## What it does well (keep)
- Clean PSR-4 namespace + `toStudlyCase` class naming (`:143-146`, `:221-233`).
- Capability picker maps to the sandbox `Capability` enum (`:251-300`) — good least-privilege onboarding.
- Type-specific manifest with a per-gateway **CSP** block (`:345-350`) that the `SecurityHeadersMiddleware` consumes — excellent.
- Secrets declared as `type => 'password'` fields (`:540-541`); webhook verify uses `hash_equals` (`:640`).
- Strong inline "secure development invariants" guidance (`:416-421`).

## Priority
M1 (secure-by-default) and M2 (`jsonBody()`) are the two that matter for first release — every module produced today inherits an auto-confirming gateway stub and a fatal addon webhook handler. M3–M6 are quality/robustness. All fixes are localized to the heredoc templates in `create-module.php`; no core changes required.
