# OwnPay — Architecture

> Canonical architecture reference for OwnPay: a self-hosted, **single-owner / multi-brand** payment gateway on a bespoke PHP 8.2 framework (PSR-11 DI, custom HTTP layer, Twig, MySQL/PDO). Conventionally this file lives at the repo root; this copy is in `docs/v2/audit_findings/` per the audit bundle.

## 1. Philosophy
- **Sovereign single-owner, multi-brand.** One super-administrator owns the platform; multiple **brands** (UI term) operate under it; staff are assigned to brands. The tenant key is always `merchant_id` (never a SaaS multi-tenant model). Any feature that breaches brand isolation is release-blocking.
- **Own the framework.** A small, dependency-light kernel (twig, firebase/php-jwt, ramsey/uuid, phpdotenv, chillerlan/php-qrcode) chosen for low-resource shared-hosting, direct lifecycle control, automatic `merchant_id` scoping at the repository layer, and a centralized error mask. (Trade-offs in `DESIGN.md` Part 2.)
- **Secure & auditable by default.** Prepared statements only, fail-closed tenant scoping, sandboxed plugins, signed updates.

## 2. Layered design
```
HTTP (public/index.php) → Kernel → Middleware pipeline → Router → Controller
                                                                      │
                          Service layer  ◄───────────────────────────┘
                          (Payment, Sms, Device, Gateway, Domain, Notification, Auth, System)
                                  │
                          Repository layer (BaseRepository + TenantScope)  →  Core\Database (PDO)
                          Cross-cutting: Event(hooks), Plugin(sandbox), Security, Cache, Queue
```
Dependencies point **downward** (Controller→Service→Repository→Core). Controllers never touch PDO directly; services orchestrate; repositories own SQL.

## 3. Request lifecycle / bootstrap
Entry: `public/index.php` → `new Kernel(); $kernel->handle()`. `Kernel::boot()` (`src/Kernel.php:79-235`):
1. Load `.env` (phpdotenv `safeLoad`).
2. Build the DI container from `config/services.php`.
3. Bootstrap `EnvironmentService` (DB-backed settings).
4. Wire `EventManager` + `PluginRegistry` into `Database` (query hooks/sandbox).
5. Set timezone; **boot plugins first** (so they can register middleware/hooks — AUD-G1).
6. Load `config/middleware.php`, apply the `system.middleware.pipeline` filter, then **re-assert** security middleware that plugins must not remove (AUD-21).
7. Fire `system.boot`; validate `JWT_SECRET`/`APP_KEY`/`ENCRYPTION_KEY` length when installed.
8. Load routes (`config/routes/*.php` + plugin routes).
Then `handle()` captures the `Request`, applies `system.request`/`system.response` filters, runs `processRequest()` (install-lock + maintenance checks → route match → middleware onion → controller dispatch), sends the `Response`, fires `system.shutdown`.

```mermaid
flowchart LR
  A[public/index.php] --> B[Kernel::handle]
  B --> C[boot: env→DI→plugins→middleware→routes]
  C --> D[Router::match]
  D --> E[Middleware onion<br/>global + group]
  E --> F[Controller@action]
  F --> G[Service]
  G --> H[Repository + TenantScope]
  H --> I[(Core\Database / PDO)]
  F --> J[Response::send]
```

## 4. DI container (`src/Container.php`)
PSR-11 (`get`/`has`) with `bind`/`singleton`/`instance`/`param`. Unregistered classes are resolved by **reflection autowiring** (constructor type-hints, recursive, with primitive defaults), with circular-dependency detection. Services are registered as **singletons** in `config/services.php`, so reflection cost is largely one-time per request.
> **Known debt (FIND-003):** a parallel static service-locator `Database::getInstance()` exists and is **not** initialized at boot — prefer constructor injection everywhere and retire the locator.

## 5. Middleware pipeline (`config/middleware.php`, `Kernel::runMiddleware`)
An inside-out onion of `handle(Request,$next): Response` middleware (PSR-15-like, not the PSR-15 interface). Groups: `global` (SecurityHeaders, Maintenance, Domain), `web` (Session, Csrf), `web-auth` (+RateLimiter), `admin` (+RateLimiter, Language, TwoFactor, Permission), `api`/`admin-api`/`api-public` (Cors, RateLimiter, Bearer/AdminBearer, Idempotency), `mobile` (Cors, RateLimiter, JwtAuth), `webhook` (IpAllowlist), `cron`, `checkout`, `install` (SecurityHeaders only). A missing middleware class throws (BUG-1 — never silently bypass security).

## 6. Routing (`src/Http/Router.php`, `config/routes/*`)
Verb + pattern routes (`/checkout/{id}`) mapped to `Controller@action` with a middleware-group tag. Plugins inject routes via the `system.routes.register` hook.

## 7. Tenant isolation model
- `merchant_id` is the tenant key on every brand-owned table.
- `Repository\TenantScope` (`forTenant($id)` returns a **clone** with `tenantId` set; `requireTenant()` **throws** if unset). Scoped CRUD auto-appends `merchant_id = :mid`; `updateScoped` **unsets** `merchant_id` to block cross-tenant migration.
- `Service\Brand\BrandContext` holds the active brand; `Middleware\DomainMiddleware` resolves custom domains to a `merchant_id` (checks `dns_verified`, blocks `/admin` on custom domains, 404s unknown/inactive domains).
- Plugins activate **per brand** (`EventManager::isOwnerActive`).

## 8. Data model (52 tables — see `SCHEMA_REVIEW.md`)
- **Money core:** `op_transactions` (with STORED generated `invoice_id`/`payment_link_id` for hot lookups), `op_payment_intents`, `op_refunds`, `op_disputes`, `op_fee_rules`, `op_idempotency_keys`.
- **Double-entry ledger (triple-table):** `op_ledger_accounts` (asset/liability/equity/revenue/expense) → `op_ledger_transactions` (journal headers) → `op_ledger_entries` (debit/credit lines). Balanced-journal invariant enforced in `LedgerService::postEntries`.
- **RBAC/tenancy:** `op_merchants`, `op_merchant_users` (Argon2id + encrypted TOTP), `op_roles`/`op_permissions`/`op_role_permissions`, `op_domains`, `op_brand_plugins`.
- **Devices/SMS:** `op_paired_devices`, `op_device_pairing_tokens`, `op_sms_templates`, `op_sms_parsed`, `op_mobile_notifications`.
- **System:** `op_rate_limits`, `op_cache`, `op_sessions`, `op_audit_logs` (HMAC-signed), `op_webhook_deliveries` (payload-hash only).
- PII (customer name/email/phone) stored encrypted (`*_enc`) with search hashes (`*_hash`).
- *(Gaps to fix before release: `op_alerts` missing; `op_job_queue` vs `op_queue_jobs` — `SCHEMA_REVIEW.md`.)*

## 9. Payment & refund flow
Intent/transaction → `GatewayApiService::initiatePayment` (fee calc + adapter `initiate`) → customer pays at gateway → callback/IPN to `/webhook/{gateway}` (`UnifiedWebhookController`, signature-verified) or sync return → `GatewayApiService::handleCallback` (FOR UPDATE lock, completes using **stored** amount, posts ledger via `LedgerService::recordPaymentReceived`). Refunds: `RefundService::create` (double FOR UPDATE, over-refund/negative guards, proportional fee, ledger `recordRefund`). *(FIND-003 currently breaks the callback/refund entry via the service-locator; FIND-002 holds the lock across the gateway HTTP call.)*

## 10. Gateway & plugin architecture
- **Gateway contract:** `Gateway\GatewayAdapterInterface` (`initiate`/`verify`/`verifyWebhook`/`refund`/`supports`/`supportedCurrencies`); `Gateway\GatewayBridge` decrypts credentials and routes. ~140 adapters under `modules/gateways/`. *(Contract is not yet enforced secure-by-default — FIND-004/005; add an abstract base + CI conformance test.)*
- **Plugins:** `Plugin\PluginLoader` discovers `modules/{gateways,addons,themes}` via `manifest.json`; `PluginRegistry` tracks status; `PluginSandbox` validates plugin SQL; `Capability` enum gates permissions.
- **Events:** `Event\EventManager` actions (fire-and-forget) + filters (pipeline), priority-ordered, per-listener error isolation, **brand-scoped activation**, and a sandbox re-check on plugin-owned `db.query.before` SQL mutations.

## 11. SMS / MFS subsystem
Companion app POSTs GCM-encrypted carrier SMS → `Api\Mobile\SmsController` → `Service\Sms\SmsParserService::processBatch` (decrypt → dedup → regex template match → heuristic fallback). `Cron\SmsVerificationJob` matches parsed SMS to pending transactions (by TrxID, then amount within a single-match window) and completes them via the ledger. On-device privacy gate config served by `Api\Mobile\ConfigController` (`filter-rules`: whitelisted senders + negative keywords). See `mobile_architecture.md`.

## 12. Security architecture
CSRF (synchronizer token), CSP + per-request nonce + HSTS/XFO/nosniff (`SecurityHeadersMiddleware`), CORS default-deny, JWT (HS256, fingerprint, refresh rotation), Argon2id + TOTP + lockout, field encryption (`Security\FieldEncryptor`), SSRF validation (`Security\UrlValidator`), rate limiting (Redis/DB), and a path-masking exception handler. Full posture in `SECURITY_AUDIT_V2.md`.

## 13. Self-update system
`update/` = server side (manifest.json + index.html + releases/ + RSA keys). `src/Update/UpdateService` checks the manifest (domain allowlist), downloads, verifies **SHA-256 + RSA-SHA256** against an embedded public key, backs up, extracts (with traversal guard), runs `releases/<v>/migrations/*.sql`, health-checks, and rolls back on failure. `MaintenanceMode` gates traffic during updates. Packaging is done by `cli/build-update.php` (see `UPDATE_BUILDER_REVIEW.md`).

## 14. Caching, queue, low-resource
`Cache\FileCache` default (Redis optional, graceful fallback); `Queue\FileQueue` default; `Cron\QueueWorkerJob` drains the DB queue (fix `op_job_queue` schema first). Designed to bootstrap on 512MB/1-vCPU shared hosting: lean deps, singleton DI, file cache, aggressive Twig compile cache. See the master report §8.

## 15. Architectural debts (must address — see `IMPLEMENTATION_PLAN.md`)
1. Retire `Database::getInstance()` static locator → DI (FIND-003).
2. Enforce a **secure-by-default gateway contract** (abstract base + CI conformance) so adapters can't ship `mock_`/`return true` (FIND-004/005).
3. Separate auth-bootstrap routes from JWT-guarded routes (FIND-019).
4. Reconcile schema/code (`op_alerts`, `op_job_queue`).
5. Make the test tier runnable on the supported PHP (FIND-006).
