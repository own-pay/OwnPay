# Change Log — Add new-findings implementation plan (Addendum) + sync source doc

- **Timestamp:** 2026-05-31 02:18:07 (local)
- **Type:** DOCUMENTATION-ONLY (markdown in `docs/v2/audit_findings/`). No code touched.
- **Snapshots:** `output/snapshots/IMPLEMENTATION_PLAN.before-20260531-021807.md`, `output/snapshots/UPDATE_SERVER_REVIEW.before-20260531-021807.md`.

## Pre-change declaration (what / why / where)
- **What:** add implementation-plan entries for the findings that were added/applied in Round 3b/3c but never got a fix-plan, **without removing any existing plan content** (per user instruction "do not remove existing implementation plan. just add new").
- **Why:** the user noted new findings were reflected in the docs but `IMPLEMENTATION_PLAN.md` "is still remaining with old only." Verified: the original plan covered FIND-001→020, FIND-S1/S2, build-update B1-B6, create-module M1-M6, index.html **U1-U5** — but the Round 3b/3c `update/index.html` work (list-resilience bug fix, GitHub-first download, branding/UX) and the sharpened create-module **M4** had no plan entries. `UPDATE_SERVER_REVIEW.md` was also stale (U6 still described `checkZipExists()`, which Round 3c removed).
- **Where:** `docs/v2/audit_findings/IMPLEMENTATION_PLAN.md` and `docs/v2/audit_findings/UPDATE_SERVER_REVIEW.md` only.

## What changed (all additive)
### `IMPLEMENTATION_PLAN.md`
- **Appended** a new `## ADDENDUM — New Findings Implementation Plan (Round 3b/3c additions)` section after the Release Gate Checklist, with full Where/Fix/Verify/Status for:
  - **U7** — list-resilience bug (broken latest release wiped the whole list) → ✅ FIXED Round 3c.
  - **U8** — GitHub-first download + local mirror fallback → ✅ IMPLEMENTED Round 3c.
  - **U9** — branding + premium UX (logo/favicon/ecosystem/social, sticky nav, hero verify-command, light/dark, search, CSP meta) → ✅ IMPLEMENTED; SRI/self-host remaining.
  - **M4** — create-module scaffold CSRF (`csrf_token` → `_csrf_token`; raw-PHP `csrf_token()` → `SecurityHelpers::csrfToken()`) → ✅ FIXED Round 3; reconciles the existing Phase-C "M3-M6" bucket.
  - Plus an "Addendum gate" checklist (fast-follow; not release-blocking).
- **Added one row** to the Coverage map table so U7/U8/U9 + M4 are accounted for.
- **No existing line removed or rewritten** — original Phases A/B/C, coverage map, and Release Gate Checklist are byte-for-byte intact except the single appended coverage row and the appended Addendum.

### `UPDATE_SERVER_REVIEW.md` (source doc, kept in sync)
- **Added** an "✅ Implemented (Round 3b/3c)" summary table.
- **Added** findings **U7** (HIGH bug, fixed), **U8** (GitHub-first, implemented), **U9** (branding/UX, implemented).
- **Annotated** the now-stale **U6** with a Round 3c update note: `checkZipExists()` was removed (its failure path was the U7 list-wipe bug; cross-origin HEAD was unreliable). U6 text retained (additive note, not a deletion).

## Command summary
- Read `IMPLEMENTATION_PLAN.md`, `UPDATE_SERVER_REVIEW.md`, planning `findings.md`; globbed `docs/v2/audit_findings/` + `output/change-log/` to confirm exactly which findings were new vs. already-planned.
- 4 `Edit` ops (2 per file); verified via grep that all 5 new headers + the coverage row landed (UPDATE_SERVER_REVIEW L23/76/85/94; IMPLEMENTATION_PLAN L116/137/141/148/154/161).

## Validation
- Additive-only confirmed: every original heading/row still present; new content sits in a clearly-labelled Addendum + new finding sections.
- Line/function refs in the new entries match the current `update/index.html` (githubUrl ~910, localMirrorUrl ~920, downloadBlock ~930, renderChannel ~993) verified earlier this session.

## Risks / notes
- Markdown-only; no source/CLI/schema code changed. Snapshots retained for both docs. No destructive operations.
- The only remaining open item from these additions is U9/U3 (real SRI or self-hosted marked/DOMPurify; tighten CSP off `'unsafe-inline'`) — recorded as a fast-follow, not a release blocker.
