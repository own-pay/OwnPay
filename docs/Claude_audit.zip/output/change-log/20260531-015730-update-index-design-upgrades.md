# Change Log — update/index.html: design upgrades (2-5) + list-resilience bug fix + GitHub-first download

- **Timestamp:** 2026-05-31 01:57:30 (local)
- **File:** `update/index.html` (authorized — the public release registry page).
- **Verified-good snapshot:** `output/snapshots/index.after-design-upgrade-20260531-015730.html` (51,954 bytes).

## Pre-change declaration (what / why / where)
- **What:** apply the four optional premium upgrades the user accepted — (2) sticky top nav + hero verify-command band, (3) light/dark theme toggle, (4) release search/filter, (5) CSP + pinned/SRI-friendly CDN posture — AND fix a reported bug where a problem with the **latest** release (config error / missing download link) hid the **entire** release list. Also: make **GitHub the first download priority**, with the local same-origin mirror as a fallback.
- **Why:** user request ("apply 2,3,4,5 and there is a error i found … if the latest … has any configuration error or not found the download link it will skip … but don't break the entire list. also GitHub link will be first … fast priority is GitHub").
- **Where:** `<head>` (CSP/meta/theme-init), `<style>` (theme tokens + new component CSS), `<body>` (topnav, hero command, search input), and the inline `<script>` (download helpers + `renderChannel` rewrite + 3 UI handlers).

## What changed
### Bug fix — list no longer dies with the latest release (core of the request)
- `renderChannel(channel, releases)` changed from `async` to **sync**; removed the old `await checkZipExists(latest.download_url)` gate that did `historyList.innerHTML=''; return` when the latest zip 404'd — that single check wiped the whole list.
- Now: `const valid = (releases||[]).filter(r => r && r.version)` skips structurally-invalid entries; features `valid[0]`; renders history `valid.slice(1)` **independently**. A broken/missing latest download can no longer hide older versions.
- `downloadBlock()` degrades gracefully: when no download URL can be derived it renders an `unavailable-badge` ("Download unavailable") **inside** the otherwise-complete card instead of throwing/blanking.

### GitHub-first download (with local mirror fallback)
- New `GITHUB_REPO='https://github.com/own-pay/OwnPay'`.
- `githubUrl(rel)`: returns the manifest `download_url` **if** it's a `github.com` URL; else builds the conventional `${GITHUB_REPO}/releases/download/v${version}/ownpay-${version}.zip` (version `encodeURIComponent`'d).
- `localMirrorUrl(rel)`: derives a same-origin relative mirror path (`releases/<v>/ownpay-<v>.zip`) from the manifest, used as the fallback link.
- `downloadBlock(rel, opts)`: primary button = **Download (GitHub)**; secondary = "or use direct mirror" link. (Cross-origin GitHub 404 can't be reliably probed at render time — which is exactly what caused the original bug — so GitHub is offered as the primary link and the mirror is always shown as a visible fallback rather than via a fragile HEAD check.)

### (2) Sticky top nav + hero verify-command band
- New `<nav class="topnav">`: logo (→ ownpay.org) + Home/Docs/Blog/Learn/Support/GitHub links + theme-toggle button (moon/sun SVGs).
- Hero command box in `<header>`: `<code id="verify-cmd">sha256sum -c checksum.sha256 …</code>` + copy button (`#hero-copy-btn`).

### (3) Light/dark theme toggle
- `[data-theme="light"]` token block (+ light `h1` gradient override).
- Anti-flash inline init at top of `<head>`: reads `localStorage['op-update-theme']` and sets `data-theme` before paint. Toggle handler persists the choice.

### (4) Release search/filter
- `<input type="search" id="release-search">`; handler hides non-matching cards in the active panel via `data-search="v<version> <date>"` attributes on `.latest-card`/`.history-item`; shows a `.search-empty` note when nothing matches.

### (5) CSP + CDN hardening posture
- Added `<meta http-equiv="Content-Security-Policy">` (default-src 'self'; scripts limited to self + jsdelivr; img to self + ownpay.org + data:; object-src 'none'; base-uri 'none'). `color-scheme` meta added.
- marked/DOMPurify remain pinned (`@12`/`@3`); changelog still rendered through `DOMPurify.sanitize(marked.parse(...))`. A self-host note documents dropping the CDN by vendoring the two libs under `/vendor`.

## Command summary
- `node output/_check_index_js.cjs` (throwaway probe, deleted) → **ALL 2 INLINE SCRIPTS OK** (theme-init 161 chars; main app 19,607 chars).
- Reworded one self-host HTML comment to remove a literal `<script>` token (it was a false-positive trip for the probe's regex; harmless in-browser, but cleaner gone).
- `grep` confirmed all new elements + 3 handlers present and a single `</body></html>`.

## Validation / test results
- Inline JS: syntactically valid (both scripts).
- Bug-fix logic read back (lines 993-1143): invalid entries filtered, latest featured, history rendered independently, `downloadBlock` GitHub-first + mirror fallback + unavailable badge. Confirmed correct.
- HTML structure intact (single document close; topnav/hero/search/handlers all present).

## Risks / notes
- **Snapshot honesty:** this turn's 13 edits were applied in succession (before a context compaction), so no dedicated *pre-design-edit* snapshot was taken at the time. The nearest prior snapshot is `index.before-20260531-011812.html` (pre-branding); together with the branding change-log (`20260531-012008-…`) and this log, the full delta is documented. A **verified-good post-upgrade** snapshot is now captured (above) as the forward recovery point. No git repo exists at the project root, so snapshots are the rollback mechanism. No destructive operations performed.
- CSP keeps `'unsafe-inline'` for scripts/styles because this is a single static file with inline theme-init/handlers and inline styles; tightening to nonces/hashes is the documented next step if desired.
- Only `update/index.html` was modified. No other source/CLI/schema files touched.
