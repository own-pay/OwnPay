# Change Log — Propagate New Round-3 Findings into Docs

- **Timestamp:** 2026-05-31 01:09:47 (local)
- **Type:** DOCUMENTATION-ONLY (markdown in docs/v2/audit_findings/). No code changed.

## New findings discovered during Round-3 implementation, now written into the relevant docs

### FIND-020 — Dead/unused schema tables (LOW)
`op_maintenance_locks`, `op_queue_jobs`, `op_plugin_settings` are defined in `schema.sql` but have zero runtime references (verified by grep). Propagated to:
- `SCHEMA_REVIEW.md` §6 (primary detail) — already added previous step.
- `ownpay_master_audit_report.md` — added FIND-020 to §10 + severity matrix (LOW 5→6).
- `IMPLEMENTATION_PLAN.md` — added a Phase-C row + coverage map entry.
- `SECURITY_AUDIT_V2.md` — added A04 register line.

### Module scaffold CSRF finding sharpened (MODULE_BUILDER_REVIEW.md M4)
Refined M4 from "csrf_token() assumed" (LOW) to the accurate dual bug (MEDIUM, FIXED):
1. field name `csrf_token` ≠ `_csrf_token` that `CsrfMiddleware` validates (both PHP + Twig paths) → scaffolded checkout CSRF always rejected;
2. raw-PHP `csrf_token()` call fatals (it's a Twig function/global, not a PHP function).
Both fixed this round.

### Verified NON-finding (recorded to prevent a future false positive)
`hook()` is registered `is_safe=html` (`TwigExtensions.php:60`), so the scaffold's `{{ hook(...) }}` without `|raw` is correct — NOT a bug. Noted in MODULE_BUILDER_REVIEW.md M4.

## Files touched (markdown only)
`ownpay_master_audit_report.md`, `IMPLEMENTATION_PLAN.md`, `SECURITY_AUDIT_V2.md`, `MODULE_BUILDER_REVIEW.md` (+ `SCHEMA_REVIEW.md` §6 from the prior step). No source/CLI/schema code modified in this step.
