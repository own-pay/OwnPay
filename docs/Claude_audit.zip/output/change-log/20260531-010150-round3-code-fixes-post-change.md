# Change Log — Round 3: Authorized Code Fixes (Post-Change Report)

- **Timestamp:** 2026-05-31 01:01:50 (local)
- **Scope (user-authorized):** edit ONLY `cli/build-update.php`, `cli/create-module.php`, `update/index.html`. All other code "left." Schema analyzed read-only (recommendations only).

## 1. Pre-change declaration (recap)
Implement the `.buildignore` plan for the update builder (your idea — adopted, enhanced with a secret hard-deny net), fix the module creator and update-server page, and report any extra/unused schema tables. Snapshots taken before editing.

## 2. Files changed
**Code (authorized):**
- `cli/build-update.php` — replaced hardcoded exclusion arrays with a `.buildignore` loader (gitignore-style) + `buildIsIgnored()`/`buildIsHardDenied()` helpers; added a **secret hard-deny** net (`.env`, `.env.*`, `*private_key*.pem`, `.git/`) applied before `.buildignore`; added the **storage/uploads runtime skeleton** (`addEmptyDir()` + `.gitkeep`) so the zip is a valid fresh-install (B1). B2/B5 intentionally skipped (build machine is set up); B4 not applied (would edit `UpdateService.php`).
- `cli/create-module.php` — M1: gateway `initiate()/verify()/refund()` now `throw` "not implemented"; `verifyWebhook()` fails closed when no secret. M2: addon `$req->jsonBody()`→`$req->json()` (+array guard). M3: theme PHP path injects `$events` into `render_php` and templates call `$events->doAction(...)` guarded. M4: CSRF field `csrf_token`→`_csrf_token`, PHP value via `SecurityHelpers::csrfToken()`. M5: generate placeholder `assets/icon.svg` + manifest `icon`→`.svg`.
- `update/index.html` — U1: `formatBytes()` math fix (`Math.pow(k,i)`) + guards. U2: changelog sanitized with **DOMPurify**; `marked`/DOMPurify CDN pinned to major (`@12`/`@3`). U4: `--primary` aligned to `#6c5ce7`.

**New file (part of the build-update mechanism you proposed):**
- `cli/.buildignore` — the externalized ignore list (55 rules). NOTE: this is a new file created to make the `.buildignore` plan functional; `cli/build-update.php` reads it. It is itself excluded from release zips (cli/ rule).

**Docs updated (markdown deliverables):**
- `docs/v2/audit_findings/SCHEMA_REVIEW.md` — added §6 "Extra / unused tables" (op_maintenance_locks, op_queue_jobs, op_plugin_settings — verified zero runtime refs).
- `UPDATE_BUILDER_REVIEW.md`, `MODULE_BUILDER_REVIEW.md`, `UPDATE_SERVER_REVIEW.md` — added "Implemented this round" status blocks.

## 3. Snapshots (CLAUDE.md §3)
`output/snapshots/{build-update,create-module}.before-20260530-234008.{php}` and `index.before-20260530-234008.html` captured before edits.

## 4. Validation
- `php -l cli/build-update.php` → No syntax errors.
- `php -l cli/create-module.php` → No syntax errors.
- `.buildignore` matching logic verified with a throwaway probe: 55 patterns loaded, **33/33** path cases pass (secrets denied; `vendor/`, `.env.example`, `.htaccess`, `composer.*`, project src kept; `output/`/`.claude/`/`storage/`/junk ignored). Probe deleted.

## 5. Extra/unused schema answer
3 unused tables found (LOW): `op_maintenance_locks` (file-lock used instead), `op_queue_jobs` (dead; worker uses `op_job_queue` — FIND-S2), `op_plugin_settings` (plugins use `op_system_settings`). Detail + recommendations in SCHEMA_REVIEW.md §6. Schema not edited (out of scope).

## 6. Integrity / risks
Only the 3 authorized code files + the new `cli/.buildignore` were modified in code; all other source untouched. Snapshots exist for rollback. No destructive operations. Public-key handling unchanged (still embedded in `UpdateService.php`; `.pem` not shipped) — B4 auto-write deferred as it touches an unauthorized file.
