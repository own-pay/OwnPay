# Change Log — Feature Gap Analysis (scope-corrected) → docs/v2/features/feature-gap-analysis.md

- **Timestamp:** 2026-05-31 10:29:45 (local)
- **Type:** DOCUMENTATION-ONLY (new markdown). No source/schema/config code touched.

## Pre-change declaration (what / why / where)
- **What:** create `docs/v2/features/feature-gap-analysis.md` — an evidence-based, scope-accurate analysis of OwnPay's missing / dead / improvable features.
- **Why:** user asked what features are missing / good-to-have / useless / improvable, then corrected the operating model (single-owner aggregator; merchant owns business+customer concerns) and said "update then save."
- **Where:** new file `docs/v2/features/feature-gap-analysis.md` only.

## Owner's scope corrections applied (now parked as OUT OF SCOPE in §1)
- No settlement/payout (funds go directly to owner; owner handles cash-out off-platform).
- Test-suite "gap" = false positive (tests run on a separate PHP 8.3 build machine).
- Customer order history = merchant website, not OwnPay.
- Coupons/vouchers/discounts = merchant business logic.
- Installments = not OwnPay's job (it aggregates gateways, isn't a BNPL/lender).
- Customer emails/receipts/analytics = merchant's job (OwnPay just fires webhooks/events).
- Subscription scheduling = merchant (the only in-scope adjacent primitive is tokenization/mandates → moved to good-to-have §3).

## Evidence gathered this session before writing
- `schema.sql` table inventory (52 `op_*` tables) — confirmed `op_disputes`, `op_ledger_*`, `op_idempotency_keys`, `op_currencies/op_exchange_rates`, `op_fee_rules`, `op_comm_log` EXIST; `op_alerts` ABSENT; `op_queue_jobs` present but worker uses `op_job_queue`.
- `src/Service/**` inventory — confirmed `ReconciliationService`, `DisputeService`, `MailProviderInterface`/`SmsProviderInterface`/`CommunicationService`, `LedgerService`, etc. exist (so they are NOT missing).
- Targeted greps: no gateway routing/failover/health/circuit-breaker engine (only HTTP Router, webhook retry, mock fallback matched); no tokenization/vault/mandate; no 3DS/SCA orchestration in core → these are genuine in-scope gaps.

## Document structure
§0 operating model · §1 explicitly out-of-scope (parked) · §2 important missing/broken (2a confirmed defects: op_alerts, queue table, gateway mock_/verify, Database::getInstance; 2b aggregator value-adds: routing/failover, gateway health/circuit-breaker) · §3 good-to-have (tokenization/mandates, 3DS/SCA, fuller REST API, OpenAPI/SDK, per-gateway sandbox, webhook normalization/replay, MCP) · §4 dead weight (dead tables, MfsService, unscoped methods, inflated gateway catalog) · §5 improvable (gateway integrity, refund saga, API completeness, SMS trx_id matching, resilience knobs, webhook backoff/dead-letter, reconciliation/dispute depth) · §6 what's already good · §7 confidence/method + suggested order of work.

## Validation
- Every "missing/absent" claim is backed by the schema/service inventory or a targeted grep this session; defect claims carry FIND-ids from the prior audit. Out-of-scope items reflect the owner's explicit corrections.

## Risks / notes
- Documentation-only; no executable code added. Some §3 prioritization is judgement (labeled as recommendation, not defect).
- Only `docs/v2/features/feature-gap-analysis.md` created. No snapshots needed (new file). No destructive operations.
