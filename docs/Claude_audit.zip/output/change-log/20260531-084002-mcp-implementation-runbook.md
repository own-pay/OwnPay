# Change Log — MCP Server AI Implementation Runbook (docs/v2/features/mcp-implementation-plan.md)

- **Timestamp:** 2026-05-31 08:40:02 (local)
- **Type:** DOCUMENTATION-ONLY (new markdown). No source/schema/config code touched.

## Pre-change declaration (what / why / where)
- **What:** create `docs/v2/features/mcp-implementation-plan.md` — a step-by-step, zero-mistake build runbook that an AI model can follow to implement the MCP server from `mcp.md` without breaking anything.
- **Why:** user request — a detailed, foolproof implementation plan "read by ai model and implemented the entire MCP server without any minor mistake … nothing will break", written for a non-expert AI with explicit guidelines.
- **Where:** new file `docs/v2/features/mcp-implementation-plan.md` only (sibling to `mcp.md`).

## Accuracy basis (verified the real framework before writing)
Read in full this session to make the runbook's code/edits exact:
- `config/middleware.php` (group structure), `config/routes/api.php` (router API + namespace prefix), `src/Container.php` (autowire; THROWS on scalar ctor params — line ~284), `src/Http/Request.php` + `src/Http/Response.php` (exact method signatures), `src/Middleware/BearerAuthMiddleware.php` (middleware contract = ctor `Container` only, resolve deps in handle), `src/Kernel.php` 240-368 (middleware resolved via `container->get()`; `Router::dispatch`), `config/services.php` (singleton factory style), `src/Controller/Api/HealthController.php` (controller shape), `src/Repository/ApiKeyRepository.php` + `BaseRepository.php` (hashed-credential repo template + Database API: fetchOne/fetchAll/fetchColumn/insert/update/delete; create/update/findByPrefix/forTenant/createScoped/updateScoped).

## What the runbook contains
- **§0 Rules of Engagement:** 12 hard rules, verified framework conventions (Request/Response/Container/middleware/controller/repo APIs), the autowire trap (no scalar ctor params), additive-only edits, verify-after-every-step, reference files, Windows/XAMPP check commands.
- **§1 Phase −1 Pre-flight:** mandatory read+confirm checklist for service signatures, the ledger-balance accessor, and the admin-session→user/brand resolution, plus snapshots — so the AI adapts to reality instead of guessing.
- **§2-§8 Phases 0-6:** DB tables + settings; OAuth 2.1 AS (repos, OAuthServer with PKCE/mint/rotate, OAuthController, consent.twig, routes); McpResourceMiddleware + `mcp` group; MCP core (Tool/McpContext/SchemaValidator/ToolRegistry+deny-list/McpServer/McpController + DI registration + route); 23 tools (3 full exemplars + exact spec table for the rest, each backing a verified safe service call, all forTenant-scoped); admin UI; hardening + 4 test suites.
- **§9-§11:** Definition of Done acceptance checklist; rollback; troubleshooting (symptom→cause→fix).
- Every phase has a **CHECK** gate; the deny-by-default `ToolRegistry` + hard deny-list regex + CI tripwire test are the no-financial-loss guarantee.

## Safety guarantees encoded for the implementer
- Forbidden ops named explicitly and never registered: RefundService::create, GatewayApiService::initiatePayment/handleCallback, CheckoutController::submitVerification, ApiKeyService/op_api_keys, unscoped findPendingMatchGlobal/getGlobalBrandBreakdown, ledger/settings/user mutation.
- All edits to shared files (routes/middleware/services/schema) are ADDITIVE at marked anchors; existing features preserved (final regression smoke test required).
- Audit FIND-006 (PHPUnit needs 8.3) called out: write tests; run on the 8.3 build box.

## Command summary
- 9 read-only file reads (wiring + http + repo + controller) to pin exact APIs; Write the runbook; Grep verification (12 sections, all CHECK gates, no TODO/FIXME).

## Risks / notes
- Documentation-only; no executable code added. The runbook intentionally bakes in a pre-flight verification phase so any signature drift is caught by the implementer rather than causing breakage.
- Spots that depend on un-read internals (ledger balance accessor, AuditLogger arg order, RefundRepository list method, admin session user resolution, router dotted-path handling) are flagged **VERIFY** with adapt-to-reality instructions — no silent guessing.
- Only `docs/v2/features/mcp-implementation-plan.md` created. No snapshots needed (new file). No destructive operations.
