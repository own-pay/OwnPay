# Change Log — update/index.html: real branding + ecosystem links

- **Timestamp:** 2026-05-31 01:20:08 (local)
- **File:** `update/index.html` (authorized). Snapshot: `output/snapshots/index.before-20260531-011812.html`.

## What changed (why: user-requested real branding + links)
- **Favicon**: added `<link rel="icon">` + `apple-touch-icon` → `https://ownpay.org/ownpay_icon.png`. Added `og:title`/`og:image` (logo) + `<meta description>`. Title aligned to "OwnPay — Update Registry".
- **Logo**: replaced the text "OP" icon with the real logo `https://ownpay.org/ownpay_logo.png` (linked to https://ownpay.org), with an `onerror` fallback to the original gradient "OP" mark if the image fails to load. Added `.logo-img`/`.logo-link` CSS (drop-shadow + hover lift, matching the existing aesthetic).
- **Footer nav** (new): Home (ownpay.org), Blog (blog.ownpay.org), Learn (learn.ownpay.org), Support (support.ownpay.org), GitHub (github.com/own-pay/OwnPay).
- **Social icons** (new): GitHub (github.com/own-pay/OwnPay) + Facebook (fb.com/ownpay.org), as inline SVGs with hover micro-interactions matching the glassmorphism theme.
- All external links use `target="_blank" rel="noopener"`.

## Design note
The existing page is already a premium glassmorphism design (gradient blobs, Outfit type, tabs/cards/animations); these changes complete it (real brand, favicon, ecosystem footer) rather than redesign it. Optional future premium upgrades were offered to the user (sticky top nav, hero, copy install command, light/dark, release search) — not implemented (scope).

## Validation / integrity
Verified via read-back + grep: favicon, og:image, header logo img + fallback, and all 6 link targets (home/blog/learn/support/github/facebook) present and well-formed. Only `update/index.html` changed; snapshot retained for rollback. No destructive operations.
