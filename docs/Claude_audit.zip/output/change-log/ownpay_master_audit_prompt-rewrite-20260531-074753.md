# Change Log — OwnPay Master Audit Prompt Rewrite

**Timestamp:** 2026-05-31 07:47:53
**Author:** Claude (Master Auditor session)
**Change type:** Full-file rewrite (single artifact, prompt engineering uplift)

## Summary of Edits

Replaced the contents of `C:\xampp\htdocs\ownpay_master_audit_prompt.txt` with a v2.0 production-grade agent audit prompt. The prior version was verbose narrative; the new version is a structured agent instruction document built on prompt-engineering best practice.

## Reason for Edits

User request: the prior prompt was "not deeper, and not looking an actual prompt." Goal was to deliver a real agent-grade prompt using prompt-engineering best practices — structured sections, explicit invariants, phased execution gates, verification protocol, severity rubric, evidence-required finding template, and anti-hallucination guards.

## File Paths Touched

- **Modified:** `C:\xampp\htdocs\ownpay_master_audit_prompt.txt`
- **Snapshot of original:** `C:\xampp\htdocs\output\snapshots\ownpay_master_audit_prompt.before-20260531-025929.txt`
- **This log:** `C:\xampp\htdocs\output\change-log\ownpay_master_audit_prompt-rewrite-20260531-074753.md`

## Structural Changes Applied

The new prompt adds the following XML-tagged sections in execution order:

1. `<system_identity>` — Three-role auditor persona (Adversarial Architect / Fintech Forensic / Pre-Release Gatekeeper) with explicit calibration on missed-vs-fabricated finding asymmetry.
2. `<mission_gravity>` — Concrete bug-class → real-world-harm mapping.
3. `<sovereign_invariants>` — Seven named architectural invariants (INV-1 through INV-7), each citable in findings.
4. `<oath_of_the_auditor>` — Twelve binding rules (RULE-1 through RULE-12) including two-pass rule for fix proposals and framework-respect rule.
5. `<execution_framework>` — Five strictly-ordered phases (Phase 0 Discovery → Phase 1 Invariant Verification → Phase 2 Quest Execution → Phase 3 Adversarial Self-Review → Phase 4 Synthesis), each with entry criteria and explicit exit gates.
6. `<verification_protocol>` — Four-check protocol (Evidence / Call Chain / Failure Scenario / Compensating Control) applied before any finding is recorded.
7. `<severity_rubric>` — Anchored CRITICAL/HIGH/MEDIUM/LOW/INFORMATIONAL criteria with concrete trigger lists.
8. `<audit_quests>` — Ten quests preserved from the source but restructured with explicit scope, evidence target, and numbered sub-questions (Q1.1, Q1.2, ...) so coverage is auditable.
9. `<testing_strategy>` — WHAT / WHY / WHAT-IF-SKIPPED / WHAT-IS-MISSING discipline across three tiers (self / auto / manual).
10. `<finding_template>` — Mandatory schema with a full worked example showing call chain, evidence excerpt, attack path, fix, and verification.
11. `<anti_patterns>` — Twelve self-detection patterns covering hedging language, missing citations, severity inflation/deflation, and invented APIs.
12. `<deliverables>` — Four documents with explicit section ordering and table specs (severity matrix, attack vector matrix, mock plugin registry, time-to-find table).
13. `<completion_criteria>` — Nine-checkbox done definition; no checkbox unchecked means not done.
14. `<closing_instruction>` — Anti-summarization guard and write-as-you-go directive to prevent context-loss-on-crash.

## Prompt Engineering Techniques Applied

- **XML-tag sectioning** — Claude responds reliably to XML-style tags for major sections; chosen over Markdown headers for the agent-instruction layer.
- **Named invariants (INV-N) and rules (RULE-N)** — Citable identifiers let the agent reference them in findings ("This violates INV-2") rather than restate them.
- **Phased execution with exit gates** — Prevents the agent from skipping discovery and jumping straight to findings.
- **Adversarial self-review phase** — Built-in refutation loop on CRITICAL/HIGH findings counters false-positive bias.
- **Verification protocol before finding-record** — Four-check gate forces evidence-before-claim.
- **Anchored severity rubric** — Removes severity drift; each tier has concrete trigger list.
- **Worked finding example** — Few-shot demonstration of the expected output shape.
- **Anti-pattern callouts** — Negative examples shape behavior more reliably than positive-only guidance.
- **Two-pass rule (RULE-11)** — Fix proposals must reference only verified-present APIs; counters hallucinated `Validator::make()` style suggestions.
- **Closing instruction** — Explicit anti-summarization and write-as-you-go guidance to prevent the common failure modes of (a) restating the prompt back and (b) losing work to mid-run interruption.

## Command Summary

```
mkdir -p output/snapshots output/change-log
cp ownpay_master_audit_prompt.txt output/snapshots/ownpay_master_audit_prompt.before-20260531-025929.txt
# Write tool: full rewrite of ownpay_master_audit_prompt.txt
# Write tool: this change log
```

## Validation / Test Results

- Snapshot created and verified via `ls -la output/snapshots/` (entry present at 34,575 bytes).
- New file written successfully via Write tool (atomic replace).
- No source code under `app/`, `src/`, `plugins/`, `public/`, or `schema/` was modified — audit prompt is a standalone artifact.
- No git operations performed.

## Risks / Notes

- The new prompt is longer in instructional density but is intentionally so — agent prompts of this class need explicit phase gates and verification protocols to produce reliable output.
- The new prompt assumes the executing agent has filesystem read access to the OwnPay project root. This matches the user's stated deployment model.
- The original is preserved in `output/snapshots/` and can be restored with a single `cp` if needed.
- No destructive operation performed; CLAUDE.md "no destructive rollback" policy honored.
