## v0.2.0 Release

- Incremental improvements and stability fixes.