## v0.2.2 Release

- Incremental improvements and stability fixes.